#!/usr/bin/env python3
"""End-to-end smoke test: boot -> notice dialog -> click OK -> menu -> keypress."""
import asyncio, os, sys
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright
from PIL import Image, ImageChops

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000/"
TAG = sys.argv[2] if len(sys.argv) > 2 else "run"
OUT = "/home/user/shots"
os.makedirs(OUT, exist_ok=True)
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
        "--js-flags=--max-old-space-size=256", "--use-gl=angle", "--use-angle=swiftshader",
        "--autoplay-policy=no-user-gesture-required", "--window-size=900,506"]


def diff_pct(a, b):
    if not (os.path.exists(a) and os.path.exists(b)):
        return None
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    if ia.size != ib.size:
        return None
    d = ImageChops.difference(ia, ib)
    px = sum(1 for p in d.getdata() if sum(p) > 24)
    return px / (ia.size[0] * ia.size[1]) * 100


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        pg = await b.new_page(viewport={"width": 900, "height": 506})
        errs, warns = [], []
        pg.on("console", lambda m: (errs if m.type == "error" else warns).append(m.text[:110]))
        await pg.goto(URL + "?nofs", wait_until="commit", timeout=30000)

        ready = False
        for _ in range(96):
            await asyncio.sleep(0.25)
            try:
                if await pg.evaluate("!!window.__gdReady"):
                    ready = True
                    break
            except Exception:
                print(f"[{TAG}] page died during boot (sandbox RAM limit)")
                return
        print(f"[{TAG}] boot ready={ready}")
        if not ready:
            return

        await asyncio.sleep(3.0)
        a = f"{OUT}/{TAG}_1_dialog.png"
        await pg.screenshot(path=a, timeout=40000)

        box = await pg.evaluate("(() => { const r=document.getElementById('canvas').getBoundingClientRect(); return {x:r.left,y:r.top,w:r.width,h:r.height}; })()")
        await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
        await asyncio.sleep(0.6)
        await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
        await asyncio.sleep(2.0)
        c = f"{OUT}/{TAG}_2_menu.png"
        await pg.screenshot(path=c, timeout=40000)

        q = await pg.evaluate("Module.gdInputQueue.length")
        f1 = await pg.evaluate("Module._gd_frames_get()|0")
        await pg.keyboard.down("Space")
        await asyncio.sleep(0.35)
        await pg.keyboard.up("Space")
        await asyncio.sleep(2.0)
        d = f"{OUT}/{TAG}_3_afterkey.png"
        await pg.screenshot(path=d, timeout=40000)
        f2 = await pg.evaluate("Module._gd_frames_get()|0")

        print(f"[{TAG}] frames {f1} -> {f2} (delta {f2-f1}), pending input after clicks={q}")
        print(f"[{TAG}] dialog->menu changed {diff_pct(a,c)}% pixels; menu->afterkey changed {diff_pct(c,d)}% pixels")
        print(f"[{TAG}] console errors={len(errs)} warnings={len(warns)}")
        for e in errs[:3]:
            print("   ERR:", e)
        try:
            await b.close()
        except Exception:
            pass

asyncio.run(main())
