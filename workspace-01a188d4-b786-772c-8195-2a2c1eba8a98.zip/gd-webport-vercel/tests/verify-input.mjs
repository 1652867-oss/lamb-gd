#!/usr/bin/env node
/**
 * Unit test for the patched hot-path input poll in gd_web.js.
 *
 * Original:  q.shift()   -> O(n) and allocates on every polled message
 * Patched:   head index  -> zero allocation
 *
 * Both implementations are driven with the identical operation sequence, each on
 * its own queue state, and must return byte-identical results.
 */
import { readFile } from "node:fs/promises";

const src = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
const start = src.indexOf("function gd_js_mouse_poll(msg, wp, lp) {");
const end = src.indexOf("gd_js_mouse_poll.sig", start);
if (start < 0 || end < 0) throw new Error("gd_js_mouse_poll not found");
const patchedSrc = src.slice(start, end);

const HEAP = new Int32Array(16);
globalThis.HEAP32 = HEAP;

const ModuleA = { gdInputQueue: [], gdInputHead: 0 };
const patchedPoll = new Function("HEAP32", "Module", `return (${patchedSrc.trim()})`)(HEAP, ModuleA);

function refPoll(msg, wp, lp) {
  const q = ModuleB.gdInputQueue;
  if (!q || q.length === 0) return 0;
  const e = q.shift();
  HEAP[msg >>> 2] = e[0];
  HEAP[wp >>> 2] = e[1];
  HEAP[lp >>> 2] = e[2];
  return 1;
}

// module B is the reference (queue.shift) implementation
const ModuleB = { gdInputQueue: [] };
const Module = ModuleA;

function pushBoth(e) { Module.gdInputQueue.push(e.slice()); ModuleB.gdInputQueue.push(e.slice()); }

let checked = 0, failures = 0;
const rnd = () => Math.random();

for (let round = 0; round < 2000; round++) {
  const nPush = Math.floor(rnd() * 6);
  for (let i = 0; i < nPush; i++) {
    pushBoth([Math.floor(rnd() * 1000), Math.floor(rnd() * 4), Math.floor(rnd() * 1e6)]);
  }
  const nPoll = Math.floor(rnd() * 8);
  for (let i = 0; i < nPoll; i++) {
    HEAP.fill(-1);
    const a = patchedPoll(0, 4, 8);
    const aOut = Array.from(HEAP.slice(0, 3));
    HEAP.fill(-1);
    const b = refPoll(0, 4, 8);
    const bOut = Array.from(HEAP.slice(0, 3));
    checked++;
    if (a !== b || aOut.join() !== bOut.join()) {
      if (++failures <= 3) console.error("MISMATCH", { a, b, aOut, bOut });
    }
  }
}

// edges
Module.gdInputQueue.length = 0; Module.gdInputHead = 0;
ModuleB.gdInputQueue.length = 0;
if (patchedPoll(0, 4, 8) !== 0) { failures++; console.error("empty queue must return 0"); }
pushBoth([7, 1, 2]);
for (let i = 0; i < 3; i++) { patchedPoll(0, 4, 8); refPoll(0, 4, 8); }
if (Module.gdInputQueue.length !== 0) { failures++; console.error("patched queue not reset after drain"); }
if (ModuleB.gdInputQueue.length !== 0) { failures++; console.error("ref queue not drained"); }

// a single entry must survive an interleaved empty poll
Module.gdInputQueue.push([9, 2, 3]); Module.gdInputHead = 0;
if (patchedPoll(0, 4, 8) !== 1 || HEAP[0] !== 9 || HEAP[1] !== 2 || HEAP[2] !== 3) { failures++; console.error("single entry lost"); }

console.log(`poll equivalence: ${checked} polls compared, ${failures} failures`);
console.log(failures === 0 ? "GLUE HOT-PATH: ALL PASS" : "GLUE HOT-PATH: FAILED");
process.exit(failures === 0 ? 0 : 1);
