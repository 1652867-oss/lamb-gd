#!/usr/bin/env python3
"""
Runtime test against a real build:
  * the game boots and presents frames
  * the engine opens ONLY the resolution set it asks for (-uhd), nothing missing
  * the notice dialog accepts a click and the game keeps rendering afterwards

Usage: python3 tests/runtime.py http://localhost:3000/ [--quick]

  --quick   skip the frame-progression and click stages (they need a real GPU;
            SwiftShader in a small container may thrash on the full texture set)

Note: this holds the whole texture set in memory, so very small machines may be
out of memory before the last stage. A stage that is skipped is reported as such.
"""
import asyncio, os, re, sys
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000/"
QUICK = "--quick" in sys.argv
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
        "--js-flags=--max-old-space-size=384", "--use-gl=angle", "--use-angle=swiftshader",
        "--autoplay-policy=no-user-gesture-required", "--window-size=900,506"]

TEX = (".png", ".plist", ".fnt", ".ogg", ".mp3", ".txt")
fails = []


def check(name, ok, detail=""):
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  -> " + detail) if detail and not ok else ""))
    if not ok:
        fails.append(name)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        pg = await b.new_page(viewport={"width": 900, "height": 506})
        opened, missing, errs = [], [], []
        # ?debug makes the engine dump its own logs through console.error, so only
        # count messages that actually look like page/JS failures
        REAL = re.compile(r"Uncaught|TypeError|ReferenceError|SyntaxError|HTTP 404|failed to|is not a function", re.I)
        DEBUG_LINE = re.compile(r"^\[[a-z_]+\]\s")   # engine/page debug channel
        pg.on("console", lambda m: errs.append(m.text[:120])
              if (m.type == "error" and REAL.search(m.text) and not DEBUG_LINE.match(m.text)) else None)

        def onmsg(m):
            mm = re.search(r'(?:fopen|GetFileAttributesA)\("([^"]+)"', m.text)
            if not mm:
                return
            name = mm.group(1).split("\\")[-1]
            low = m.text.lower()
            (missing if ("missing" in low or "-> fail" in low) else opened).append(name)

        pg.on("console", onmsg)
        await pg.goto(URL + "?debug&nofs", wait_until="commit", timeout=30000)

        ready = False
        for _ in range(120):
            await asyncio.sleep(0.25)
            try:
                if await asyncio.wait_for(pg.evaluate("!!window.__gdReady"), 8):
                    ready = True
                    break
            except Exception:
                break
        check("game boots and signals ready", ready)
        if not ready:
            print("  (page died during boot - almost certainly RAM in this environment)")
            return

        # frames keep coming (each stage degrades gracefully on low-RAM hosts)
        async def frames():
            # a stalled renderer must fail this check, not hang the whole suite
            try:
                return await asyncio.wait_for(pg.evaluate("Module._gd_frames_get()|0"), 8)
            except Exception:
                return None

        if QUICK:
            f0 = f1 = None
            print("  SKIP  frame progression (--quick)")
        else:
            f0 = await frames()
            await asyncio.sleep(2.0)
            f1 = await frames()
        if f0 is None or f1 is None:
            print("  SKIP  frame progression (renderer torn down by the host - low RAM)")
        else:
            check("engine presents frames", f1 > f0, f"{f0} -> {f1}")

        # resource discipline
        res = [n for n in opened if n.lower().endswith(TEX)]
        miss = [n for n in missing if n.lower().endswith(TEX)]
        hd = [n for n in res if re.search(r"-(hd|ld)\.", n, re.I)]
        uhd = [n for n in res if "-uhd." in n.lower()]
        unexpected = [n for n in miss if not re.search(r"-(hd|ld|uhd)\.(png|plist|fnt|ogg|mp3)$", n, re.I)]
        check("engine opens -uhd resources", len(uhd) > 0, str(len(uhd)))
        check("engine never opened a -hd/-ld file", len(hd) == 0, str(hd[:3]))
        check("no unexpected missing resource", len(unexpected) == 0, str(unexpected[:3]))
        print(f"      ({len(res)} resource opens, {len(miss)} probes reported missing, "
              f"{len(uhd)} of them -uhd)")

        # the notice dialog takes a click
        if QUICK:
            print("  SKIP  notice-dialog click (--quick)")
        try:
            if QUICK:
                raise RuntimeError("quick mode")
            box = await pg.evaluate("(() => { const r=document.getElementById('canvas').getBoundingClientRect(); return {x:r.left,y:r.top,w:r.width,h:r.height}; })()")
            await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
            await asyncio.sleep(1.0)
            await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
            await asyncio.sleep(2.0)
            f2 = await pg.evaluate("Module._gd_frames_get()|0")
            check("still rendering after accepting the notice", f2 >= (f1 or 0), f"{f1} -> {f2}")
        except Exception as e:
            print(f"      (post-click stage skipped: {type(e).__name__} - RAM in this environment)")

        check("no console errors", len(errs) == 0, "; ".join(errs[:2]))
        try:
            await b.close()
        except Exception:
            pass

    print("\nRUNTIME:", "ALL PASS" if not fails else f"{len(fails)} FAILED -> {fails}")
    sys.exit(0 if not fails else 1)

asyncio.run(main())
