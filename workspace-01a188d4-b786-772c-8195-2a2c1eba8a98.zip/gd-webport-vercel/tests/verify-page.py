#!/usr/bin/env python3
"""
Page-level checks that need no game assets (the Module object exists before boot):

  * ?fps=N and ?uncap reach the engine as Module.__gdPacing
  * ?nofs and ?dsync reach it as Module.__gdGpuTuning
  * a software rasterizer is detected and warned about (this sandbox is SwiftShader)
  * the boot overlay reports progress and never fails silently
"""
import asyncio, os, sys
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000/"
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
        "--js-flags=--max-old-space-size=256", "--use-gl=angle", "--use-angle=swiftshader"]

fails = []


def check(name, ok, detail=""):
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  -> " + detail) if detail and not ok else ""))
    if not ok:
        fails.append(name)


async def probe(b, query, state={"pg": None}):
    # one page, navigations only: this sandbox runs a single-process Chromium and
    # cannot afford a fresh context per case
    if state["pg"] is None:
        ctx = await b.new_context(viewport={"width": 900, "height": 506})
        await ctx.route("**/a/**", lambda r: r.abort())     # no assets needed
        state["pg"] = await ctx.new_page()
    pg = state["pg"]
    await pg.goto("about:blank")
    await pg.goto(URL + query, wait_until="commit", timeout=30000)
    await asyncio.sleep(0.6)
    state = await pg.evaluate("""(() => ({
        pacing: window.Module ? Module.__gdPacing : null,
        gpu: window.Module ? Module.__gdGpuTuning : null,
        renderer: window.__gdGpu || null,
        warn: !!document.getElementById('rawwarn'),
        msg: (document.querySelector('#msg>span') || {}).textContent || '',
    }))()""")
    return state


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)

        s = await probe(b, "?nofs")
        check("default pacing is engine/vsync", s["pacing"] and s["pacing"]["uncap"] is False and s["pacing"]["target"] == 0,
              str(s["pacing"]))
        check("?nofs is not treated as a pacing flag", s["pacing"] and s["pacing"]["uncap"] is False)
        check("software rasterizer is detected", "swiftshader" in (s["renderer"] or "").lower(), str(s["renderer"]))
        check("software rasterizer warns the player", s["warn"] is True)

        s = await probe(b, "?fps=90&nofs")
        check("?fps=90 sets a 11.1 ms budget", s["pacing"] and abs(s["pacing"]["target"] - 1000 / 90) < 0.01,
              str(s["pacing"]))

        s = await probe(b, "?uncap&nofs")
        check("?uncap sets uncap", s["pacing"] and s["pacing"]["uncap"] is True, str(s["pacing"]))

        s = await probe(b, "?fps=0&nofs")
        check("?fps=0 is clamped, not a divide-by-zero", s["pacing"] and s["pacing"]["target"] == 1000.0,
              str(s["pacing"]))

        s = await probe(b, "?fps=99999&nofs")
        check("?fps=99999 is clamped", s["pacing"] and s["pacing"]["target"] >= 1.0, str(s["pacing"]))

        s = await probe(b, "?dsync&nofs")
        check("?dsync reaches the GL attributes", s["gpu"] and s["gpu"]["desynchronized"] is True, str(s["gpu"]))

        s = await probe(b, "?noaa&nofs")
        check("?noaa reaches the GL attributes", s["gpu"] and s["gpu"]["antialias"] is False, str(s["gpu"]))

        s = await probe(b, "?power=default&nofs")
        check("?power=default reaches the GL attributes", s["gpu"] and s["gpu"]["powerPreference"] == "default",
              str(s["gpu"]))

        try:
            await b.close()
        except Exception:
            pass

    print("\nPAGE FLAGS:", "ALL PASS" if not fails else f"{len(fails)} FAILED -> {fails}")
    sys.exit(0 if not fails else 1)

asyncio.run(main())
