# Geometry Dash — WASM web port (Vercel-ready)

A self-contained, self-hosted build of the **Geometry Dash web port** (the Cocos2d-x → WebAssembly
port by **bog / "lollipop"**, kept current by *AlexBoops*), tuned for fast loading and smooth
runtime, packaged so it deploys to **Vercel** as-is.

The whole site *is* the game: one page, one canvas, fullscreen on first click — no menu, no
analytics, no loader screen, no proxy, no external CDN calls.

> **This build edits the game, not just the page.** Two things are patched inside the shipped
> engine at build time: its online server URLs (so level search/download go through this
> deployment — see *Online levels*) and its frame pacer / GL context attributes (runtime
> tuning). Everything is verified by `npm test`; nothing is patched by guessing.

> **Correctness first.** Earlier revisions of this package tried to save bytes by serving the
> smaller HD texture set under the UHD filenames. That is *not* a valid optimisation: Cocos2d-x
> derives each sprite's `contentScaleFactor` from the **filename suffix** (`-uhd` = 4, `-hd` = 2,
> no suffix = 1), so renaming HD bytes to `-uhd` makes every sprite draw at twice its intended
> size — the notice dialog ends up oversized with its text and OK button outside the panel.
> This build therefore ships **exactly the resolution set the engine asks for** and never
> substitutes resolutions. See *Verification* below for how that is enforced automatically.

---

## Online levels (the game's own servers, proxied by you)

Searching for a demon or any level by name, browsing the level lists, downloading a
level and playing it — all of that is the **game's own online feature**, and it works
here because the game now talks to *this deployment* instead of Boomlings.

**It is not a mod or an overlay. The game binary is edited at build time.** The server
URLs are compiled into the engine image (`/Resources/bin/GeometryDash.exe.img`,
NUL-terminated C strings), and `scripts/fetch-assets.mjs` rewrites each one in place:

```
https://www.boomlings.com/database/getGJLevels21.php   ->   /api/gd/getGJLevels21.php
https://www.boomlings.com/database/downloadGJLevel22.php -> /api/gd/downloadGJLevel22.php
https://www.boomlings.com/database/accounts/loginGJAccount.php -> /api/gd/accounts/loginGJAccount.php
... 60 endpoints in total, including the "databas/" typo the original build ships
```

The replacement is **length-preserving** (padded with NULs), so the memory image and
every package offset stay byte-identical and the engine notices nothing. Verified: zero
`boomlings.com/database` URLs survive in the shipped package, and the game's own HTTP
hook (`gd_http_start`) is proven to issue the `/api/gd/...` URL by test.

Then `server/gd-proxy.mjs` (used by both `api/gd/[...path].js` on Vercel and
`scripts/serve.mjs` locally) forwards those requests upstream:

| What it does | Why |
|---|---|
| forwards the body **verbatim** (including GD's `secret`) | Boomlings validates it; nothing is rewritten |
| sets a normal `User-Agent` | Boomlings/Cloudflare reject bot-like requests |
| **edge-caches public reads** — search `s-maxage=30`, level download `s-maxage=3600` | repeat searches and level loads are instant and cost no upstream traffic |
| never caches account/write endpoints (`accounts/*`, `upload*`, `rate*`, …) | credentials and mutations must not leak between players |
| rejects traversal, absolute URLs, unknown methods, bodies > 64 KB | it is a public proxy; it only speaks the game's own endpoint names |
| fails over across `GD_UPSTREAM=a,b,c` and returns `-1` if all are down | the game shows its own "no connection" instead of hanging |

After boot the page also **warms** two endpoints in the background, so the first time you
open Online Levels the data is already hot.

### If the upstream refuses your deployment

Boomlings sits behind Cloudflare, which bans whole datacenter ASNs (`error code: 1005`).
This sandbox is one of them, so the proxy's failover and error reporting are what I could
verify live here (against a stub upstream, end to end). If your deployment's egress is
blocked too, point it at a reachable mirror — no code change:

```bash
# Vercel dashboard -> Settings -> Environment Variables
GD_UPSTREAM="https://mirror-a.example/database,https://mirror-b.example/database"
```

Diagnose from any browser:

* `GET /api/gd/` → JSON with the configured upstreams and which endpoints are cacheable
* a failed request returns `-1` (the game's own "no data") plus an `x-gd-errors` header
  naming every upstream it tried and why it failed

`?noprefetch` disables the warm-up if you want to see the cold path.

---

## Deploy (pick one)

**A. Vercel CLI (fastest)**

```bash
cd gd-webport-vercel
npx vercel deploy --prod     # first run asks to link/create a project
```

**B. GitHub → Vercel**

1. Push this folder to a repo (the ~216 MB of generated assets are *not* committed — see below).
2. In Vercel: **Add New → Project → import the repo**.
3. Deploy. `vercel.json` already sets the build command, output dir and headers.

**Node version:** set in `package.json` (`engines.node`), **not** in `vercel.json`. For the built-in
Node runtime Vercel requires *no* `functions[].runtime` — that field is only for community runtimes
in `name@version` form, and a bare value like `nodejs20.x` fails the deploy with *"Function Runtimes
must have a valid version, for example `now-php@1.0.0`"*. `tests/verify-deploy-config.mjs` enforces
this (plus: no `[...]` in function globs, since those are glob character classes and would silently
match nothing).

Your build step downloads the game assets automatically (`node scripts/fetch-assets.mjs`), so the
repo stays tiny and the deployment ships the real binaries from Vercel's edge. The online-levels
proxy runs as a Node function at `api/gd/[...path].js` (config in `vercel.json`); no extra setup.

> Deployment size: **203 MB** of static assets (13.9 MB engine + 189.5 MB gzipped resource parts).
> Mind the bandwidth quota: Hobby includes 100 GB/month of fast data transfer ≈ **490 first-time
> players** (returning players transfer ~0 bytes; assets are `immutable` for a year and also pinned
> in Cache Storage).

**Local test**

```bash
npm run assets     # downloads + repacks public/a/* (~15 s, needs ~1 GB free RAM)
npm run serve      # http://localhost:3000
```

`npm run assets:force` re-downloads from upstream. The build is incremental: with a valid
`public/a/manifest.json` it does nothing.

---

## What was made faster / leaner

Measured first-load transfer, this build vs. the upstream port:

| | upstream port | this build |
|---|---|---|
| engine (`wasm`) | 69.8 MB (4 parts, concatenated in JS, then compiled) | **13.9 MB** gzip, inflated natively and compiled *from the stream* |
| resources (`data`) | 314.5 MB (16 parts, one at a time, plus a full 315 MB concat copy) | **189.5 MB** gzip of a **226 MB** deduplicated package (12 parts) |
| glue JS | 1.28 MB via `fetch`+`eval` | 1.28 MB, plain `<script>`, immutable-cached |
| **first load** | **385.6 MB** | **203.4 MB  (−47 %)** |
| repeat load | re-downloads whatever the CDN felt like | **~0 bytes** (Cache Storage + `immutable`) |
| RAM for the game files | ~315 MB | **~226 MB** (−89 MB) |
| texture VRAM | UHD set | **UHD set (unchanged — required for correct sprite scale)** |

How the bytes were removed (every claim verified by the test suite in `tests/`):

1. **WASM is gzip-compressed at build time** (69.8 → 13.9 MB, −80 %). The page streams it through
   the browser's native `DecompressionStream('gzip')` straight into
   `WebAssembly.instantiateStreaming` — it is never fully buffered in JS, so the old 70 MB blob is
   gone from memory too.
2. **The duplicate texture sets are dropped, not aliased** (−88.6 MB). The upstream package ships
   every atlas three times (`-uhd`, `-hd`, plain); this port only ever asks for `-uhd`, so the
   `-hd` and plain twins are removed outright. The files the engine does request keep their exact
   names — nothing is renamed, nothing is re-scaled, nothing can 404. 15 textures genuinely exist
   *only* as `-hd` upstream (icons, popups, promos); those ship as-is, which is correct because
   Cocos scales each sprite from its own filename. The build reports that number in
   `manifest.json` (`lowerResTextures: 15`) and the tests assert it.
3. **Data parts are gzip'd** (−36 MB, −16 %). Spritesheets and audio are already compressed, but the
   ~1 900 `plist` atlases and text payloads are not; each part is inflated natively while it
   streams, so decode never blocks the main thread.
4. **Identical files are deduplicated by content hash** across the whole package.
5. **No manifest round-trip.** The build bakes part count/sizes into `index.html`, so the first byte
   of the download is requested at HTML parse time, in parallel with the glue and the engine.

Runtime / structural changes:

| Area | upstream port | this build |
|---|---|---|
| Parallelism | 16 parts fetched **serially**, 60 ms sleep between them | **12 parts streamed concurrently** into one pre-allocated buffer (no concatenation copy) |
| Asset origin | `cdn.jsdelivr.net` + CORS proxies | same origin, your deployment |
| Engine boot | fetch → `eval` the glue | `<script src>`, streamed parse |
| Progress | `setStatus` string scraping | direct byte-accurate hook |
| Repeat visits | browser cache only | **Cache Storage** (survives cache eviction, works offline) |
| Boot UI | 4 bars, logo fly-in, 1.7 s artificial delay | one 2 px line + one word, auto-hidden when the first frame renders |
| Console/logging | in-page console, per-frame logs | disabled in production (`_gd_log_set(0)`, console no-oped) |
| Input | pointer/keyboard/touch glue | kept, cleaned: pointer coalescing, focus handshake, touch→click |
| Headers | defaults | `/a/*` `immutable` for a year; parts as octet-stream so no double-compression |

Result: the game is download-bound, so a 47 % smaller payload is ~47 % faster to first play
(a 100 Mbit line: ~31 s → ~16 s; a 25 Mbit line: ~2 min → ~65 s), and it costs ~47 % less Vercel
bandwidth.

### Where the remaining 203 MB is (measured, and why we stopped there)

| payload | files | size | removable? |
|---|---|---|---|
| PNG texture atlases (UHD set) | 1 587 | 112.5 MB | **only losslessly, and barely**: re-filtering every scanline with the best per-row PNG filter and re-deflating at level 9 was measured end to end at **106.0 MB (−5.7 %)**, for ~7 minutes of build CPU (no `zopflipng`/`oxipng`/`optipng` in a stock build image). 3 % of the download is not worth that. |
| audio: songs + sfx | 35 mp3 + 300 ogg | 74.5 MB | **no.** The two formats are disjoint sets (0 shared stems) — nothing is duplicated — and the files are already compressed, so gzip does nothing. Shrinking them means lossy re-encoding, which is a quality decision, not an optimisation. |
| `plist` atlases / `fnt` fonts / text | 1 404 | 15.8 MB | no: they are the metadata the engine needs, and they are the one part that *does* gzip well (already factored in). |
| engine `.img` blobs (`GeometryDash.exe.img`, 2 DLLs) | 3 | 12.3 MB | no: that is the executable image itself. |

Also verified, and rejected for good reasons:

* **Zero packaged files are unreferenced.** Cross-checking all 3 330 names against the strings in the
  engine binary, the glue and every text asset found **0** files that nothing can ever name, so there
  is no dead weight to delete.
* **Lazy per-file loading** (boot from ~20 MB and stream the rest) is the only change that would make
  first play *dramatically* faster, and it is not safe here: MEMFS files are zero-copy views into the
  single package buffer (`FS_createDataFile(..., canOwn=true)`), and a filesystem read cannot wait on
  the network. A file whose bytes had not arrived yet would read as zeros — a silently corrupted
  atlas, not an error. That trade is not worth a broken game, so it is not done.
* **Splitting/parallelising further** is already maxed: 12 parts stream concurrently over one
  connection pool (HTTP/2 multiplexes them), and the first part is requested at HTML parse time.
* **The staging buffer cannot be freed after boot** for the same zero-copy reason — the 226 MB buffer
  *is* the game's filesystem, so peak RAM is already the floor for this package size.

## Runtime performance (the game itself)

Load speed is only half of it; these change how the game *runs*.

| Lever | Before | Now | Why it matters |
|---|---|---|---|
| GPU selection | browser default (may pick the iGPU) | `powerPreference: "high-performance"` | laptops stop rendering GD on the integrated chip |
| Frame buffer | `preserveDrawingBuffer` possible | forced **false** | no implicit full-frame copy per presented frame |
| Canvas geometry | stretched by CSS to the window | **exact 16:9 letterbox, sized in JS** | the engine renders into a fixed 1920×1080 buffer; stretching it distorts the picture *and* moves every click, so the box is kept 16:9 and centred |
| Canvas layer | plain element | own compositor layer (`will-change`) | no page re-raster while the game draws |
| Input → game queue | `Array.shift()` per event (O(n), allocates) | **head index**, zero allocation | the poll runs every frame; this removed per-frame allocation churn on the hot path (proven equivalent over 7 000 polls in `tests/`) |
| Event path | separate `mouse*` + `touch*` handlers (double-fire on touch laptops) | **one `PointerEvent` path** with fallbacks | fewer handlers, no duplicate events |
| Mouse-move flood | every `mousemove` queued | coalesced to ≤1 pending move | the queue is drained once per frame; a flood only delays the frame |
| Window focus | never told | `WM_ACTIVATE`/`WM_SETFOCUS`/`WM_ACTIVATEAPP`, re-sent on refocus | the engine's input loop starts *and resumes* like a real Windows window (alt-tab back no longer leaves it deaf) |
| Coordinate mapping | `getBoundingClientRect()` on **every** event (forces layout) | rect cached, re-measured on resize/fullscreen | removes a synchronous layout from the latency chain of every click and key |
| Fullscreen | on first click, always | **on first click**, `?nofs` opts out | one less click, but embedders/testers can turn it off |
| Frame pacing | one promise + one closure **and** a fresh queue array per frame; vsync estimate could be poisoned by a single late frame | **allocation-free pacer**, clamped estimate that ignores tab-switch gaps, resets on `visibilitychange` | less GC per second on the hot path, and a 144 Hz panel is detected instead of assumed |
| FPS cap | whatever the engine asked for | **`?uncap`** (never wait for vsync) or **`?fps=N`** (explicit target) | the highest frame counter the machine can produce, or a deliberate cap |
| Software rendering | rendered at a few fps with no explanation | **detected and reported**: a one-line banner names the rasterizer | the #1 real-world cause of "the game is slow" is hardware acceleration being off; now the player is told |
| Audio output | default latency class | `AudioContext({ latencyHint: "interactive" })` | smaller output buffer = sfx land sooner |
| Debug/logging | per-frame log calls | off in production (`_gd_log_set(0)`, console no-oped) | removes per-frame string work |

The texture set is **not** a performance lever here: the engine asks for `-uhd`, so `-uhd` is what
ships. Shrinking it would mean shipping the wrong asset for the filename, which is the bug described
at the top of this file.

### Measuring it yourself

Open the site with **`?perf`** for a small overlay: real FPS (from the engine's own frame counter),
worst frame time, **input latency in ms**, and the texture set in use. No flag, no overlay, no cost.

## Verification — how this build is proven

Nothing here is called done by eyeball. `tests/` contains the harnesses; all of them exit non-zero
on failure.

```bash
npm test                        # glue hot-path equivalence + build integrity
node tests/verify-build.mjs     # part files, tags, textures, dangling URLs, headers
node tests/verify-gd-api.mjs    # online proxy: passthrough, caching, failover, abuse, engine patch
node tests/verify-deploy-config.mjs  # vercel.json/package.json validity (catches deploy-time rejections)
python3 tests/unittest_input.py http://localhost:3000/    # 16 input/geometry assertions
python3 tests/geomcheck.py      http://localhost:3000/    # letterbox + click mapping, 5 window shapes
python3 tests/runtime.py        http://localhost:3000/ --quick  # boot + resource discipline (7 s)
python3 tests/verify-page.py    http://localhost:3000/    # ?fps/?uncap/?dsync wiring + software-GPU warning
python3 tests/smoke.py          http://localhost:3000/ lab # boot → dialog → menu → key, screenshots
python3 tests/abtest.py         <label> <port> [refdir]   # pixel-diff two builds
```

What they assert:

* **Build integrity** — every file the page names exists; `index.html`'s baked `GD_BUILD` equals
  `manifest.json`; all 12 parts exist, are gzip, and sum to the declared size; the glue carries the
  build tag; **no texture base ships at two resolutions**; the only lower-res textures are the 15
  that upstream only publishes as `-hd`; no hard-coded `/a/` URL bypasses `assetURL()`.
* **Glue hot-path** — the patched zero-allocation input poll vs. the original `shift()` version over
  thousands of randomised push/poll sequences, byte-identical results.
* **Frame pacing** — with faked rAF/MessageChannel/timers: default waits for vsync; `?fps=240` skips
  it; `?fps=30` stays vsync-paced; `?uncap` never waits; a hidden tab backs off on a 50 ms timer; the
  refresh estimate survives a 5 s stall; the fast path allocates no per-frame queue.
* **Input & geometry** — at 960×540, 1000×700, 800×800, 1400×500 and 1920×1080 the canvas is exactly
  16:9, centred, inside the viewport; a click at the canvas centre produces `WM_LBUTTONDOWN` at game
  coordinates (960, 540) — i.e. the notice dialog's OK button is where it looks like it is; space
  produces `WM_KEYDOWN`+`WM_CHAR` with `VK_SPACE`; wheel, blur-release and focus messages verified;
  a 12-event mouse-move flood queues at most 3 polls.
* **Online proxy** — 30 assertions: endpoint parsing and traversal rejection, verbatim body + secret
  passthrough, User-Agent normalisation, cache policy per endpoint, method/size abuse, failover past a
  Cloudflare block and a 503, `-1` when everything is down, and the game-side proof that the engine
  image carries `/api/gd/...` and its HTTP hook issues that relative URL.
* **Runtime** — boot the real build, confirm the engine opens **only `-uhd` files** (0 `-hd`/`-ld`,
  0 unexpected missing files) and that the game advances frames.

### Cache correctness (why assets can never go stale)

`/a/*` is served `immutable` for a year, so URLs must change whenever the bytes do:

* The build computes a **tag** = hash of `commit + quality + layout version + output sizes + part
  count + **the glue's own bytes**` and writes it into `manifest.json` and `index.html`.
  (The glue hash matters: `/a/*` is immutable *and* the glue carries the same stamp, so without it a
  glue-only change — a runtime fix, a pacing change — would never reach a returning player. The
  integrity test recomputes that hash and fails the build if the tag ignores the glue.)
* Every asset request is `<file>?v=<tag>`; the Cache Storage bucket is `gd-assets-<tag>` and caches
  from other builds are deleted at startup.
* `index.html` is `no-store`, so a page can never be older than the deployment it talks to.
* The **engine script itself** is requested as `gd_web.js?v=<tag>` — a cached old glue used to ask
  for the *old* part count, which is what produced `part 12: HTTP 404` after a redeploy.
* The glue carries its own stamp (`Module.__gdBuildTag`); on mismatch the page re-fetches it with a
  cache buster.
* Belt and braces: a 404 on a part triggers one cache-busted retry, then a re-read of
  `manifest.json` to adopt the deployment's real part count — so even a fully stale page heals
  itself. This was reproduced and verified with a deliberately stale page.

### Optional knobs

| Flag | Effect |
|---|---|
| `?perf` | overlay: FPS, worst frame time, input latency, **measured display Hz**, pacing mode, GPU | 
| `?uncap` | never wait for vsync — highest possible FPS. Costs CPU/battery and can tear |
| `?fps=N` | pace to N fps (e.g. `?fps=90`). Ignored for N above the refresh rate, which is vsync-paced anyway |
| `?noprefetch` | don't pre-warm the online endpoints after boot |
| `?noaa` | drop MSAA on the default framebuffer — a real win on integrated GPUs; opt-in because it changes edge smoothing |
| `?nofs` | do not auto-fullscreen on the first click (embedding, testing) |
| `?dsync` | enables the low-latency (`desynchronized`) canvas. Cuts one compositor hop, but on some drivers the canvas then reads back black (screenshots, OBS, Discord capture). **Off by default** — try it, keep it only if capture still works. |
| `?power=default` | let the browser pick the GPU; better battery life, slower if you have a dGPU |
| `?debug` | full engine console output + build tag / part count / quality line |

Build-time: `GD_QUALITY=all npm run assets:force` produces a reference build with every resolution
present (312 MB, 16 parts). It does **not** fit Vercel's 100 MB static-upload limit and OOM-kills
machines with little RAM; it exists only for offline comparison.

Rebuild after changing anything: the build re-packs the package, updates the baked manifest and
writes a new tag.

## Black or blank screen? Read this

The page tells you what is happening instead of going silent:

| What you see | What it means |
|---|---|
| `loading 12%` climbing to `99%`, thin line at the bottom | **Normal.** It is downloading ~203 MB. On a 100 Mbit line ≈ 16 s, on 20 Mbit ≈ 1.5–2 min, on mobile data a lot longer. Leave the tab focused. |
| `loading X%` stuck for 25 s | The download stalled; the page says so. Reload and check in DevTools → Network that `/a/gd_web.data.partN` returns 200. |
| `game data failed to load (part N: HTTP 404 …)` | The page and the deployment disagree — usually a **stale cached page** from an older build. Every asset URL carries `?v=<tag>` and `index.html` is `no-store`, and a stale page self-heals; for an already-poisoned browser do one hard reload (Ctrl/Cmd+Shift+R). If it 404s on a *fresh* browser, the build step did not run. |
| `could not download the game engine` | Network failure while fetching the wasm pack, reported instead of hanging. |
| `This build needs WebAssembly JSPI…` | Browser too old / flag off. Chrome-Edge 137+, Firefox 153+, Safari 27+. Chrome flag: `chrome://flags/#enable-experimental-webassembly-features`. |
| `WebGL2 is unavailable` | Hardware acceleration is off, or you are in a VM/remote desktop. |
| Game's own blue **Geometry Dash** loading screen | It worked — the engine is up and booting its resources. |
| Pure black, no text at all | Old `index.html` cached, or JS disabled. Hard-reload and append `?debug`. |
| Deploy fails: *Function Runtimes must have a valid version* | `vercel.json` had a `functions[].runtime`. Remove it — the Node version comes from `package.json` `engines.node`. Run `node tests/verify-deploy-config.mjs`. |
| Online Levels shows "no connection" | `/api/gd/*` is up but the upstream is unreachable — check `GET /api/gd/` for the configured upstream, and the `x-gd-errors` header on a failing request. See *Online levels*. |

## Repository hygiene

`public/a/` (~216 MB) and `.cache-assets/` (~300 MB) are **build artifacts**, not source — both are
git-ignored. Vercel recreates them during the build (≈15 s). That keeps the project small enough to
sync, commit and diff; never force-add them to git.

```bash
npm run dev      # builds the assets once, then serves http://localhost:3000
```

## Requirements

* A modern desktop Chrome/Edge/Firefox (WebGL2 + WebAssembly).
* **JSPI** ("JavaScript Promise Integration") is used by this port for its frame-yield loop. Chrome
  has it on by default in current versions; if the game never leaves the loading screen, enable
  `chrome://flags#enable-experimental-webassembly-features`, restart, and add `?debug` to the URL to
  see the engine's console output.

## Controls

Click / tap / `Space` / `↑` to jump, `Esc` pauses, mouse for menus. Click once on the page for
fullscreen (or open with `?nofs` to stay windowed).

---

## Files

```
gd-webport-vercel/
├── vercel.json                 # build cmd, output dir, cache + MIME headers
├── package.json                # npm run assets / serve / test / deploy
├── public/
│   ├── index.html              # the whole site: canvas + loader + input glue
│   └── a/                      # generated by scripts/fetch-assets.mjs (git-ignored)
│       ├── manifest.json       # sizes, part count, texture-set info (also baked into the page)
│       ├── gd_web.js           # Emscripten glue, file table rewritten by the build
│       ├── gd_web.wasm.pack    # 66.6 MB engine, gzip (13.9 MB), stream-compiled
│       └── gd_web.data.part1…12# 226 MB resources (uhd set), deduplicated + gzip (189.5 MB)
├── scripts/
│   ├── fetch-assets.mjs        # downloads, dedupes, repacks, patches the glue, verifies sizes
│   └── serve.mjs               # local static server with Vercel-like headers
└── tests/
    ├── verify-build.mjs        # build integrity (node, no browser)
    ├── verify-gd-api.mjs       # online proxy + engine-image patch (node, no browser)
    ├── verify-deploy-config.mjs# Vercel config validity, offline (node, no browser)
    ├── verify-input.mjs        # glue hot-path equivalence (node, no browser)
    ├── verify-pacing.mjs       # frame pacer contract: vsync vs uncap vs ?fps (node, no browser)
    ├── verify-page.py          # query-flag wiring + software-renderer warning (Playwright)
    ├── unittest_input.py       # input/geometry assertions (Playwright)
    ├── geomcheck.py            # letterbox + click mapping at 5 window shapes (Playwright)
    ├── runtime.py              # boots the real build, audits which files the engine opens
    ├── smoke.py                # boot → notice dialog → menu → keypress (Playwright)
    └── abtest.py               # pixel-diff two builds (Playwright + PIL)
```

Upstream is pinned to commit `c6ac9417ff93ea957425b23ee87f1ed290663ebb` of
`AlexBoops/geometry-dash-webport` so builds are reproducible. Run `npm run assets:force` to
re-download, or bump `COMMIT` in `scripts/fetch-assets.mjs` when upstream updates.

## Credits / legal

* Geometry Dash © **RobTop Games** — unofficial fan port; not affiliated with or endorsed by RobTop.
  Do not sell or monetise it.
* Web port by **bog** ("lollipop"); maintenance, the JS glue and the 2.2 feature work by
  **AlexBoops** and contributors.
* This repo only adds packaging, the faster loader, the test suite and the deployment config.
