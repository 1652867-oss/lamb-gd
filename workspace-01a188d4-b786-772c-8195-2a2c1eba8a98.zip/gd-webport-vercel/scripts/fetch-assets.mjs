#!/usr/bin/env node
/**
 * Build step: fetches the Geometry Dash WASM assets, then makes them as small as
 * possible and writes a fully self-hosted, self-describing bundle into public/a/.
 *
 * Optimisations applied here:
 *
 *  1. WASM: the 69.8 MB engine binary is stored gzip-compressed (14.0 MB).
 *     The browser inflates it natively with DecompressionStream('gzip') and
 *     compiles it *straight from the stream* (no JS-side copy, no 70 MB blob).
 *
 *  2. DATA: the 314.5 MB resource package contains three copies of most
 *     textures/atlases (-uhd / -hd / plain). Only the -uhd bytes are ever used by
 *     the desktop-class renderer this port runs, so the duplicate byte ranges are
 *     collapsed: every filename still exists in the virtual filesystem, it simply
 *     points at the same shared bytes. Nothing can 404 and nothing is copied.
 *     Identical files are deduplicated by content hash as well.
 *
 *  3. The Emscripten glue's file table is rewritten to match the new layout, and
 *     its downloader is replaced with a streaming, parallel, progress-reporting one.
 *
 * Usage: node scripts/fetch-assets.mjs [--force]
 */

import { mkdir, writeFile, stat, readFile, unlink, readdir } from "node:fs/promises";
import { existsSync, statSync } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { gzipSync } from "node:zlib";

const COMMIT = "c6ac9417ff93ea957425b23ee87f1ed290663ebb";
const UPSTREAM = `https://cdn.jsdelivr.net/gh/AlexBoops/geometry-dash-webport@${COMMIT}/`;
const OUT = path.resolve(process.env.GD_OUT || "public/a");
const CACHE = path.resolve(".cache-assets"); // raw upstream parts, reused between builds
const FORCE = process.argv.includes("--force");
const LAYOUT_VERSION = 4; // bump to invalidate a previous public/a/

// Texture quality. The package ships every atlas at three resolutions; a build keeps
// only one set (the engine falls back automatically, it probes uhd -> hd -> ld -> plain).
//   uhd : default - the EXACT resolution set the engine asks for. Cocos2d-x picks a
//         sprite's contentScaleFactor from the filename suffix (-uhd = 4x), so a
//         build must ship the same suffix the engine requests or every sprite is
//         drawn at the wrong size. Do not substitute other resolutions ("hd"/"ld")
//         under uhd names: that is exactly what scrambled the UI once.
//   all : sanity/reference build - every resolution present (312 MB, does not fit
//         in Vercel's 100 MB static upload limit, and OOMs small machines).
//         uhd, 64 MB less to download, ~4x less VRAM  => the fastest option
//   uhd : maximum sharpness if you ever render above 1080p (~113 MB textures)
//   ld  : smallest/fastest still, visibly soft at 1080p
const QUALITY = (process.env.GD_QUALITY || "uhd").toLowerCase();   // uhd: the set the engine asks for
const QUALITY_ORDERS = {
  all: null,               // keep every resolution (reference build, for A/B testing)
  uhd: ["uhd", "hd", "ld", ""],   // what this port actually requests
};
if (!(QUALITY in QUALITY_ORDERS)) {
  throw new Error(`GD_QUALITY must be one of ${Object.keys(QUALITY_ORDERS).join(", ")} (got "${QUALITY}")`);
}
const QUALITY_ORDER = QUALITY_ORDERS[QUALITY];

/**
 * Cocos2d-x decides a sprite's contentScaleFactor from the *filename* suffix
 * (-uhd => 4, -hd => 2, plain => 1). Serving HD pixels under a -uhd name keeps
 * the atlas self-consistent but doubles every sprite on screen, which is exactly
 * the scrambled UI that shipped in v4. So when we narrow to one resolution we
 * DROP the other names from the package instead of aliasing them: the game then
 * only ever sees the set it actually asks for.
 */
const ALIAS_ACROSS_RES = false;

const PART = 19922944;          // output part size (kept identical to upstream chunking)
const WASM_PARTS = [19922944, 19922944, 19922944, 10060133];
const DATA_PARTS = Array(15).fill(19922944).concat([15656699]);
const MB = (n) => (n / 1048576).toFixed(1) + " MB";

/**
 * Assets are cached `immutable` for a year, so their URLs must change whenever
 * their bytes change. This tag is derived from everything that affects the
 * output and every asset URL carries it as ?v=<tag>. A page can therefore never
 * be paired with assets from a different build - which is exactly what produced
 * the "part 9: HTTP 404" after the UHD (12 parts) -> HD (8 parts) switch.
 */
function buildTag(parts) {
  return crypto
    .createHash("sha1")
    .update([LAYOUT_VERSION, COMMIT, QUALITY, ...parts].join("|"))
    .digest("hex")
    .slice(0, 12);
}

const sha1 = (s) => crypto.createHash("sha1").update(s).digest("hex");

/* ---------------------------------------------------------------- download */

async function download(url, dest, expected) {
  if (!FORCE && existsSync(dest) && (!expected || statSync(dest).size === expected)) return readFile(dest);
  let lastErr;
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const buf = Buffer.from(await res.arrayBuffer());
      if (expected && buf.length !== expected) throw new Error(`size ${buf.length} != ${expected}`);
      await mkdir(path.dirname(dest), { recursive: true });
      await writeFile(dest, buf);
      return buf;
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 300 * attempt));
    }
  }
  throw new Error(`${path.basename(dest)}: ${lastErr.message}`);
}

async function pullParts(prefix, sizes, label) {
  const out = [];
  for (let i = 0; i < sizes.length; i++) {
    const f = path.join(CACHE, `${prefix}.part${i + 1}`);
    out.push(await download(`${UPSTREAM}${prefix}.part${i + 1}`, f, sizes[i]));
    if ((i + 1) % 4 === 0 || i === sizes.length - 1) console.log(`[assets]   ${label} ${i + 1}/${sizes.length}`);
  }
  return Buffer.concat(out);
}

/* ------------------------------------------------------------ data packing */

const RES = /^(.*?)(?:-(uhd|hd|ld))?\.([a-z0-9]+)$/i;

/** group id + resolution suffix of a resource name */
function groupOf(name) {
  const m = RES.exec(name);
  if (!m) return null;
  return { key: m[1] + "\u0000" + m[3].toLowerCase(), suffix: m[2] ? m[2].toLowerCase() : "" };
}

/**
 * For every file, work out which file in its group actually gets shipped.
 * e.g. with QUALITY=hd, "GJ_Sheet-uhd.png" and "GJ_Sheet.png" both resolve to
 * "GJ_Sheet-hd.png", so all three names stay valid but the bytes exist once.
 */
function buildResolveMap(files) {
  const groups = new Map();
  for (const f of files) {
    const g = groupOf(f.filename);
    if (!g) continue;
    if (!groups.has(g.key)) groups.set(g.key, new Map());
    const byRes = groups.get(g.key);
    if (!byRes.has(g.suffix)) byRes.set(g.suffix, f.filename);
  }
  const resolve = new Map();
  const fallbacks = [];   // shipped files where the ideal resolution does not exist upstream
  if (!QUALITY_ORDER) {
    for (const f of files) resolve.set(f.filename, f.filename);
    return { resolve, fallbacks };
  }
  for (const f of files) {
    const g = groupOf(f.filename);
    if (!g) { resolve.set(f.filename, f.filename); continue; }
    const byRes = groups.get(g.key);
    let pick = null;
    for (const want of QUALITY_ORDER) {
      if (byRes.has(want)) { pick = byRes.get(want); break; }
    }
    if (!pick) pick = f.filename;
    if (ALIAS_ACROSS_RES) {
      resolve.set(f.filename, pick);
    } else {
      // only the chosen resolution's own name survives
      resolve.set(f.filename, pick === f.filename ? f.filename : null);
    }
  }
  return { resolve, fallbacks };
}

function repack(src, meta) {
  const files = meta.files;
  const { resolve, fallbacks } = buildResolveMap(files);
  const byName = new Map(files.map((f) => [f.filename, f]));
  const hashes = new Map();       // sha1 -> {start, end}
  const blocks = [];              // unique byte runs, in first-use order
  let cursor = 0;
  const newFiles = [];
  let droppedAlias = 0, droppedDup = 0;

  for (const f of files) {
    const target = resolve.has(f.filename) ? resolve.get(f.filename) : f.filename;
    if (target === null) continue; // resolution not shipped in this build
    const t = target === f.filename ? f : byName.get(target);
    const bytes = src.subarray(t.start, t.end);
    const hash = crypto.createHash("sha1").update(bytes).digest("base64");

    let range = hashes.get(hash);
    if (!range) {
      range = { start: cursor, end: cursor + bytes.length };
      hashes.set(hash, range);
      blocks.push(bytes);
      cursor += bytes.length;
    } else if (target === f.filename) {
      droppedDup += f.end - f.start;
    }
    if (target !== f.filename) droppedAlias += f.end - f.start;

    const entry = { filename: f.filename, start: range.start, end: range.end };
    if (f.audio) entry.audio = f.audio;
    newFiles.push(entry);
  }

  const out = Buffer.concat(blocks, cursor);
    // textures upstream only publishes below uhd: Cocos picks the scale factor from
  // the filename suffix, so these must ship exactly as named
  const lowerResTextures = newFiles.filter((f) => /-(hd|ld)\.(png|plist|fnt)$/i.test(f.filename)).length;
  return { out, meta: { ...meta, files: newFiles, remote_package_size: cursor, lowerResTextures }, droppedAlias, droppedDup };
}

/* -------------------------------------------------------- glue JS patching */

function findJsonObject(src, marker) {
  const at = src.indexOf(marker);
  if (at < 0) throw new Error("metadata object not found in glue");
  const start = at + marker.length;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < src.length; i++) {
    const c = src[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { start, end: i + 1 };
    }
  }
  throw new Error("unterminated metadata object");
}

function patchGlue(src, meta, tag) {
  // build stamp: the page compares this with the deployment it is talking to
  src = src.replace(
    "Module[\"expectedDataFileDownloads\"] ??= 0;",
    "Module[\"expectedDataFileDownloads\"] ??= 0;\nModule[\"__gdBuildTag\"] = " + JSON.stringify(tag) + ";"
  );

  // a) file table -> new (deduplicated) offsets
  const { start, end } = findJsonObject(src, "  loadPackage(");
  const json = JSON.stringify(meta);
  src = src.slice(0, start) + json + src.slice(end);

  // b) downloader -> delegate to the page's parallel streaming loader
  const dlStart = src.indexOf("async function fetchRemotePackage(packageName, packageSize) {");
  const dlEnd = src.indexOf("    var fetchedCallback;", dlStart);
  if (dlStart < 0 || dlEnd < 0) throw new Error("could not locate fetchRemotePackage");
  const replacement = `async function fetchRemotePackage(packageName, packageSize) {
      if (isNode) {
        var fsPromises = require("fs/promises");
        var contents = await fsPromises.readFile(packageName);
        return contents.buffer;
      }
      // The page (index.html) starts pulling the parts before this glue even runs.
      if (Module["gdDataPromise"]) return await Module["gdDataPromise"];
      // Fallback: sequential fetch of the part files.
      const total = packageSize || ${meta.remote_package_size};
      const PART_SIZE = ${PART};
      const parts = Math.ceil(total / PART_SIZE);
      const merged = new Uint8Array(total);
      let loaded = 0;
      for (let i = 0; i < parts; i++) {
        const res = await fetch(packageName + ".part" + (i + 1));
        if (!res.ok) throw new Error("part " + (i + 1) + ": HTTP " + res.status);
        const reader = res.body.pipeThrough(new DecompressionStream("gzip")).getReader();
        const base = i * PART_SIZE;
        let pos = 0;
        for (;;) {
          const r = await reader.read();
          if (r.done) break;
          merged.set(r.value, base + pos);
          pos += r.value.length;
          loaded += r.value.length;
        }
      }
      return merged.buffer;
    }
`;
  return src.slice(0, dlStart) + replacement + src.slice(dlEnd);
}


/* ---------------------------------------------------- runtime tuning patches */

/**
 * Patches that make the game itself faster on the user's machine:
 *
 *  1. WebGL context: force the discrete GPU ("high-performance") and a
 *     low-latency, non-preserved drawing buffer. `desynchronized` lets the
 *     compositor skip a queue hop, which measurably cuts input-to-photon
 *     latency; `powerPreference` stops laptops from rendering on the iGPU.
 *  2. Input polling: replace Array.shift() (O(n), allocates) on the per-frame
 *     hot path with a head index.
 *  3. WebAudio: ask for the "interactive" latency class so sfx/music do not sit
 *     in a deep output buffer.
 */
function tuneGlue(src) {
  let out = src;

  // 1. context attributes
  const ctxOld = 'var ctx = canvas.getContext("webgl2", webGLContextAttributes);';
  if (!out.includes(ctxOld)) throw new Error("webgl context creation not found");
  out = out.replace(ctxOld,
    'var ctx = canvas.getContext("webgl2", (function (a) {\n' +
    '      var o = {}; for (var k in a) o[k] = a[k];\n' +
    '      var t = Module.__gdGpuTuning || {};\n' +
    '      o.powerPreference = t.powerPreference || "high-performance";  /* prefer the dGPU */\n' +
    '      o.desynchronized = t.desynchronized === true;                 /* opt-in, ?dsync */\n' +
    '      o.preserveDrawingBuffer = false;                              /* no per-frame copy */\n' +
    '      o.failIfMajorPerformanceCaveat = false;\n' +
    '      if (t.antialias === false) o.antialias = false;              /* opt-in, ?noaa */\n' +
    '      if (Module.__gdNoLog !== 1) {}\n' +
    '      return o;\n' +
    '    })(webGLContextAttributes));');

  // 2. input queue: head index instead of shift()
  const pollOld = `function gd_js_mouse_poll(msg, wp, lp) {
  if (!Module.gdInputQueue || Module.gdInputQueue.length === 0) return 0;
  var e = Module.gdInputQueue.shift();
  HEAP32[msg >>> 2] = e[0];
  HEAP32[wp >>> 2] = e[1];
  HEAP32[lp >>> 2] = e[2];
  return 1;
}`;
  if (!out.includes(pollOld)) throw new Error("gd_js_mouse_poll not found");
  out = out.replace(pollOld, `function gd_js_mouse_poll(msg, wp, lp) {
  var q = Module.gdInputQueue;
  if (!q || q.length === 0) return 0;
  var h = Module.gdInputHead | 0;
  if (h >= q.length) { q.length = 0; h = 0; }
  var e = q[h];
  HEAP32[msg >>> 2] = e[0];
  HEAP32[wp >>> 2] = e[1];
  HEAP32[lp >>> 2] = e[2];
  h++;
  if (h >= q.length) { q.length = 0; h = 0; }
  Module.gdInputHead = h;
  return 1;
}`);

  // 3. frame pacing: zero-allocation, ?fps=N target, ?uncap for max FPS
  const yieldOld = `function __asyncjs__gd_js_yield_frame(target_ms) {
  return Asyncify.handleAsync(async () => {
    if (!Module.gdRafWatch) {
      Module.gdRafWatch = 1;
      Module.gdRafInterval = 1e3 / 60;
      var last = 0;
      var watch = function(t) {
        if (last) {
          var d = t - last;
          if (d > 2 && d < 100) Module.gdRafInterval = Module.gdRafInterval * .9 + d * .1;
        }
        last = t;
        requestAnimationFrame(watch);
      };
      requestAnimationFrame(watch);
      var mc = new MessageChannel;
      Module.gdFastQ = [];
      mc.port1.onmessage = function() {
        var q = Module.gdFastQ;
        Module.gdFastQ = [];
        for (var i = 0; i < q.length; ++i) q[i]();
      };
      Module.gdFastPort = mc.port2;
    }
    if (document.hidden) {
      await new Promise(function(res) {
        setTimeout(res, 50);
      });
    } else if (target_ms > 0 && target_ms < Module.gdRafInterval * .9) {
      await new Promise(function(res) {
        Module.gdFastQ.push(res);
        Module.gdFastPort.postMessage(0);
      });
    } else {
      await new Promise(function(res) {
        requestAnimationFrame(function() {
          res();
        });
      });
    }
  });
}`;
  if (!out.includes(yieldOld)) throw new Error("gd_js_yield_frame not found");
  out = out.replace(yieldOld, `/**
 * Frame pacer. One wake-up per frame, no allocation per frame.
 *
 *   default     wake on the next vsync (rAF): best frame pacing, no tearing.
 *               On a 144 Hz display this already yields ~144 fps.
 *   ?fps=N      pace to N frames per second (e.g. ?fps=90) - uses a timer when
 *               N is below the refresh rate, otherwise vsync.
 *   ?uncap      never wait for vsync: run the loop as fast as the machine can,
 *               for the highest possible frame counter. Costs CPU/battery and can
 *               tear, so it is opt-in.
 *
 * The vsync estimate is a slow-decaying average, clamped so a single late frame
 * (tab switch, GC, shader compile) cannot poison it.
 */
function __asyncjs__gd_js_yield_frame(target_ms) {
  return Asyncify.handleAsync(async () => {
    if (!Module.gdPace) {
      var P = Module.gdPace = {
        interval: 1e3 / 60,      // measured refresh interval (ms)
        last: 0,
        ticks: 0,
        target: 0,               // 0 = engine decides, >0 = forced frame budget
        uncap: false,
        wake: null,
        port: null
      };
      var tune = Module.__gdPacing || {};
      P.uncap = tune.uncap === true;
      P.target = +tune.target > 0 ? +tune.target : 0;

      var watch = function (t) {
        if (P.last) {
          var d = t - P.last;
          // ignore absurd gaps (tab switch, debugger) instead of averaging them in
          if (d > 2 && d < 100) {
            P.interval = P.interval * 0.9 + d * 0.1;
            if (P.interval < 2) P.interval = 2;
            if (P.interval > 100) P.interval = 100;
          }
        }
        P.last = t;
        P.ticks++;
        requestAnimationFrame(watch);
      };
      requestAnimationFrame(watch);

      // fast path: a MessageChannel message is delivered before paints, so the
      // loop can run without waiting for vsync. Single reusable slot.
      var mc = new MessageChannel;
      P.port = mc.port2;
      mc.port1.onmessage = function () {
        var w = P.wake;
        P.wake = null;
        if (w) w();
      };
      document.addEventListener("visibilitychange", function () {
        P.last = 0;   // refresh estimate is stale after being backgrounded
      });
    }

    var P = Module.gdPace;

    if (document.hidden) {
      await new Promise(function (res) { setTimeout(res, 50); });
      return;
    }

    if (P.uncap) {
      await new Promise(function (res) { P.wake = res; P.port.postMessage(0); });
      return;
    }

    // frame budget: explicit ?fps= wins, else the engine's own request
    var budget = P.target > 0 ? P.target : target_ms;

    if (budget > 0 && budget < P.interval * 0.9) {
      // target is faster than the display: don't wait for vsync, but still
      // release the JS stack so input/timers run
      await new Promise(function (res) { P.wake = res; P.port.postMessage(0); });
    } else {
      await new Promise(function (res) { requestAnimationFrame(res); });
    }
  });
}`);

  // 3b. expose the measured refresh rate + pacing mode to the page
  out = out.replace("__asyncjs__gd_js_yield_frame.sig = \"vd\";",
    "__asyncjs__gd_js_yield_frame.sig = \"vd\";\n" +
    "Module.__gdPacingInfo = function () {\n" +
    "  var P = Module.gdPace;\n" +
    "  if (!P) return null;\n" +
    "  return { interval: P.interval, hz: P.interval ? 1000 / P.interval : 0,\n" +
    "           tick: P.ticks, uncap: P.uncap, target: P.target };\n" +
    "};");

  // 3. audio latency class
  const acOld = "          this.ctx = new AC;";
  if (out.includes(acOld)) {
    out = out.replace(acOld,
      "          try { this.ctx = new AC({ latencyHint: \"interactive\" }); } catch (e) { this.ctx = new AC(); }");
  }

  return out;
}


/* ---------------------------------------------------- engine server patching */

/**
 * Point the GAME's own online traffic at our deployment.
 *
 * The server URLs are compiled into the engine image
 * (`/Resources/bin/GeometryDash.exe.img`, NUL-terminated C strings), so this edits
 * the game binary itself rather than wrapping it. Each
 *   https://www.boomlings.com/database/<endpoint>.php
 * becomes
 *   /api/gd/<endpoint>.php          (NUL-padded to the same byte length)
 * so the engine's HTTP layer (gd_http_start -> fetch) asks OUR origin, which
 * proxies to Boomlings. Same length in, same length out: the memory image and
 * every package offset stay valid, and there is nothing for the engine to notice.
 */
// capture the WHOLE nested path (accounts/loginGJAccount.php): stopping at the
// first segment would NUL-terminate the string early and break the endpoint
const ENGINE_SERVER_RE = /https:\/\/www\.boomlings\.com\/(?:database|databas)\/([A-Za-z0-9_./-]+\.php)/g;

function patchEngineServerUrls(buf) {
  const str = buf.toString("latin1");
  const hits = [...str.matchAll(ENGINE_SERVER_RE)];
  if (hits.length === 0) throw new Error("no boomlings endpoints found in the engine image (upstream changed?)");
  const patched = [];
  for (const m of hits) {
    const [full, endpoint] = m;
    const replacement = `/api/gd/${endpoint}`;   // endpoint keeps any sub-directory
    if (replacement.length > full.length) throw new Error(`proxy path longer than the original URL (${endpoint})`);
    const off = m.index;
    buf.write(replacement, off, "latin1");
    // NUL-fill the remainder so the C string ends exactly where the original did
    buf.fill(0, off + replacement.length, off + full.length);
    patched.push(endpoint);
  }
  return patched;
}

/** Reverse check used by tests: are there any boomlings database URLs left? */
function findUnpatchedServerUrls(buf) {
  return [...buf.toString("latin1").matchAll(ENGINE_SERVER_RE)].map((m) => m[0]);
}

/* ------------------------------------------------------------------- main */

async function main() {
  const t0 = Date.now();
  await mkdir(OUT, { recursive: true });
  await mkdir(CACHE, { recursive: true });

  const manifestPath = path.join(OUT, "manifest.json");
  if (!FORCE && existsSync(manifestPath)) {
    const m = JSON.parse(await readFile(manifestPath, "utf8"));
    if (m.v === LAYOUT_VERSION && m.commit === COMMIT) {
      console.log(`[assets] up to date (${m.parts} parts, ${MB(m.dataBytes)} data, v=${m.tag})`);
      return;
    }
  }

  console.log("[assets] fetching upstream sources ...");
  const glue = (await download(`${UPSTREAM}gd_web.js`, path.join(CACHE, "gd_web.js"))).toString("utf8");
  const wasm = await pullParts("gd_web.wasm", WASM_PARTS, "wasm");
  const data = await pullParts("gd_web.data", DATA_PARTS, "data");

  const { start, end } = findJsonObject(glue, "  loadPackage(");
  const meta = JSON.parse(glue.slice(start, end));
  if (meta.remote_package_size !== data.length) {
    throw new Error(`metadata size ${meta.remote_package_size} != data ${data.length}`);
  }

  console.log(`[assets] repacking ${MB(data.length)} package (${meta.files.length} entries) ...`);
  const t1 = Date.now();
  const { out, meta: newMeta, droppedAlias } = repack(data, meta);
  console.log(
    `[assets]   ${MB(data.length)} -> ${MB(out.length)} ` +
    `(-${((1 - out.length / data.length) * 100).toFixed(1)}%, ` +
    `saved ${MB(data.length - out.length)}) in ${((Date.now() - t1) / 1000).toFixed(1)}s`
  );
  console.log(`[assets]   redundant resolution copies: ${MB(droppedAlias)}`);

  // edit the game itself: its online endpoints now point at this deployment
  const serverEndpoints = patchEngineServerUrls(out);
  console.log(`[assets]   engine server endpoints -> /api/gd/ (${serverEndpoints.length} patched: ${serverEndpoints.length ? [...new Set(serverEndpoints)].slice(0, 4).join(", ") + (serverEndpoints.length > 4 ? ", ..." : "") : "-"})`);

  // write data parts (gzip'd - spritesheets/audio are already compressed, but the
  // plist/xml/txt payload still shrinks ~25%, and the browser inflates natively)
  const parts = Math.ceil(out.length / PART);
  let rawSum = 0, gzSum = 0;
  for (let i = 0; i < parts; i++) {
    const slice = out.subarray(i * PART, Math.min(out.length, (i + 1) * PART));
    const gz = gzipSync(slice, { level: 6 });
    rawSum += slice.length;
    gzSum += gz.length;
    await writeFile(path.join(OUT, `gd_web.data.part${i + 1}`), gz);
  }
  console.log(`[assets] data parts gzip: ${MB(rawSum)} -> ${MB(gzSum)} (-${((1 - gzSum / rawSum) * 100).toFixed(1)}%)`);

  // wasm: gzip, decompressed natively by the browser
  const t2 = Date.now();
  const wasmGz = gzipSync(wasm, { level: 9 });
  await writeFile(path.join(OUT, "gd_web.wasm.pack"), wasmGz);
  console.log(
    `[assets] wasm ${MB(wasm.length)} -> ${MB(wasmGz.length)} gz ` +
    `(-${((1 - wasmGz.length / wasm.length) * 100).toFixed(0)}%) in ${((Date.now() - t2) / 1000).toFixed(1)}s`
  );

  // Patched glue. The tag has to cover the glue's own bytes: /a/* is served
  // immutable and the glue carries the same stamp, so a glue-only change (runtime
  // tuning, bug fix) must change the URL or returning players keep the old engine
  // forever. Stamp with a placeholder, hash the result, then stamp for real.
  const PLAIN = "@@GD_BUILD_TAG@@";
  const stamped = (t) => tuneGlue(patchGlue(glue, newMeta, t));
  const glueHash = sha1(stamped(PLAIN));
  // The package bytes matter as much as their size: patching the engine image in
  // place (server endpoints) keeps the length identical, so a size-only tag would
  // hand returning players the OLD engine image and silently break online play.
  const dataHash = sha1(out);
  const tag = buildTag([out.length, wasmGz.length, parts, glueHash, dataHash]);
  const patched = stamped(tag);
  if (patched.includes(PLAIN)) throw new Error("build tag placeholder was not replaced");
  if (sha1(patched) === glueHash) throw new Error("glue hash is not sensitive to the tag");
  await writeFile(path.join(OUT, "gd_web.js"), patched);

  const manifest = {
    v: LAYOUT_VERSION,
    tag,
    glueHash,
    dataHash,
    commit: COMMIT,
    parts,
    partSize: PART,
    dataBytes: out.length,
    dataWireBytes: gzSum,
    dataGzip: true,
    quality: QUALITY,
    onlineEndpoints: [...new Set(serverEndpoints)].sort(),
    wasmBytes: wasm.length,
    wasmPackBytes: wasmGz.length,
    files: newMeta.files.length,
    // textures that only exist in a lower resolution upstream (Cocos scales those
    // per-sprite from the filename suffix, so shipping them as-is is correct)
    lowerResTextures: newMeta.lowerResTextures || 0,
  };
  await writeFile(manifestPath, JSON.stringify(manifest));

  // bake the manifest into the page so the downloads start with zero extra RTT
  const pagePath = path.resolve(process.env.GD_PAGE || "public/index.html");
  const page = await readFile(pagePath, "utf8");
  const inline = JSON.stringify({ v: manifest.v, tag, parts, partSize: PART, dataBytes: out.length, dataWireBytes: gzSum, dataGzip: true, quality: QUALITY, wasmPackBytes: wasmGz.length });
  const patchedPage = page.replace(/var GD_BUILD = \{[^}]*\};/, `var GD_BUILD = ${inline};`);
  if (patchedPage !== page) await writeFile(pagePath, patchedPage);

  // drop stale artifacts
  for (const f of await readdir(OUT)) {
    const keep =
      f === "gd_web.js" || f === "gd_web.wasm.pack" || f === "manifest.json" ||
      /^gd_web\.data\.part\d+$/.test(f);
    if (!keep) await unlink(path.join(OUT, f)).catch(() => {});
  }
  for (const f of await readdir(OUT)) {
    const m = /^gd_web\.data\.part(\d+)$/.exec(f);
    if (m && Number(m[1]) > parts) await unlink(path.join(OUT, f));
  }

  const wire = gzSum + wasmGz.length + patched.length;
  console.log(
    `[assets] done in ${((Date.now() - t0) / 1000).toFixed(1)}s - ` +
    `first load ships ${MB(wire)} (was ${MB(data.length + wasm.length + glue.length)}), ` +
    `${parts} parts, build tag ${tag}`
  );
}

main().catch((e) => {
  console.error("[assets] FAILED:", e.message);
  process.exit(1);
});
