/**
 * Geometry Dash online proxy - the piece that makes in-game level search work.
 *
 * The game's own endpoints are compiled into its image and have been rewritten at
 * build time from `https://www.boomlings.com/database/<endpoint>` to
 * `/api/gd/<endpoint>` (see patchEngineServerUrls in scripts/fetch-assets.mjs).
 * This module receives those requests and forwards them upstream.
 *
 * Why a server at all:
 *   * the game runs on our origin, and Boomlings sends no CORS headers
 *   * Boomlings rejects requests without a desktop-like User-Agent
 *   * responses can be cached at the edge, so repeat searches and level loads are
 *     instant and cost no upstream traffic
 *
 * Used by both `api/gd/[...path].js` (Vercel) and `scripts/serve.mjs` (local dev),
 * so what you test locally is exactly what runs in production.
 */

/** Endpoints that are safe to cache at the edge (public, read-only, no account state). */
const CACHEABLE = new Map([
  ["getGJLevels21.php", 30],
  ["downloadGJLevel22.php", 3600],
  ["getGJSongInfo.php", 3600],
  ["getGJMapPacks21.php", 300],
  ["getGJGauntlets21.php", 300],
  ["getGJLevelLists.php", 60],
  ["getGJUsers20.php", 30],
  ["getGJUserInfo20.php", 30],
  ["getGJScores20.php", 30],
  ["getGJTopArtists.php", 300],
  ["checkIfServerOnline.php", 10],
]);

/**
 * Anything that carries credentials, writes data or is account-scoped must never be
 * cached, and is only forwarded to the same endpoints the game asks for.
 */
const NEVER_CACHE_PREFIX = ["accounts", "upload", "delete", "rate", "suggest", "update",
  "block", "unblock", "accept", "reject", "request", "getSaveData", "login", "register"];

const MAX_BODY = 64 * 1024;         // level uploads are the only large payloads
const UA = "GeometryDash/2.2 (webport)";

/**
 * Public read-only fallback. Boomlings blocks a number of datacentre networks
 * (including this sandbox) with Cloudflare 1005. This relay is used only after
 * the deployment's own upstream fails, and only for anonymous public reads such
 * as level search/download. Account, write, and credential-bearing endpoints are
 * never sent to it. Set GD_PUBLIC_RELAY=off to disable, or point it at an owned
 * Cloudflare Worker ending in `?url=`.
 */
const DEFAULT_PUBLIC_RELAY = "https://boomlings.ivan-makarov12341.workers.dev/?url=";

/** Upstreams are tried in order; override with GD_UPSTREAM=a,b. */
function upstreams() {
  const raw = process.env.GD_UPSTREAM || "https://www.boomlings.com/database";
  return raw.split(",").map((s) => s.trim().replace(/\/+$/, "")).filter(Boolean);
}

function publicRelay() {
  const raw = process.env.GD_PUBLIC_RELAY;
  if (raw && /^(?:0|false|off|none)$/i.test(raw.trim())) return null;
  const base = (raw || DEFAULT_PUBLIC_RELAY).trim();
  // HTTP is accepted only for a loopback test relay; deployment relays require
  // HTTPS because requests include the game's public form secret.
  const allowed = /^https:\/\//i.test(base) || /^http:\/\/(?:127\.0\.0\.1|localhost)(?::\d+)?\//i.test(base);
  return allowed && base.includes("?url=") ? base : null;
}

function isPublicRead(endpoint) {
  return CACHEABLE.has(endpoint.split("/").pop());
}

function upstreamFailed(res, text) {
  // Cloudflare 1005 may arrive as the bare string or as an HTML denial page;
  // never hand that document to the game as though it were a level list.
  return res.status >= 400 || /error code:\s*1\d{3}|access denied|cloudflare/i.test(text);
}

/** `/api/gd/getGJLevels21.php`, `/api/gd/accounts/loginGJAccount.php`, `?ep=` */
export function resolveEndpoint(pathname, query) {
  let p = pathname || "";
  const apiIdx = p.indexOf("/api/gd");
  if (apiIdx >= 0) p = p.slice(apiIdx + "/api/gd".length);
  if (!p && query && query.ep) p = "/" + String(query.ep);
  p = p.split("?")[0].replace(/^\/+/, "");
  if (!p) return null;
  // no traversal, no scheme, no absolute URLs
  if (/\.\.|^https?:|^\/\/|\\/.test(p)) return null;
  if (!/^[A-Za-z0-9_\-./]+$/.test(p)) return null;
  if (p.split("/").some((seg) => seg === "." || seg === "")) return null;
  return p;
}

function cacheTag(endpoint) {
  const leaf = endpoint.split("/").pop();
  if (NEVER_CACHE_PREFIX.some((p) => endpoint.startsWith(p) || leaf.startsWith(p))) return null;
  const s = CACHEABLE.get(leaf);
  return s ? `public, s-maxage=${s}, stale-while-revalidate=${s * 4}` : null;
}

/**
 * Core proxy. Returns { status, headers, body } - no framework types, so both the
 * Vercel adapter and the tiny local server can use it.
 */
export async function proxyRequest({ method = "POST", pathname, query = {}, headers = {}, body = null }) {
  const endpoint = resolveEndpoint(pathname, query);
  if (!endpoint) {
    return { status: 404, headers: { "content-type": "text/plain" }, body: "unknown endpoint" };
  }
  if (method === "OPTIONS") {
    return { status: 204, headers: { "access-control-allow-origin": "*", "access-control-allow-methods": "GET, POST, OPTIONS", "access-control-allow-headers": "content-type", "access-control-max-age": "86400" }, body: "" };
  }
  if (method !== "POST" && method !== "GET") {
    return { status: 405, headers: { "content-type": "text/plain", allow: "GET, POST" }, body: "method not allowed" };
  }
  const buf = body ? Buffer.from(body) : null;
  if (buf && buf.length > MAX_BODY) {
    return { status: 413, headers: { "content-type": "text/plain" }, body: "request too large" };
  }

  const errors = [];
  const contentType = headers["content-type"] || "application/x-www-form-urlencoded";
  const request = async (url, label, viaRelay = false) => {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 12000);
      const res = await fetch(url, {
        method,
        headers: {
          "user-agent": UA,
          "accept": "*/*",
          ...(method === "POST" ? { "content-type": contentType } : {}),
        },
        body: method === "POST" ? buf : undefined,
        redirect: "follow",
        signal: ctrl.signal,
      }).finally(() => clearTimeout(timer));
      const text = await res.text();
      if (upstreamFailed(res, text)) {
        errors.push(`${label}: HTTP ${res.status} ${text.replace(/\s+/g, " ").slice(0, 80)}`);
        return null;
      }
      const cache = cacheTag(endpoint);
      return {
        status: res.status,
        headers: {
          "content-type": "text/plain; charset=utf-8",
          "cache-control": cache || "no-store",
          "x-gd-endpoint": endpoint,
          "x-gd-upstream": label,
          ...(viaRelay ? { "x-gd-relay": "public-read" } : {}),
        },
        body: text,
      };
    } catch (e) {
      errors.push(`${label}: ${e && (e.name === "AbortError" ? "timeout" : e.message || e)}`);
      return null;
    }
  };

  for (const base of upstreams()) {
    const url = method === "GET"
      ? `${base}/${endpoint}${query.qs ? "?" + query.qs : ""}`
      : `${base}/${endpoint}`;
    const out = await request(url, base);
    if (out) return out;
  }

  // A public relay is deliberately a final, read-only fallback. It makes level
  // search/download survive a Vercel/Cloudflare 1005 while keeping credentials
  // and all state-changing game calls on the deployment's own trusted route.
  const relay = publicRelay();
  if (relay && isPublicRead(endpoint)) {
    const target = `https://www.boomlings.com/database/${endpoint}${method === "GET" && query.qs ? "?" + query.qs : ""}`;
    const out = await request(relay + encodeURIComponent(target), relay, true);
    if (out) return out;
  }

  // Everything failed: hand the game a body it treats as "no data" (-1) and
  // expose enough diagnostics for a deployment owner to replace the relay.
  return {
    status: 502,
    headers: {
      "content-type": "text/plain; charset=utf-8",
      "cache-control": "no-store",
      "x-gd-errors": errors.join(" | ").slice(0, 400),
    },
    body: "-1",
  };
}

/** Health/diagnostic payload for `/api/gd/` with no endpoint. */
export function proxyInfo() {
  return {
    ok: true,
    upstreams: upstreams(),
    publicReadRelayEnabled: !!publicRelay(),
    cacheable: [...CACHEABLE.keys()],
  };
}
