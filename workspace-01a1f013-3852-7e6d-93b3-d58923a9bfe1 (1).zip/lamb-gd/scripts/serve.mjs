#!/usr/bin/env node
/**
 * Tiny static server that mimics the Vercel headers for local testing.
 *   node scripts/serve.mjs [port]
 */
import http from "node:http";
import { createReadStream, statSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { proxyRequest, proxyInfo, resolveEndpoint } from "../server/gd-proxy.mjs";

const ROOT = process.env.ROOT_DIR || path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const PORT = Number(process.argv[2] || process.env.PORT || 3000);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".wasm": "application/wasm",
  ".json": "application/json",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

/** Mirror of api/gd/[...path].js so local dev exercises the production proxy. */
async function handleGdApi(req, res, url) {
  const query = Object.fromEntries(url.searchParams.entries());
  query.qs = url.search.slice(1);

  if (!resolveEndpoint(url.pathname, query)) {
    res.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
    res.end(JSON.stringify(proxyInfo()));
    return;
  }

  let body = null;
  if (req.method === "POST") {
    // one byte past the limit is enough: the proxy answers 413 for anything bigger
    const chunks = [];
    let size = 0;
    for await (const c of req) {
      chunks.push(c);
      size += c.length;
      if (size > 64 * 1024) break;
    }
    body = Buffer.concat(chunks);
  }

  const out = await proxyRequest({
    method: req.method,
    pathname: url.pathname,
    query,
    headers: req.headers,
    body,
  });
  res.writeHead(out.status, out.headers);
  res.end(out.body);
}

const server = http.createServer((req, res) => {
  const parsed = new URL(req.url, "http://x");
  if (parsed.pathname === "/api/gd" || parsed.pathname.startsWith("/api/gd/")) {
    handleGdApi(req, res, parsed).catch((e) => {
      res.writeHead(502, { "content-type": "text/plain" });
      res.end("proxy error: " + (e && e.message));
    });
    return;
  }
  let urlPath = decodeURIComponent(parsed.pathname);
  if (urlPath === "/") urlPath = "/index.html";
  const file = path.join(ROOT, path.normalize(urlPath).replace(/^(\.\.[/\\])+/, ""));

  if (!existsSync(file) || !statSync(file).isFile()) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("404");
    return;
  }

  const stat = statSync(file);
  const ext = path.extname(file).toLowerCase();
  const headers = {
    "content-type": MIME[ext] || "application/octet-stream",
    "accept-ranges": "bytes",
    "access-control-allow-origin": "*",
    "cache-control": urlPath.startsWith("/a/")
      ? "public, max-age=31536000, immutable"
      : "public, max-age=0, must-revalidate",
  };

  // range support (the client resumes interrupted parts)
  const range = req.headers.range;
  if (range) {
    const m = /bytes=(\d+)-(\d*)/.exec(range);
    const start = Number(m[1]);
    const end = m[2] ? Number(m[2]) : stat.size - 1;
    headers["content-range"] = `bytes ${start}-${end}/${stat.size}`;
    headers["content-length"] = end - start + 1;
    res.writeHead(206, headers);
    createReadStream(file, { start, end }).pipe(res);
    return;
  }

  headers["content-length"] = stat.size;
  res.writeHead(200, headers);
  if (req.method === "HEAD") return res.end();
  createReadStream(file).pipe(res);
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`serving ${ROOT} on http://0.0.0.0:${PORT}`);
});
