#!/usr/bin/env node
/**
 * Build step: fetches the Geometry Dash WASM assets, then makes them as small as
 * possible and writes a fully self-hosted, self-describing bundle into public/a/.
 *
 * Optimisations applied here:
 *
 *  1. WASM: the 69.8 MB engine binary is stored gzip-compressed (14.0 MB).
 *     The browser inflates it natively with DecompressionStream('gzip') and
 *     compiles it *straight from the stream* (no JS-side copy, no 70 MB blob).
 *
 *  2. DATA: the 314.5 MB resource package contains three copies of most
 *     textures/atlases (-uhd / -hd / plain). Only the -uhd bytes are ever used by
 *     the desktop-class renderer this port runs, so the duplicate byte ranges are
 *     collapsed: every filename still exists in the virtual filesystem, it simply
 *     points at the same shared bytes. Nothing can 404 and nothing is copied.
 *     Identical files are deduplicated by content hash as well.
 *
 *  3. The Emscripten glue's file table is rewritten to match the new layout, and
 *     its downloader is replaced with a streaming, parallel, progress-reporting one.
 *
 * Usage: node scripts/fetch-assets.mjs [--force]
 */

import { mkdir, writeFile, stat, readFile, unlink, readdir } from "node:fs/promises";
import { existsSync, statSync } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { gzipSync } from "node:zlib";
import { fileURLToPath } from "node:url";

const COMMIT = "c6ac9417ff93ea957425b23ee87f1ed290663ebb";
const UPSTREAM = `https://cdn.jsdelivr.net/gh/AlexBoops/geometry-dash-webport@${COMMIT}/`;
const OUT = path.resolve(process.env.GD_OUT || "public/a");
const CACHE = path.resolve(".cache-assets"); // raw upstream parts, reused between builds
const PAGE = path.resolve(process.env.GD_PAGE || "public/index.html");
const FORCE = process.argv.includes("--force");
const LAYOUT_VERSION = 7; // bump to invalidate a previous public/a/

// Texture quality. The upstream package contains multiple filename-qualified
// texture sets. Cocos assigns a texture's contentScaleFactor from that suffix:
// -uhd means 4x, -hd means 2x, and no suffix means 1x. The native engine was
// built around the UHD resource lookup, so the safe default must retain the UHD
// files and their matching plist metadata. Selecting the HD-only table made
// nine-slice panels, icons, and text use incompatible logical scales.
//
// `uhd` is the correct/default game build. `hd` and `ld` are explicit opt-in
// experimental resource reductions only; they are never substituted under a
// different filename. `all` is a reference package containing every tier.
const QUALITY = (process.env.GD_QUALITY || "uhd").toLowerCase();
const QUALITY_ORDERS = {
  all: null,                         // keep every resolution (reference build)
  uhd: ["uhd", "hd", "ld", ""],       // sharpest / largest
  hd: ["hd", "ld", ""],               // default high-performance build
  ld: ["ld", ""],                     // maximum texture/RAM savings
};
if (!(QUALITY in QUALITY_ORDERS)) {
  throw new Error(`GD_QUALITY must be one of ${Object.keys(QUALITY_ORDERS).join(", ")} (got "${QUALITY}")`);
}
const QUALITY_ORDER = QUALITY_ORDERS[QUALITY];

/**
 * Cocos2d-x decides a sprite's contentScaleFactor from the *filename* suffix
 * (-uhd => 4, -hd => 2, plain => 1). Serving HD pixels under a -uhd name keeps
 * the atlas self-consistent but doubles every sprite on screen, which is exactly
 * the scrambled UI that shipped in v4. So when we narrow to one resolution we
 * DROP the other names from the package instead of aliasing them: the game then
 * only ever sees the set it actually asks for.
 */
const ALIAS_ACROSS_RES = false;

const PART = 19922944;          // output part size (kept identical to upstream chunking)
const WASM_PARTS = [19922944, 19922944, 19922944, 10060133];
const DATA_PARTS = Array(15).fill(19922944).concat([15656699]);
const MB = (n) => (n / 1048576).toFixed(1) + " MB";

/**
 * Assets are cached `immutable` for a year, so their URLs must change whenever
 * their bytes change. This tag is derived from everything that affects the
 * output and every asset URL carries it as ?v=<tag>. A page can therefore never
 * be paired with assets from a different build - which is exactly what produced
 * the "part 9: HTTP 404" after the UHD (12 parts) -> HD (8 parts) switch.
 */
function buildTag(parts) {
  return crypto
    .createHash("sha1")
    .update([LAYOUT_VERSION, COMMIT, QUALITY, ...parts].join("|"))
    .digest("hex")
    .slice(0, 12);
}

const sha1 = (s) => crypto.createHash("sha1").update(s).digest("hex");

/**
 * An artifact cache is only valid for the exact packer and page template that
 * created it.  The old cache guard looked at just commit/layout/quality, so a
 * glue-patcher edit could leave an immutable old gd_web.js deployed. Normalize
 * the generated GD_BUILD literal, then fingerprint the two source inputs.
 */
async function buildInputHash() {
  const [self, page] = await Promise.all([
    readFile(fileURLToPath(import.meta.url), "utf8"),
    readFile(PAGE, "utf8"),
  ]);
  const template = page.replace(/var GD_BUILD = \{[^}]*\};/, "var GD_BUILD = @@GENERATED@@;");
  return sha1(`packer=${self}\npage=${template}\nquality=${QUALITY}\nlayout=${LAYOUT_VERSION}`);
}

/* ---------------------------------------------------------------- download */

async function download(url, dest, expected) {
  if (!FORCE && existsSync(dest) && (!expected || statSync(dest).size === expected)) return readFile(dest);
  let lastErr;
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const buf = Buffer.from(await res.arrayBuffer());
      if (expected && buf.length !== expected) throw new Error(`size ${buf.length} != ${expected}`);
      await mkdir(path.dirname(dest), { recursive: true });
      await writeFile(dest, buf);
      return buf;
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 300 * attempt));
    }
  }
  throw new Error(`${path.basename(dest)}: ${lastErr.message}`);
}

async function pullParts(prefix, sizes, label) {
  const out = [];
  for (let i = 0; i < sizes.length; i++) {
    const f = path.join(CACHE, `${prefix}.part${i + 1}`);
    out.push(await download(`${UPSTREAM}${prefix}.part${i + 1}`, f, sizes[i]));
    if ((i + 1) % 4 === 0 || i === sizes.length - 1) console.log(`[assets]   ${label} ${i + 1}/${sizes.length}`);
  }
  return Buffer.concat(out);
}

/* ------------------------------------------------------------ data packing */

const RES = /^(.*?)(?:-(uhd|hd|ld))?\.([a-z0-9]+)$/i;

/** group id + resolution suffix of a resource name */
function groupOf(name) {
  const m = RES.exec(name);
  if (!m) return null;
  return { key: m[1] + "\u0000" + m[3].toLowerCase(), suffix: m[2] ? m[2].toLowerCase() : "" };
}

/**
 * For every file, work out which file in its group actually gets shipped.
 * e.g. with QUALITY=hd, "GJ_Sheet-uhd.png" and "GJ_Sheet.png" both resolve to
 * "GJ_Sheet-hd.png", so all three names stay valid but the bytes exist once.
 */
function buildResolveMap(files) {
  const groups = new Map();
  for (const f of files) {
    const g = groupOf(f.filename);
    if (!g) continue;
    if (!groups.has(g.key)) groups.set(g.key, new Map());
    const byRes = groups.get(g.key);
    if (!byRes.has(g.suffix)) byRes.set(g.suffix, f.filename);
  }
  const resolve = new Map();
  const fallbacks = [];   // shipped files where the ideal resolution does not exist upstream
  if (!QUALITY_ORDER) {
    for (const f of files) resolve.set(f.filename, f.filename);
    return { resolve, fallbacks };
  }
  for (const f of files) {
    const g = groupOf(f.filename);
    if (!g) { resolve.set(f.filename, f.filename); continue; }
    const byRes = groups.get(g.key);
    let pick = null;
    for (const want of QUALITY_ORDER) {
      if (byRes.has(want)) { pick = byRes.get(want); break; }
    }
    if (!pick) pick = f.filename;
    if (ALIAS_ACROSS_RES) {
      resolve.set(f.filename, pick);
    } else {
      // only the chosen resolution's own name survives
      resolve.set(f.filename, pick === f.filename ? f.filename : null);
    }
  }
  return { resolve, fallbacks };
}

function repack(src, meta) {
  const files = meta.files;
  const { resolve, fallbacks } = buildResolveMap(files);
  const byName = new Map(files.map((f) => [f.filename, f]));
  const hashes = new Map();       // sha1 -> {start, end}
  const blocks = [];              // unique byte runs, in first-use order
  let cursor = 0;
  const newFiles = [];
  let droppedAlias = 0, droppedDup = 0;

  for (const f of files) {
    const target = resolve.has(f.filename) ? resolve.get(f.filename) : f.filename;
    if (target === null) continue; // resolution not shipped in this build
    const t = target === f.filename ? f : byName.get(target);
    const bytes = src.subarray(t.start, t.end);
    const hash = crypto.createHash("sha1").update(bytes).digest("base64");

    let range = hashes.get(hash);
    if (!range) {
      range = { start: cursor, end: cursor + bytes.length };
      hashes.set(hash, range);
      blocks.push(bytes);
      cursor += bytes.length;
    } else if (target === f.filename) {
      droppedDup += f.end - f.start;
    }
    if (target !== f.filename) droppedAlias += f.end - f.start;

    const entry = { filename: f.filename, start: range.start, end: range.end };
    if (f.audio) entry.audio = f.audio;
    newFiles.push(entry);
  }

  const out = Buffer.concat(blocks, cursor);
    // textures upstream only publishes below uhd: Cocos picks the scale factor from
  // the filename suffix, so these must ship exactly as named
  const lowerResTextures = newFiles.filter((f) => /-(hd|ld)\.(png|plist|fnt)$/i.test(f.filename)).length;
  return { out, meta: { ...meta, files: newFiles, remote_package_size: cursor, lowerResTextures }, droppedAlias, droppedDup };
}

/* -------------------------------------------------------- glue JS patching */

function findJsonObject(src, marker) {
  const at = src.indexOf(marker);
  if (at < 0) throw new Error("metadata object not found in glue");
  const start = at + marker.length;
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < src.length; i++) {
    const c = src[i];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) return { start, end: i + 1 };
    }
  }
  throw new Error("unterminated metadata object");
}

function patchGlue(src, meta, tag) {
  // build stamp: the page compares this with the deployment it is talking to
  src = src.replace(
    "Module[\"expectedDataFileDownloads\"] ??= 0;",
    "Module[\"expectedDataFileDownloads\"] ??= 0;\nModule[\"__gdBuildTag\"] = " + JSON.stringify(tag) + ";"
  );

  // a) file table -> new (deduplicated) offsets
  const { start, end } = findJsonObject(src, "  loadPackage(");
  const json = JSON.stringify(meta);
  src = src.slice(0, start) + json + src.slice(end);

  // b) downloader -> delegate to the page's parallel streaming loader
  const dlStart = src.indexOf("async function fetchRemotePackage(packageName, packageSize) {");
  const dlEnd = src.indexOf("    var fetchedCallback;", dlStart);
  if (dlStart < 0 || dlEnd < 0) throw new Error("could not locate fetchRemotePackage");
  const replacement = `async function fetchRemotePackage(packageName, packageSize) {
      if (isNode) {
        var fsPromises = require("fs/promises");
        var contents = await fsPromises.readFile(packageName);
        return contents.buffer;
      }
      // The page (index.html) starts pulling the parts before this glue even runs.
      if (Module["gdDataPromise"]) return await Module["gdDataPromise"];
      // Fallback: sequential fetch of the part files.
      const total = packageSize || ${meta.remote_package_size};
      const PART_SIZE = ${PART};
      const parts = Math.ceil(total / PART_SIZE);
      const merged = new Uint8Array(total);
      let loaded = 0;
      for (let i = 0; i < parts; i++) {
        const res = await fetch(packageName + ".part" + (i + 1));
        if (!res.ok) throw new Error("part " + (i + 1) + ": HTTP " + res.status);
        const reader = res.body.pipeThrough(new DecompressionStream("gzip")).getReader();
        const base = i * PART_SIZE;
        let pos = 0;
        for (;;) {
          const r = await reader.read();
          if (r.done) break;
          merged.set(r.value, base + pos);
          pos += r.value.length;
          loaded += r.value.length;
        }
      }
      return merged.buffer;
    }
`;
  return src.slice(0, dlStart) + replacement + src.slice(dlEnd);
}


/* ---------------------------------------------------- runtime tuning patches */

/**
 * Patches that make the game itself faster on the user's machine:
 *
 *  1. WebGL context: force the discrete GPU ("high-performance") and a
 *     low-latency, non-preserved drawing buffer. `desynchronized` lets the
 *     compositor skip a queue hop, which measurably cuts input-to-photon
 *     latency; `powerPreference` stops laptops from rendering on the iGPU.
 *  2. Input polling: replace Array.shift() and per-event arrays with a fixed
 *     typed ring, so the per-frame hot path allocates nothing.
 *  3. WebAudio: ask for the "interactive" latency class so sfx/music do not sit
 *     in a deep output buffer.
 */
function tuneGlue(src) {
  let out = src;

  // 1. context attributes
  const ctxOld = 'var ctx = canvas.getContext("webgl2", webGLContextAttributes);';
  if (!out.includes(ctxOld)) throw new Error("webgl context creation not found");
  out = out.replace(ctxOld,
    'var ctx = canvas.getContext("webgl2", (function (a) {\n' +
    '      var o = {}; for (var k in a) o[k] = a[k];\n' +
    '      var t = Module.__gdGpuTuning || {};\n' +
    '      o.powerPreference = t.powerPreference || "high-performance";  /* prefer the dGPU */\n' +
    '      o.desynchronized = t.desynchronized === true;                 /* low-latency present */\n' +
    '      o.preserveDrawingBuffer = false;                              /* no per-frame copy */\n' +
    '      o.alpha = t.alpha === true;                                  /* opaque canvas = less compositing */\n' +
    '      o.premultipliedAlpha = false;\n' +
    '      o.failIfMajorPerformanceCaveat = false;\n' +
    '      if (t.antialias === false) o.antialias = false;              /* high-FPS default */\n' +
    '      if (Module.__gdNoLog !== 1) {}\n' +
    '      return o;\n' +
    '    })(webGLContextAttributes));');

  // 2. input ring: fixed typed storage instead of Array.shift() / event arrays.
  const pollOld = `function gd_js_mouse_poll(msg, wp, lp) {
  if (!Module.gdInputQueue || Module.gdInputQueue.length === 0) return 0;
  var e = Module.gdInputQueue.shift();
  HEAP32[msg >>> 2] = e[0];
  HEAP32[wp >>> 2] = e[1];
  HEAP32[lp >>> 2] = e[2];
  return 1;
}`;
  if (!out.includes(pollOld)) throw new Error("gd_js_mouse_poll not found");
  out = out.replace(pollOld, `function gd_js_mouse_poll(msg, wp, lp) {
  var n = Module.gdInputCount | 0;
  var ring = Module.gdInputRing;
  if (!ring || n <= 0) return 0;
  var mask = Module.gdInputMask | 0;
  var h = Module.gdInputHead & mask;
  var p = h * 3;
  HEAP32[msg >>> 2] = ring[p];
  HEAP32[wp >>> 2] = ring[p + 1];
  HEAP32[lp >>> 2] = ring[p + 2];
  Module.gdInputHead = (h + 1) & mask;
  Module.gdInputCount = n - 1;
  return 1;
}`);

  // 3. Default-framebuffer render scale. The binary is a fixed desktop port and
  // issues 1920x1080 viewport/scissor calls even when the HTML canvas is smaller.
  // Scale only framebuffer 0; FBO render targets must stay in their own texture
  // coordinates or post-processing/screenshot paths would be corrupted.
  const bindOld = `var _glBindFramebuffer = (target, framebuffer) => {
  GLctx.bindFramebuffer(target, GL.framebuffers[framebuffer]);
};`;
  if (!out.includes(bindOld)) throw new Error("glBindFramebuffer hook not found");
  out = out.replace(bindOld, `var _glBindFramebuffer = (target, framebuffer) => {
  // GL_FRAMEBUFFER or GL_DRAW_FRAMEBUFFER selects the target used by viewport.
  if (target === 36160 || target === 36009) Module.gdDrawFramebuffer = framebuffer | 0;
  GLctx.bindFramebuffer(target, GL.framebuffers[framebuffer]);
};`);
  const scissorOld = `var _glScissor = (x0, x1, x2, x3) => GLctx.scissor(x0, x1, x2, x3);`;
  if (!out.includes(scissorOld)) throw new Error("glScissor hook not found");
  out = out.replace(scissorOld, `var _glScissor = (x0, x1, x2, x3) => {
  var s = Module.__gdRenderScale || 1;
  if (s !== 1 && !Module.gdDrawFramebuffer) GLctx.scissor(Math.round(x0 * s), Math.round(x1 * s), Math.round(x2 * s), Math.round(x3 * s));
  else GLctx.scissor(x0, x1, x2, x3);
};`);
  const viewportOld = `var _glViewport = (x0, x1, x2, x3) => GLctx.viewport(x0, x1, x2, x3);`;
  if (!out.includes(viewportOld)) throw new Error("glViewport hook not found");
  out = out.replace(viewportOld, `var _glViewport = (x0, x1, x2, x3) => {
  var s = Module.__gdRenderScale || 1;
  if (s !== 1 && !Module.gdDrawFramebuffer) GLctx.viewport(Math.round(x0 * s), Math.round(x1 * s), Math.round(x2 * s), Math.round(x3 * s));
  else GLctx.viewport(x0, x1, x2, x3);
};`);

  // 4. Native Cocos client-array bridge. This build's native renderer submits
  // interleaved vertex structs through legacy OpenGL client arrays. WebGL has no
  // such API, so stock Emscripten uploaded the same overlapping native struct to
  // a temporary VBO once for *each* enabled attribute. The live engine profile
  // records tens of thousands of 96-byte uploads in ten seconds. Coalesce only
  // overlapping ranges with the same nonzero stride, upload their exact union
  // once, and give every attribute its original relative byte offset. Packed
  // arrays remain isolated unless they truly share their starting pointer.
  // This is a rendering-path equivalence patch: no visual feature, native draw,
  // ordering, blend state, texture tier, or quality setting is removed.
  const clientArraysOld = `  preDrawHandleClientVertexAttribBindings: count => {
    GL.resetBufferBinding = false;
    // TODO: initial pass to detect ranges we need to upload, might not need
    // an upload per attrib
    for (var i = 0; i < GL.currentContext.maxVertexAttribs; ++i) {
      var cb = GL.currentContext.clientBuffers[i];
      if (!cb.clientside || !cb.enabled) continue;
      GL.resetBufferBinding = true;
      var size = GL.calcBufLength(cb.size, cb.type, cb.stride, count);
      var buf = GL.getTempVertexBuffer(size);
      GLctx.bindBuffer(34962, buf);
      GLctx.bufferSubData(34962, 0, HEAPU8.subarray(cb.ptr >>> 0, cb.ptr + size >>> 0));
      cb.vertexAttribPointerAdaptor.call(GLctx, i, cb.size, cb.type, cb.normalized, cb.stride, 0);
    }
  },`;
  if (!out.includes(clientArraysOld)) throw new Error("client-array bridge hook not found");
  out = out.replace(clientArraysOld, `  preDrawHandleClientVertexAttribBindings: count => {
    GL.resetBufferBinding = false;
    var context = GL.currentContext;
    var max = context.maxVertexAttribs;
    // Lazily allocate fixed bookkeeping once per GL context, never per draw.
    var groupOf = context.gdClientGroupOf;
    if (!groupOf) {
      context.gdClientGroupOf = groupOf = new Int32Array(max);
      context.gdClientGroupStart = new Uint32Array(max);
      context.gdClientGroupEnd = new Uint32Array(max);
      context.gdClientGroupStride = new Int32Array(max);
      context.gdClientGroupUsed = new Int8Array(max);
    }
    var starts = context.gdClientGroupStart;
    var ends = context.gdClientGroupEnd;
    var strides = context.gdClientGroupStride;
    var used = context.gdClientGroupUsed;
    var groups = 0;

    // Partition enabled client attributes into overlapping interleaved ranges.
    for (var i = 0; i < max; ++i) {
      var cb = context.clientBuffers[i];
      groupOf[i] = -1;
      if (!cb.clientside || !cb.enabled) continue;
      GL.resetBufferBinding = true;
      var size = GL.calcBufLength(cb.size, cb.type, cb.stride, count);
      var start = cb.ptr >>> 0;
      var end = start + size;
      var g = -1;
      for (var j = 0; j < groups; ++j) {
        if (!used[j]) continue;
        if ((cb.stride > 0 && strides[j] === cb.stride && start <= ends[j] && end >= starts[j]) ||
            (cb.stride === 0 && start === starts[j])) { g = j; break; }
      }
      if (g < 0) {
        g = groups++;
        used[g] = 1;
        starts[g] = start;
        ends[g] = end;
        strides[g] = cb.stride;
      } else {
        if (start < starts[g]) starts[g] = start;
        if (end > ends[g]) ends[g] = end;
        // One newly-expanded interval can bridge two earlier groups. Merge their
        // memberships before upload without allocating an intermediate list.
        if (cb.stride > 0) for (var h = g + 1; h < groups; ++h) {
          if (used[h] && strides[h] === cb.stride && starts[g] <= ends[h] && ends[g] >= starts[h]) {
            if (starts[h] < starts[g]) starts[g] = starts[h];
            if (ends[h] > ends[g]) ends[g] = ends[h];
            for (var q = 0; q < i; ++q) if (groupOf[q] === h) groupOf[q] = g;
            used[h] = 0;
          }
        }
      }
      groupOf[i] = g;
    }

    // One VBO upload per group, then recreate every original attribute pointer
    // at its byte offset inside that VBO.
    for (var g = 0; g < groups; ++g) {
      if (!used[g]) continue;
      var base = starts[g] >>> 0;
      var bytes = (ends[g] - starts[g]) >>> 0;
      var buf = GL.getTempVertexBuffer(bytes);
      GLctx.bindBuffer(34962, buf);
      GLctx.bufferSubData(34962, 0, HEAPU8.subarray(base, base + bytes));
      for (var i = 0; i < max; ++i) {
        if (groupOf[i] !== g) continue;
        var attr = context.clientBuffers[i];
        attr.vertexAttribPointerAdaptor.call(GLctx, i, attr.size, attr.type, attr.normalized,
                                             attr.stride, (attr.ptr - base) >>> 0);
      }
    }
  },`);

  // 4. Online-read browser fallback. The engine first calls its same-origin
  // Vercel route. If that route is missing, blocked, or returns an HTTP failure,
  // retry only anonymous public level endpoints through the CORS-enabled relay.
  // Login, account, upload, rating, and all other stateful endpoints can never
  // take this path.
  const httpFetchOld = `  fetch(UTF8ToString(proxy), opts).then(function(r) {`;
  if (!out.includes(httpFetchOld)) throw new Error("gd_http_start fetch hook not found");
  out = out.replace(httpFetchOld, `  var requestURL = UTF8ToString(proxy);
  var gdFetch = fetch(requestURL, opts);
  var gdPublicEndpoint = /^\\/api\\/gd\\/(getGJLevels21|downloadGJLevel22|getGJSongInfo|getGJMapPacks21|getGJGauntlets21|getGJLevelLists|getGJUsers20|getGJUserInfo20|getGJScores20|getGJTopArtists|checkIfServerOnline)\\.php$/.exec(requestURL);
  if (gdPublicEndpoint) {
    var gdRelayURL = "https://boomlings.ivan-makarov12341.workers.dev/?url=" +
      encodeURIComponent("https://www.boomlings.com/database/" + gdPublicEndpoint[1] + ".php");
    var gdTryRelay = function () { return fetch(gdRelayURL, opts); };
    gdFetch = gdFetch.then(function (r) {
      return r && r.status < 400 ? r : gdTryRelay();
    }, gdTryRelay);
  }
  gdFetch.then(function(r) {`);

  // 5. Platformer compatibility. 2.2 platformers carry field 31=1 in their
  // downloaded level envelope. Their player/camera update path is timing-sensitive
  // in this Windows-to-WASM port, so stop the default uncapped simulation before
  // the level opens. Rendering remains at the selected framebuffer; only the
  // update wake-up returns to rAF. `?platformerfast` or an explicit `?fps=` keeps
  // the high-FPS behavior for users who knowingly prefer it.
  const httpDoneOld = `    g.done = 1;
    console.log("[http] done id=" + id + " status=" + g.status + " bytes=" + g.body.length);`;
  if (!out.includes(httpDoneOld)) throw new Error("gd_http_start completion hook not found");
  out = out.replace(httpDoneOld, `    if (/\\/api\\/gd\\/downloadGJLevel22\\.php$/.test(requestURL) &&
        !(typeof location !== "undefined" && /[?&](?:platformerfast|fps=)/.test(location.search))) {
      // Search raw bytes rather than decoding a potentially multi-megabyte level.
      // The compressed level data itself is base64 and cannot contain ':' fields.
      for (var pi = 0; pi + 5 < g.body.length; ++pi) {
        if (g.body[pi] === 58 && g.body[pi + 1] === 51 && g.body[pi + 2] === 49 &&
            g.body[pi + 3] === 58 && g.body[pi + 4] === 49 && g.body[pi + 5] === 58) {
          Module.__gdPlatformerActive = 1;
          if (Module.__gdPacing) Module.__gdPacing.uncap = false;
          if (Module.gdPace) Module.gdPace.uncap = false;
          break;
        }
      }
    }
    g.done = 1;
    console.log("[http] done id=" + id + " status=" + g.status + " bytes=" + g.body.length);`);

  // 6. frame pacing: zero-allocation, ?fps=N target, ?uncap for max FPS
  const yieldOld = `function __asyncjs__gd_js_yield_frame(target_ms) {
  return Asyncify.handleAsync(async () => {
    if (!Module.gdRafWatch) {
      Module.gdRafWatch = 1;
      Module.gdRafInterval = 1e3 / 60;
      var last = 0;
      var watch = function(t) {
        if (last) {
          var d = t - last;
          if (d > 2 && d < 100) Module.gdRafInterval = Module.gdRafInterval * .9 + d * .1;
        }
        last = t;
        requestAnimationFrame(watch);
      };
      requestAnimationFrame(watch);
      var mc = new MessageChannel;
      Module.gdFastQ = [];
      mc.port1.onmessage = function() {
        var q = Module.gdFastQ;
        Module.gdFastQ = [];
        for (var i = 0; i < q.length; ++i) q[i]();
      };
      Module.gdFastPort = mc.port2;
    }
    if (document.hidden) {
      await new Promise(function(res) {
        setTimeout(res, 50);
      });
    } else if (target_ms > 0 && target_ms < Module.gdRafInterval * .9) {
      await new Promise(function(res) {
        Module.gdFastQ.push(res);
        Module.gdFastPort.postMessage(0);
      });
    } else {
      await new Promise(function(res) {
        requestAnimationFrame(function() {
          res();
        });
      });
    }
  });
}`;
  if (!out.includes(yieldOld)) throw new Error("gd_js_yield_frame not found");
  out = out.replace(yieldOld, `/**
 * Frame pacer. One wake-up per frame, no allocation per frame.
 *
 *   default     wake on the next vsync (rAF): best frame pacing, no tearing.
 *               On a 144 Hz display this already yields ~144 fps.
 *   ?fps=N      pace to N frames per second (e.g. ?fps=90) - uses a timer when
 *               N is below the refresh rate, otherwise vsync.
 *   ?uncap      never wait for vsync: run the loop as fast as the machine can,
 *               for the highest possible frame counter. Costs CPU/battery and can
 *               tear, so it is opt-in.
 *
 * The vsync estimate is a slow-decaying average, clamped so a single late frame
 * (tab switch, GC, shader compile) cannot poison it.
 */
function __asyncjs__gd_js_yield_frame(target_ms) {
  return Asyncify.handleAsync(async () => {
    if (!Module.gdPace) {
      var P = Module.gdPace = {
        interval: 1e3 / 60,      // measured refresh interval (ms)
        last: 0,
        ticks: 0,
        target: 0,               // 0 = engine decides, >0 = forced frame budget
        uncap: false,
        wake: null,
        port: null
      };
      var tune = Module.__gdPacing || {};
      P.uncap = tune.uncap === true;
      P.target = +tune.target > 0 ? +tune.target : 0;

      var watch = function (t) {
        if (P.last) {
          var d = t - P.last;
          // ignore absurd gaps (tab switch, debugger) instead of averaging them in
          if (d > 2 && d < 100) {
            P.interval = P.interval * 0.9 + d * 0.1;
            if (P.interval < 2) P.interval = 2;
            if (P.interval > 100) P.interval = 100;
          }
        }
        P.last = t;
        P.ticks++;
        requestAnimationFrame(watch);
      };
      requestAnimationFrame(watch);

      // fast path: a MessageChannel message is delivered before paints, so the
      // loop can run without waiting for vsync. Single reusable slot.
      var mc = new MessageChannel;
      P.port = mc.port2;
      mc.port1.onmessage = function () {
        var w = P.wake;
        P.wake = null;
        if (w) w();
      };
      document.addEventListener("visibilitychange", function () {
        P.last = 0;   // refresh estimate is stale after being backgrounded
      });
    }

    var P = Module.gdPace;

    if (document.hidden) {
      await new Promise(function (res) { setTimeout(res, 50); });
      return;
    }

    if (P.uncap) {
      await new Promise(function (res) { P.wake = res; P.port.postMessage(0); });
      return;
    }

    // frame budget: explicit ?fps= wins, else the engine's own request
    var budget = P.target > 0 ? P.target : target_ms;

    if (budget > 0 && budget < P.interval * 0.9) {
      // target is faster than the display: don't wait for vsync, but still
      // release the JS stack so input/timers run
      await new Promise(function (res) { P.wake = res; P.port.postMessage(0); });
    } else {
      await new Promise(function (res) { requestAnimationFrame(res); });
    }
  });
}`);

  // 4b. expose the measured refresh rate + pacing mode to the page
  out = out.replace("__asyncjs__gd_js_yield_frame.sig = \"vd\";",
    "__asyncjs__gd_js_yield_frame.sig = \"vd\";\n" +
    "Module.__gdPacingInfo = function () {\n" +
    "  var P = Module.gdPace;\n" +
    "  if (!P) return null;\n" +
    "  return { interval: P.interval, hz: P.interval ? 1000 / P.interval : 0,\n" +
    "           tick: P.ticks, uncap: P.uncap, target: P.target };\n" +
    "};");

  // 5. audio latency class
  const acOld = "          this.ctx = new AC;";
  if (out.includes(acOld)) {
    out = out.replace(acOld,
      "          try { this.ctx = new AC({ latencyHint: \"interactive\" }); } catch (e) { this.ctx = new AC(); }");
  }

  return out;
}


/* ---------------------------------------------------- engine server patching */

/**
 * Point the GAME's own online traffic at our deployment.
 *
 * The server URLs are compiled into the engine image
 * (`/Resources/bin/GeometryDash.exe.img`, NUL-terminated C strings), so this edits
 * the game binary itself rather than wrapping it. Each
 *   https://www.boomlings.com/database/<endpoint>.php
 * becomes
 *   /api/gd/<endpoint>.php          (NUL-padded to the same byte length)
 * so the engine's HTTP layer (gd_http_start -> fetch) asks OUR origin, which
 * proxies to Boomlings. Same length in, same length out: the memory image and
 * every package offset stay valid, and there is nothing for the engine to notice.
 */
// capture the WHOLE nested path (accounts/loginGJAccount.php): stopping at the
// first segment would NUL-terminate the string early and break the endpoint
const ENGINE_SERVER_RE = /https:\/\/www\.boomlings\.com\/(?:database|databas)\/([A-Za-z0-9_./-]+\.php)/g;

function patchEngineServerUrls(buf) {
  const str = buf.toString("latin1");
  const hits = [...str.matchAll(ENGINE_SERVER_RE)];
  if (hits.length === 0) throw new Error("no boomlings endpoints found in the engine image (upstream changed?)");
  const patched = [];
  for (const m of hits) {
    const [full, endpoint] = m;
    const replacement = `/api/gd/${endpoint}`;   // endpoint keeps any sub-directory
    if (replacement.length > full.length) throw new Error(`proxy path longer than the original URL (${endpoint})`);
    const off = m.index;
    buf.write(replacement, off, "latin1");
    // NUL-fill the remainder so the C string ends exactly where the original did
    buf.fill(0, off + replacement.length, off + full.length);
    patched.push(endpoint);
  }
  return patched;
}

/** Reverse check used by tests: are there any boomlings database URLs left? */
function findUnpatchedServerUrls(buf) {
  return [...buf.toString("latin1").matchAll(ENGINE_SERVER_RE)].map((m) => m[0]);
}

/* ------------------------------------------------------------------- main */

async function main() {
  const t0 = Date.now();
  await mkdir(OUT, { recursive: true });
  await mkdir(CACHE, { recursive: true });

  const manifestPath = path.join(OUT, "manifest.json");
  const inputHash = await buildInputHash();
  if (!FORCE && existsSync(manifestPath)) {
    const m = JSON.parse(await readFile(manifestPath, "utf8"));
    if (m.v === LAYOUT_VERSION && m.commit === COMMIT && m.quality === QUALITY && m.inputHash === inputHash) {
      console.log(`[assets] up to date (${m.parts} parts, ${MB(m.dataBytes)} data, v=${m.tag})`);
      return;
    }
  }

  console.log("[assets] fetching upstream sources ...");
  const glue = (await download(`${UPSTREAM}gd_web.js`, path.join(CACHE, "gd_web.js"))).toString("utf8");
  const wasm = await pullParts("gd_web.wasm", WASM_PARTS, "wasm");
  // Kept mutable so the 300 MB upstream source package can be released before
  // compressing the engine. This matters for the UI-correct UHD build on small
  // CI/Vercel build machines.
  let data = await pullParts("gd_web.data", DATA_PARTS, "data");

  const { start, end } = findJsonObject(glue, "  loadPackage(");
  const meta = JSON.parse(glue.slice(start, end));
  if (meta.remote_package_size !== data.length) {
    throw new Error(`metadata size ${meta.remote_package_size} != data ${data.length}`);
  }
  const sourceDataBytes = data.length;

  console.log(`[assets] repacking ${MB(data.length)} package (${meta.files.length} entries) ...`);
  const t1 = Date.now();
  const repacked = repack(data, meta);
  let out = repacked.out;
  const { meta: newMeta, droppedAlias } = repacked;
  console.log(
    `[assets]   ${MB(data.length)} -> ${MB(out.length)} ` +
    `(-${((1 - out.length / data.length) * 100).toFixed(1)}%, ` +
    `saved ${MB(data.length - out.length)}) in ${((Date.now() - t1) / 1000).toFixed(1)}s`
  );
  console.log(`[assets]   redundant resolution copies: ${MB(droppedAlias)}`);

  // Edit the game itself: its online endpoints now point at this deployment.
  // The hash must be taken after this mutation, before the large package buffer
  // is released below.
  const serverEndpoints = patchEngineServerUrls(out);
  const dataHash = sha1(out);
  const dataBytes = out.length;
  console.log(`[assets]   engine server endpoints -> /api/gd/ (${serverEndpoints.length} patched: ${serverEndpoints.length ? [...new Set(serverEndpoints)].slice(0, 4).join(", ") + (serverEndpoints.length > 4 ? ", ..." : "") : "-"})`);

  // write data parts (gzip'd - spritesheets/audio are already compressed, but the
  // plist/xml/txt payload still shrinks ~25%, and the browser inflates natively)
  const parts = Math.ceil(out.length / PART);
  let rawSum = 0, gzSum = 0;
  for (let i = 0; i < parts; i++) {
    const slice = out.subarray(i * PART, Math.min(out.length, (i + 1) * PART));
    const gz = gzipSync(slice, { level: 6 });
    rawSum += slice.length;
    gzSum += gz.length;
    await writeFile(path.join(OUT, `gd_web.data.part${i + 1}`), gz);
  }
  console.log(`[assets] data parts gzip: ${MB(rawSum)} -> ${MB(gzSum)} (-${((1 - gzSum / rawSum) * 100).toFixed(1)}%)`);

  // Nothing downstream needs either 300 MB source or the repacked byte buffer.
  // Drop both references before the CPU/memory-heavy WASM gzip step.
  data = null;
  out = null;
  repacked.out = null;

  // wasm: gzip, decompressed natively by the browser
  const t2 = Date.now();
  const wasmGz = gzipSync(wasm, { level: 9 });
  await writeFile(path.join(OUT, "gd_web.wasm.pack"), wasmGz);
  console.log(
    `[assets] wasm ${MB(wasm.length)} -> ${MB(wasmGz.length)} gz ` +
    `(-${((1 - wasmGz.length / wasm.length) * 100).toFixed(0)}%) in ${((Date.now() - t2) / 1000).toFixed(1)}s`
  );

  // Patched glue. The tag has to cover the glue's own bytes: /a/* is served
  // immutable and the glue carries the same stamp, so a glue-only change (runtime
  // tuning, bug fix) must change the URL or returning players keep the old engine
  // forever. Stamp with a placeholder, hash the result, then stamp for real.
  const PLAIN = "@@GD_BUILD_TAG@@";
  const stamped = (t) => tuneGlue(patchGlue(glue, newMeta, t));
  const glueHash = sha1(stamped(PLAIN));
  // The package bytes matter as much as their size: patching the engine image in
  // place (server endpoints) keeps the length identical, so a size-only tag would
  // hand returning players the OLD engine image and silently break online play.
  const tag = buildTag([dataBytes, wasmGz.length, parts, glueHash, dataHash]);
  const patched = stamped(tag);
  if (patched.includes(PLAIN)) throw new Error("build tag placeholder was not replaced");
  if (sha1(patched) === glueHash) throw new Error("glue hash is not sensitive to the tag");
  await writeFile(path.join(OUT, "gd_web.js"), patched);

  const manifest = {
    v: LAYOUT_VERSION,
    tag,
    glueHash,
    dataHash,
    inputHash,
    commit: COMMIT,
    parts,
    partSize: PART,
    dataBytes,
    dataWireBytes: gzSum,
    dataGzip: true,
    quality: QUALITY,
    onlineEndpoints: [...new Set(serverEndpoints)].sort(),
    wasmBytes: wasm.length,
    wasmPackBytes: wasmGz.length,
    files: newMeta.files.length,
    // textures that only exist in a lower resolution upstream (Cocos scales those
    // per-sprite from the filename suffix, so shipping them as-is is correct)
    lowerResTextures: newMeta.lowerResTextures || 0,
  };
  await writeFile(manifestPath, JSON.stringify(manifest));

  // bake the manifest into the page so the downloads start with zero extra RTT
  const pagePath = PAGE;
  const page = await readFile(pagePath, "utf8");
  const inline = JSON.stringify({ v: manifest.v, tag, parts, partSize: PART, dataBytes, dataWireBytes: gzSum, dataGzip: true, quality: QUALITY, wasmPackBytes: wasmGz.length });
  const patchedPage = page.replace(/var GD_BUILD = \{[^}]*\};/, `var GD_BUILD = ${inline};`);
  if (patchedPage !== page) await writeFile(pagePath, patchedPage);

  // drop stale artifacts
  for (const f of await readdir(OUT)) {
    const keep =
      f === "gd_web.js" || f === "gd_web.wasm.pack" || f === "manifest.json" ||
      /^gd_web\.data\.part\d+$/.test(f);
    if (!keep) await unlink(path.join(OUT, f)).catch(() => {});
  }
  for (const f of await readdir(OUT)) {
    const m = /^gd_web\.data\.part(\d+)$/.exec(f);
    if (m && Number(m[1]) > parts) await unlink(path.join(OUT, f));
  }

  const wire = gzSum + wasmGz.length + patched.length;
  console.log(
    `[assets] done in ${((Date.now() - t0) / 1000).toFixed(1)}s - ` +
    `first load ships ${MB(wire)} (was ${MB(sourceDataBytes + wasm.length + glue.length)}), ` +
    `${parts} parts, build tag ${tag}`
  );
}

main().catch((e) => {
  console.error("[assets] FAILED:", e.message);
  process.exit(1);
});
