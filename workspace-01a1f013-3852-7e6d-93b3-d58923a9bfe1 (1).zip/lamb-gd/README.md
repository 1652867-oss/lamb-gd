# Geometry Dash — WASM web port (Vercel-ready)

A self-contained, self-hosted build of the **Geometry Dash web port** (the Cocos2d-x → WebAssembly
port by **bog / "lollipop"**, kept current by *AlexBoops*), tuned for fast loading and smooth
runtime, packaged so it deploys to **Vercel** as-is.

The whole site *is* the game: one page, one canvas, fullscreen on first click — no separate
launcher, analytics, or external CDN calls. Its only server component is the same-origin online-levels proxy described below.

> **This build edits the game, not just the page.** Two things are patched inside the shipped
> engine at build time: its online server URLs (so level search/download go through this
> deployment — see *Online levels*) and its frame pacer / GL context attributes (runtime
> tuning). Everything is verified by `npm test`; nothing is patched by guessing.

> **Correctness first.** Cocos2d-x derives a texture's `contentScaleFactor` from its
> filename suffix (`-uhd` = 4, `-hd` = 2, no suffix = 1). The native web-port renderer expects
> the UHD resource lookup. An HD-only package caused incompatible nine-slice panels, icons, and
> labels — visually fragmented UI with undersized buttons. The default is therefore the complete
> matching **UHD** tier. No tier is ever renamed or aliased under another tier's filename.

---

## Online levels (the game's own servers, proxied by you)

Searching for a demon or any level by name, browsing the level lists, downloading a
level and playing it — all of that is the **game's own online feature**, and it works
here because the game now talks to *this deployment* instead of Boomlings.

**It is not a mod or an overlay. The game binary is edited at build time.** The server
URLs are compiled into the engine image (`/Resources/bin/GeometryDash.exe.img`,
NUL-terminated C strings), and `scripts/fetch-assets.mjs` rewrites each one in place:

```
https://www.boomlings.com/database/getGJLevels21.php   ->   /api/gd/getGJLevels21.php
https://www.boomlings.com/database/downloadGJLevel22.php -> /api/gd/downloadGJLevel22.php
https://www.boomlings.com/database/accounts/loginGJAccount.php -> /api/gd/accounts/loginGJAccount.php
... 60 endpoints in total, including the "databas/" typo the original build ships
```

The replacement is **length-preserving** (padded with NULs), so the memory image and
every package offset stay byte-identical and the engine notices nothing. Verified: zero
`boomlings.com/database` URLs survive in the shipped package, and the game's own HTTP
hook (`gd_http_start`) is proven to issue the `/api/gd/...` URL by test.

Then `server/gd-proxy.mjs` (used by both `api/gd/[...path].js` on Vercel and
`scripts/serve.mjs` locally) forwards those requests upstream:

| What it does | Why |
|---|---|
| forwards the body **verbatim** (including GD's `secret`) | Boomlings validates it; nothing is rewritten |
| sets a normal `User-Agent` | Boomlings/Cloudflare reject bot-like requests |
| **edge-caches public reads** — search `s-maxage=30`, level download `s-maxage=3600` | repeat searches and level loads are instant and cost no upstream traffic |
| never caches account/write endpoints (`accounts/*`, `upload*`, `rate*`, …) | credentials and mutations must not leak between players |
| rejects traversal, absolute URLs, unknown methods, bodies > 64 KB | it is a public proxy; it only speaks the game's own endpoint names |
| fails over across `GD_UPSTREAM=a,b,c` and returns `-1` if all are down | the game shows its own "no connection" instead of hanging |

After boot the page also **warms** two endpoints in the background, so the first time you
open Online Levels the data is already hot.

### If the upstream refuses your deployment

Boomlings sits behind Cloudflare, which bans whole datacenter ASNs (`error code: 1005`).
This sandbox is one of them, so the proxy's failover and error reporting are what I could
verify live here (against a stub upstream, end to end). If the deployment's egress is blocked too, the proxy now retries **anonymous public reads**
(level search, quick-search lists, level downloads, public profiles, songs, packs and gauntlets)
through a public Cloudflare relay. It is used only after the normal upstream fails. The generated
browser HTTP bridge has the same public-read retry, so a missing or failed Vercel function cannot
turn a level search into an empty list. Account, write, and credential-bearing calls are **never**
sent through either fallback.

For durable production hosting, deploy the included `workers/gd-public-read-relay.js` as your
own Cloudflare Worker and set this Vercel environment variable:

```bash
GD_PUBLIC_RELAY="https://your-worker.workers.dev/?url="
```

Set `GD_PUBLIC_RELAY=off` to disable the fallback, or set `GD_UPSTREAM` to one or more trusted
GD database mirrors (`https://mirror.example/database,...`) to replace the primary upstream.

Diagnose from any browser:

* `GET /api/gd/` → JSON with configured upstreams, cacheable endpoints, and whether the fallback is enabled.
* Responses carry `x-gd-upstream`; public fallback responses additionally carry `x-gd-relay: public-read`.
* A complete failure returns `-1` (the game's own "no data") plus `x-gd-errors` with the attempted routes.

`?noprefetch` disables the warm-up if you want to see the cold path.

---

## Deploy (pick one)

**A. Vercel CLI (fastest)**

```bash
cd <your-repo>
npx vercel deploy --prod     # first run asks to link/create a project
```

**B. GitHub → Vercel**

1. Push this folder to a repo (the ~216 MB of generated assets are *not* committed — see below).
2. In Vercel: **Add New → Project → import the repo**.
3. Deploy. `vercel.json` already sets the build command, output dir and headers.

**Node version:** set in `package.json` (`engines.node`), **not** in `vercel.json`. For the built-in
Node runtime Vercel requires *no* `functions[].runtime` — that field is only for community runtimes
in `name@version` form, and a bare value like `nodejs20.x` fails the deploy with *"Function Runtimes
must have a valid version, for example `now-php@1.0.0`"*. `tests/verify-deploy-config.mjs` enforces
this (plus: no `[...]` in function globs, since those are glob character classes and would silently
match nothing).

Your build step downloads the game assets automatically (`node scripts/fetch-assets.mjs`), so the
repo stays tiny and the deployment ships the real binaries from Vercel's edge. The online-levels
proxy runs as a Node function at `api/gd/[...path].js` (config in `vercel.json`); no extra setup.

> Default UHD deployment size is about **203 MB** of static assets (13.3 MB engine + ~189.5 MB
> gzipped resource parts). The larger matching tier is intentional: it preserves the native UI's
> geometry. Returning players transfer ~0 bytes because assets are versioned, `immutable`, and also
> pinned in Cache Storage.

**Local test**

```bash
npm run assets     # downloads + repacks public/a/* (~15 s, needs ~1 GB free RAM)
npm run serve      # http://localhost:3000
```

`npm run assets:force` re-downloads from upstream. The build is incremental: with a valid
`public/a/manifest.json` it does nothing.

---

## What was made faster / leaner

Measured first-load transfer, this default **native-UHD high-FPS** build vs. the upstream port:

| | upstream port | this build |
|---|---|---|
| engine (`wasm`) | 66.6 MiB, concatenated in JS then compiled | **13.3 MiB** gzip, natively inflated and stream-compiled |
| resources (`data`) | 299.9 MiB / 16 serial parts | **~189.5 MiB** gzip of a **~215.5 MiB** package / 12 parallel parts |
| glue JS | `fetch` + `eval` | plain immutable `<script>` |
| **first load** | **367.7 MiB** | **~203 MB (−45%)** |
| texture tier | UHD | **UHD, with matching Cocos filename scaling** |

### Why the matching UHD build is required

The upstream package has several resolution tiers. `scripts/fetch-assets.mjs` selects one tier
without renaming it. The default is `uhd`; `hd`, `ld`, and `all` remain explicit build options through
`GD_QUALITY`. The engine's panel, font, icon, and sprite-frame paths are coupled to their qualified
texture names and matching plist dimensions. The UHD set is the only safe default for this port;
using only HD assets produced the broken small-icon/fragmented-panel UI shown in the regression.

The default package removes unused lower tiers and deduplicates byte-identical files, but never
changes a retained filename's scale suffix. The browser streams each gzip part directly into one
preallocated MEMFS buffer: no concatenation copy and no JavaScript decompressor are used.

The build tag now includes the selected tier, layout version, data hash, and glue hash. The build cache
also fingerprints the packer and normalized page template, so a loader/glue-patcher edit cannot silently
reuse old immutable artifacts. A build cannot reuse UHD artifacts after switching to HD (or vice versa).

### High-FPS runtime profile

| Lever | Default high-FPS setting | Effect |
|---|---|---|
| GPU | `powerPreference: "high-performance"` | prefers a discrete GPU when one is available |
| WebGL output | opaque canvas, MSAA off, `preserveDrawingBuffer: false` | avoids alpha compositing, multisample work, and a full-frame preserve copy |
| Presentation | `desynchronized: true` | reduces compositor queue latency on supporting drivers |
| Frame pacing | **uncapped by default** | advances the game as quickly as the browser/GPU can schedule it |
| Render resolution | **1280×720 by default**; fixed 1920×1080 game coordinates | 2.25× fewer default-framebuffer pixels; the patched GL viewport/scissor path scales only framebuffer 0, so offscreen effects stay correct |
| Turbo render | `?render=540` / `?turbo` (960×540) | 4× fewer default-framebuffer pixels than 1080p for severely GPU-bound systems |
| Ultra render | `?render=360`, `?ultra`, or `?fastest` (640×360) | 9× fewer default-framebuffer pixels than 1080p — the maximum-FPS visual mode |
| Native renderer bridge | coalesced overlapping interleaved Cocos client arrays | one exact temporary-VBO upload per shared native vertex struct, rather than one overlapping upload per attribute; draw order and image quality are unchanged |
| Input | fixed typed `Int32Array` ring + coalesced pointer motion | no event arrays or `Array.shift()` churn in the per-frame polling path |
| Canvas | 16:9 letterbox, compositor layer, cached bounds | no stretch, no per-event forced layout; hit testing remains in the native 1920×1080 coordinate space |
| Audio | `latencyHint: "interactive"` | lower output-buffer latency |

The page still exposes an opt-out profile for capture, battery, or compatibility: `?safe` or `?vsync`
restores a full 1920×1080 framebuffer, browser-friendly pacing, and conservative presentation choices.
The default deliberately prioritizes FPS and latency; it can use substantially more power and may tear
on some hardware.

**Measured validation:** in this sandbox's intentionally slow SwiftShader renderer, the real game booted,
accepted the notice-dialog click, and advanced at roughly **3.1 FPS at 1080p**, **13.1 FPS at 720p**,
**30.5 FPS at 540p**, and **52.3 FPS at 360p ultra**. Those are not hardware-GPU claims; they
demonstrate that the new framebuffer path is active and scales actual rendering work rather than merely
resizing CSS.

**Engine-path validation:** a temporary instrumented run of the live menu received 30,077 legacy native
client-attribute ranges in 10 seconds but issued only 10,971 temporary-VBO uploads after coalescing
(63.5% fewer uploads than the one-attribute-per-upload bridge). In immediately paired, fresh
15-second 540p SwiftShader samples, frame advance
increased from **26.85 FPS** before the engine bridge patch to **29.77 FPS** after it (about **10.9%**).
The notice dialog, main menu, and built-in level-selection scene all rendered and advanced afterward.
This is a small software-renderer sample, not a hardware-FPS promise.

### Measuring it yourself

Open the site with **`?perf`** for a small overlay: real FPS (from the engine's own frame counter),
worst frame time, **input latency in ms**, texture tier, and active framebuffer resolution. No flag, no overlay, no cost.

## Verification — how this build is proven

Nothing here is called done by eyeball. `tests/` contains the harnesses; all of them exit non-zero
on failure.

```bash
npm test                        # glue hot-path equivalence + build integrity
node tests/verify-build.mjs     # part files, tags, textures, dangling URLs, headers
node tests/verify-gd-api.mjs    # online proxy: passthrough, caching, failover, abuse, engine patch
node tests/verify-deploy-config.mjs  # vercel.json/package.json validity (catches deploy-time rejections)
python3 tests/unittest_input.py http://localhost:3000/    # 16 input/geometry assertions
python3 tests/geomcheck.py      http://localhost:3000/    # letterbox + click mapping, 5 window shapes
python3 tests/runtime.py        http://localhost:3000/ --quick  # boot + resource discipline (7 s)
python3 tests/verify-page.py    http://localhost:3000/    # high-FPS/safe query-profile wiring + software-GPU warning
python3 tests/smoke.py          http://localhost:3000/ lab # boot → dialog → menu → key, screenshots
python3 tests/abtest.py         <label> <port> [refdir]   # pixel-diff two builds
```

What they assert:

* **Build integrity** — every file the page names exists; `index.html`'s baked `GD_BUILD` equals
  `manifest.json`; every generated part exists, is gzip, and sums to the declared size; the glue
  carries the build tag; a single-tier build never mixes resolution tiers or ships unselected UHD
  files; no hard-coded `/a/` URL bypasses `assetURL()`.
* **Glue hot-path** — the patched fixed-ring input poll vs. the original `shift()` queue over
  thousands of randomised push/poll sequences plus a forced wrap/overflow, byte-identical results.
* **Native client-array bridge** — 4,000 randomized attribute layouts, including overlapping,
  stride-zero, disabled, and range-bridging cases, prove every original native byte range remains
  represented by its coalesced VBO upload; fixed per-context bookkeeping is present in generated glue.
* **Frame pacing** — with faked rAF/MessageChannel/timers: vsync, explicit high-FPS targets, and
  uncapped mode choose the expected wake-up path; a hidden tab backs off on a 50 ms timer; the refresh
  estimate survives a 5 s stall; the fast path allocates no per-frame queue. A page-level test also
  locks in the default high-FPS profile and the `?safe` / `?vsync` escape hatches.
* **Input & geometry** — at 960×540, 1000×700, 800×800, 1400×500 and 1920×1080 the canvas is exactly
  16:9, centred, inside the viewport; a click at the canvas centre still produces `WM_LBUTTONDOWN` at
  native game coordinates (960, 540) even though the default framebuffer is 1280×720 — i.e. the notice
  dialog's OK button is where it looks like it is; space
  produces `WM_KEYDOWN`+`WM_CHAR` with `VK_SPACE`; wheel, blur-release and focus messages verified;
  a 12-event mouse-move flood queues at most 3 polls.
* **Online proxy** — 30 assertions: endpoint parsing and traversal rejection, verbatim body + secret
  passthrough, User-Agent normalisation, cache policy per endpoint, method/size abuse, failover past a
  Cloudflare block and a 503, `-1` when everything is down, and the game-side proof that the engine
  image carries `/api/gd/...` and its HTTP hook issues that relative URL.
* **Runtime** — boot the real build, confirm the engine opens the selected texture tier (HD by
  default), never opens a higher unshipped tier, has no unexpected missing files, and advances frames.

### Cache correctness (why assets can never go stale)

`/a/*` is served `immutable` for a year, so URLs must change whenever the bytes do:

* The build computes a **tag** = hash of `commit + quality + layout version + output sizes + part
  count + **the glue's own bytes**` and writes it into `manifest.json` and `index.html`.
  (The glue hash matters: `/a/*` is immutable *and* the glue carries the same stamp, so without it a
  glue-only change — a runtime fix, a pacing change — would never reach a returning player. The
  integrity test recomputes that hash and fails the build if the tag ignores the glue.)
* Every asset request is `<file>?v=<tag>`; the Cache Storage bucket is `gd-assets-<tag>` and caches
  from other builds are deleted at startup.
* `index.html` is `no-store`, so a page can never be older than the deployment it talks to.
* The **engine script itself** is requested as `gd_web.js?v=<tag>` — a cached old glue used to ask
  for the *old* part count, which is what produced `part 12: HTTP 404` after a redeploy.
* The glue carries its own stamp (`Module.__gdBuildTag`); on mismatch the page re-fetches it with a
  cache buster.
* Belt and braces: a 404 on a part triggers one cache-busted retry, then a re-read of
  `manifest.json` to adopt the deployment's real part count — so even a fully stale page heals
  itself. This was reproduced and verified with a deliberately stale page.

### Optional knobs

| Flag | Effect |
|---|---|
| `?perf` | overlay: FPS, worst frame time, input latency, measured display Hz, pacing mode, GPU, texture tier, active framebuffer |
| `?render=720` | default high-FPS framebuffer (1280×720): 2.25× fewer pixels than 1080p |
| `?render=1080`, `?render=full`, or `?render=native` | full 1920×1080 framebuffer / maximum sharpness |
| `?render=540` or `?turbo` | 960×540 turbo framebuffer: 4× fewer pixels than 1080p |
| `?render=360`, `?ultra`, or `?fastest` | 640×360 maximum-FPS framebuffer: 9× fewer pixels than 1080p |
| `?safe` or `?vsync` | opt out of the max-performance default: full 1080p framebuffer (unless `?render=` is explicit), vsync pacing, browser MSAA/alpha choices, synchronized presentation |
| `?uncap` | force uncapped operation even alongside a safe URL; this is already the default otherwise |
| `?fps=N` | request an explicit frame budget, e.g. `?fps=90` |
| `?platformerfast` | keep uncapped pacing after a downloaded platformer level; default behavior switches only platformer simulation to stable rAF pacing |
| `?nodsync` | retain the high-FPS profile but disable desynchronized presentation for capture-tool compatibility |
| `?alpha` | request an alpha channel for an embedding that needs transparency |
| `?noaa` | explicitly disable MSAA (already the default high-FPS choice) |
| `?noprefetch` | don't pre-warm the online endpoints after boot |
| `?nofs` | do not auto-fullscreen on the first click (embedding, testing) |
| `?power=default` | let the browser pick the GPU; better battery life, potentially slower |
| `?debug` | full engine console output + build tag / part count / quality line |

Build-time texture tiers: default `npm run assets` builds the required **UHD** tier. Use
`npm run assets:hd` or `GD_QUALITY=ld npm run assets:force` only for controlled experiments;
they are not the supported UI-correct deployment. `GD_QUALITY=all npm run assets:force` creates
a full reference package.

Rebuild after changing anything: the build re-packs the package, updates the baked manifest and
writes a new tag.

## Black or blank screen? Read this

The page tells you what is happening instead of going silent:

| What you see | What it means |
|---|---|
| `loading 12%` climbing to `99%`, thin line at the bottom | **Normal.** It is downloading about 203 MB for the default UI-correct UHD build. On a 100 Mbit line that is roughly 20 s before overhead; on mobile data it can be much longer. Leave the tab focused. |
| `loading X%` stuck for 25 s | The download stalled; the page says so. Reload and check in DevTools → Network that `/a/gd_web.data.partN` returns 200. |
| `game data failed to load (part N: HTTP 404 …)` | The page and the deployment disagree — usually a **stale cached page** from an older build. Every asset URL carries `?v=<tag>` and `index.html` is `no-store`, and a stale page self-heals; for an already-poisoned browser do one hard reload (Ctrl/Cmd+Shift+R). If it 404s on a *fresh* browser, the build step did not run. |
| `could not download the game engine` | Network failure while fetching the wasm pack, reported instead of hanging. |
| `This build needs WebAssembly JSPI…` | Browser too old / flag off. Chrome-Edge 137+, Firefox 153+, Safari 27+. Chrome flag: `chrome://flags/#enable-experimental-webassembly-features`. |
| `WebGL2 is unavailable` | Hardware acceleration is off, or you are in a VM/remote desktop. |
| Game's own blue **Geometry Dash** loading screen | It worked — the engine is up and booting its resources. |
| Pure black, no text at all | Old `index.html` cached, or JS disabled. Hard-reload and append `?debug`. |
| Deploy fails: *Function Runtimes must have a valid version* | `vercel.json` had a `functions[].runtime`. Remove it — the Node version comes from `package.json` `engines.node`. Run `node tests/verify-deploy-config.mjs`. |
| Online Levels shows "no connection" | `/api/gd/*` is up but the upstream is unreachable — check `GET /api/gd/` for the configured upstream, and the `x-gd-errors` header on a failing request. See *Online levels*. |

## Repository hygiene

`public/a/` (~203 MB in the default UHD build) and `.cache-assets/` (~300 MB) are **build artifacts**, not source — both are
git-ignored. Vercel recreates them during the build. That keeps the project small enough to
sync, commit and diff; never force-add them to git.

```bash
npm run dev      # builds the assets once, then serves http://localhost:3000
```

## Requirements

* A modern desktop Chrome/Edge/Firefox (WebGL2 + WebAssembly).
* **JSPI** ("JavaScript Promise Integration") is used by this port for its frame-yield loop. Chrome
  has it on by default in current versions; if the game never leaves the loading screen, enable
  `chrome://flags#enable-experimental-webassembly-features`, restart, and add `?debug` to the URL to
  see the engine's console output.

## Controls

Click / tap / `Space` / `↑` to jump, `Esc` pauses, mouse for menus. Click once on the page for
fullscreen (or open with `?nofs` to stay windowed).

---

## Files

```
<your-repo>/
├── vercel.json                 # build cmd, output dir, cache + MIME headers
├── package.json                # npm run assets / serve / test / deploy
├── public/
│   ├── index.html              # the whole site: canvas + loader + input glue
│   └── a/                      # generated by scripts/fetch-assets.mjs (git-ignored)
│       ├── manifest.json       # sizes, part count, texture-set info (also baked into the page)
│       ├── gd_web.js           # Emscripten glue, file table rewritten by the build
│       ├── gd_web.wasm.pack    # 66.6 MiB engine, gzip (13.3 MiB), stream-compiled
│       └── gd_web.data.part1…12 # matching UHD resources, deduplicated + gzip (~189.5 MiB)
├── scripts/
│   ├── fetch-assets.mjs        # downloads, dedupes, repacks, patches the glue, verifies sizes
│   └── serve.mjs               # local static server with Vercel-like headers
├── workers/
│   └── gd-public-read-relay.js # optional owned Cloudflare fallback for public online reads
└── tests/
    ├── verify-build.mjs        # build integrity (node, no browser)
    ├── verify-gd-api.mjs       # online proxy + engine-image patch (node, no browser)
    ├── verify-deploy-config.mjs# Vercel config validity, offline (node, no browser)
    ├── verify-input.mjs        # glue hot-path equivalence (node, no browser)
    ├── verify-client-arrays.mjs# native interleaved-VBO bridge equivalence (node, no browser)
    ├── verify-pacing.mjs       # frame pacer contract: vsync vs uncap vs ?fps (node, no browser)
    ├── verify-performance.mjs  # high-FPS default profile contract (node, no browser)
    ├── verify-page.py          # query-flag wiring + software-renderer warning (Playwright)
    ├── unittest_input.py       # input/geometry assertions (Playwright)
    ├── geomcheck.py            # letterbox + click mapping at 5 window shapes (Playwright)
    ├── runtime.py              # boots the real build, audits which files the engine opens
    ├── smoke.py                # boot → notice dialog → menu → keypress (Playwright)
    └── abtest.py               # pixel-diff two builds (Playwright + PIL)
```

Upstream is pinned to commit `c6ac9417ff93ea957425b23ee87f1ed290663ebb` of
`AlexBoops/geometry-dash-webport` so builds are reproducible. Run `npm run assets:force` to
re-download, or bump `COMMIT` in `scripts/fetch-assets.mjs` when upstream updates.

## Credits / legal

* Geometry Dash © **RobTop Games** — unofficial fan port; not affiliated with or endorsed by RobTop.
  Do not sell or monetise it.
* Web port by **bog** ("lollipop"); maintenance, the JS glue and the 2.2 feature work by
  **AlexBoops** and contributors.
* This repo only adds packaging, the faster loader, the test suite and the deployment config.
