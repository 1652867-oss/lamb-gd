/**
 * Vercel function: /api/gd/<endpoint>
 *
 * The game's engine image is patched at build time to call this path instead of
 * Boomlings, so in-game level search / demons / level downloads work from our own
 * origin. See server/gd-proxy.mjs for the shared implementation.
 */
import { proxyRequest, proxyInfo, resolveEndpoint } from "../../server/gd-proxy.mjs";

async function readBody(req) {
  if (req.method !== "POST") return null;
  // read at most one byte past the limit: the proxy turns anything larger into a
  // 413, and memory can never be exhausted by a caller
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    chunks.push(c);
    size += c.length;
    if (size > 64 * 1024) break;
  }
  return Buffer.concat(chunks);
}

export default async function handler(req, res) {
  const pathname = req.url || "/api/gd/";
  const url = new URL(pathname, "http://localhost");
  const query = Object.fromEntries(url.searchParams.entries());
  query.qs = url.search.slice(1);

  if (!resolveEndpoint(url.pathname, query)) {
    res.statusCode = pathname.replace(/\?.*$/, "") === "/api/gd" || pathname === "/api/gd/" ? 200 : 404;
    res.setHeader("content-type", "application/json");
    res.setHeader("cache-control", "no-store");
    res.end(JSON.stringify(proxyInfo()));
    return;
  }

  const out = await proxyRequest({
    method: req.method,
    pathname: url.pathname,
    query,
    headers: req.headers,
    body: await readBody(req),
  });

  res.statusCode = out.status;
  for (const [k, v] of Object.entries(out.headers)) res.setHeader(k, v);
  res.end(out.body);
}
