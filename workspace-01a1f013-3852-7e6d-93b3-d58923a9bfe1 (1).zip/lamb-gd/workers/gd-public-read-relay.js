// Optional Cloudflare Worker for a deployment owner who wants to replace the
// shared public-read fallback. Deploy this file as a Worker, then set Vercel's
// GD_PUBLIC_RELAY to https://<your-worker>.workers.dev/?url=
//
// It intentionally supports anonymous, public level reads only. Do not turn it
// into a general CORS proxy or route account credentials through a shared worker.
const READ_ONLY = new Set([
  "getGJLevels21.php",
  "downloadGJLevel22.php",
  "getGJSongInfo.php",
  "getGJMapPacks21.php",
  "getGJGauntlets21.php",
  "getGJLevelLists.php",
  "getGJUsers20.php",
  "getGJUserInfo20.php",
  "getGJScores20.php",
  "getGJTopArtists.php",
  "checkIfServerOnline.php",
]);

function cors() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-allow-headers": "content-type",
    "access-control-max-age": "86400",
  };
}

export default {
  async fetch(request) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
    if (request.method !== "GET" && request.method !== "POST") return new Response("method not allowed", { status: 405, headers: cors() });

    const requestURL = new URL(request.url);
    let target;
    try { target = new URL(requestURL.searchParams.get("url") || ""); }
    catch { return new Response("missing or invalid url", { status: 400, headers: cors() }); }

    if (target.origin !== "https://www.boomlings.com" || !target.pathname.startsWith("/database/")) {
      return new Response("host not allowed", { status: 403, headers: cors() });
    }
    const endpoint = target.pathname.slice("/database/".length);
    if (!READ_ONLY.has(endpoint)) return new Response("endpoint not allowed", { status: 403, headers: cors() });

    const body = request.method === "POST" ? await request.arrayBuffer() : undefined;
    const response = await fetch(target, {
      method: request.method,
      headers: {
        // The GD origin's WAF accepts Worker-originated form requests without a
        // browser-like user agent. No player cookies or authorization are sent.
        "content-type": request.headers.get("content-type") || "application/x-www-form-urlencoded",
      },
      body,
      redirect: "follow",
    });
    return new Response(response.body, {
      status: response.status,
      headers: { ...cors(), "content-type": response.headers.get("content-type") || "text/plain; charset=utf-8" },
    });
  },
};
