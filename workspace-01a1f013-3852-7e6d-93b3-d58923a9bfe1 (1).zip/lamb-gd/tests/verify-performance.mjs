#!/usr/bin/env node
/**
 * High-FPS profile contract. These are source-level checks because WebGL context
 * attributes and the default pacing query are selected before the WASM runtime
 * starts, and therefore cannot be covered by the glue-only unit tests.
 */
import { readFile } from "node:fs/promises";

const page = await readFile(new URL("../public/index.html", import.meta.url), "utf8");
const glue = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};

check("max-performance profile is the default", /uncap:\s*!fpsArg\s*&&\s*\(!safeProfile/.test(page));
check("safe/vsync escape hatch is available", /safe\|compat\|vsync/.test(page));
check("default profile enables desynchronized presentation", /desynchronized:\s*!safeProfile/.test(page));
check("default profile disables MSAA", /antialias:\s*\(!safeProfile/.test(page));
check("default framebuffer is 720p for a 2.25x fill-rate reduction", /else renderHeight = 720;/.test(page) && /canvas\.width = RENDER_W;/.test(page));
check("turbo framebuffer option reaches 540p", /\?render=540/.test(page) && /turbo.*alias for 540/.test(page));
check("maximum-FPS ultra framebuffer option reaches 360p", /\?render=360/.test(page) && /(?:ultra|fastest).*aliases for 360/.test(page));
check("input uses one fixed typed ring", /gdInputRing: new Int32Array\(3 \* 1024\)/.test(page) && /Module\.gdInputCount/.test(glue));
check("render scaling only touches the default framebuffer", /Module\.gdDrawFramebuffer/.test(glue) && /s !== 1 && !Module\.gdDrawFramebuffer/.test(glue));
check("native Cocos client arrays coalesce overlapping interleaved uploads", /gdClientGroupOf/.test(glue) && /getTempVertexBuffer\(bytes\)/.test(glue) && /attr\.ptr - base/.test(glue));
check("native 1920x1080 hit coordinates are retained", /var GAME_W = 1920, GAME_H = 1080/.test(page));
check("context explicitly requests opaque output", /o\.alpha = t\.alpha === true/.test(glue));
check("context keeps the no-copy backbuffer", /o\.preserveDrawingBuffer = false/.test(glue));
check("context honors the low-latency presentation setting", /o\.desynchronized = t\.desynchronized === true/.test(glue));
const packer = await readFile(new URL("../scripts/fetch-assets.mjs", import.meta.url), "utf8");
check("build defaults to the native UHD texture tier", /GD_QUALITY \|\| "uhd"/.test(packer));
check("texture tiers are never aliased across filename scale factors", /const ALIAS_ACROSS_RES = false;/.test(packer));
check("public online reads have a browser fallback when the Vercel route fails", /gdPublicEndpoint/.test(packer) && /gdTryRelay/.test(packer));

console.log(failures === 0 ? "\nHIGH-FPS PROFILE: ALL PASS" : `\nHIGH-FPS PROFILE: ${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
