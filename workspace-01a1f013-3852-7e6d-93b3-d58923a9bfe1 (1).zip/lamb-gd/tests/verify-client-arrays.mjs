#!/usr/bin/env node
/**
 * Equivalence checks for the native Cocos client-array bridge optimization.
 *
 * The browser WebGL bridge has to convert legacy client arrays into temporary
 * VBO uploads. The production glue coalesces overlapping interleaved ranges
 * with the same stride. This test mirrors that small range-partition algorithm
 * and proves every original upload range remains wholly represented, packed
 * arrays only share when their pointer is identical, and a bridging interval
 * merges earlier overlapping groups.
 */
import { readFile } from "node:fs/promises";

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};

/** Exact range grouping used by the generated GL patch, expressed as data. */
function groupRanges(attrs) {
  const max = attrs.length;
  const groupOf = new Int32Array(max);
  const starts = new Uint32Array(max);
  const ends = new Uint32Array(max);
  const strides = new Int32Array(max);
  const used = new Int8Array(max);
  let groups = 0;

  for (let i = 0; i < max; ++i) {
    const a = attrs[i];
    groupOf[i] = -1;
    if (!a.enabled) continue;
    const start = a.ptr >>> 0;
    const end = start + a.bytes;
    let g = -1;
    for (let j = 0; j < groups; ++j) {
      if (!used[j]) continue;
      if ((a.stride > 0 && strides[j] === a.stride && start <= ends[j] && end >= starts[j]) ||
          (a.stride === 0 && start === starts[j])) {
        g = j;
        break;
      }
    }
    if (g < 0) {
      g = groups++;
      used[g] = 1;
      starts[g] = start;
      ends[g] = end;
      strides[g] = a.stride;
    } else {
      if (start < starts[g]) starts[g] = start;
      if (end > ends[g]) ends[g] = end;
      if (a.stride > 0) {
        for (let h = g + 1; h < groups; ++h) {
          if (used[h] && strides[h] === a.stride && starts[g] <= ends[h] && ends[g] >= starts[h]) {
            if (starts[h] < starts[g]) starts[g] = starts[h];
            if (ends[h] > ends[g]) ends[g] = ends[h];
            for (let q = 0; q < i; ++q) if (groupOf[q] === h) groupOf[q] = g;
            used[h] = 0;
          }
        }
      }
    }
    groupOf[i] = g;
  }
  return { groupOf, starts, ends, strides, used, groups };
}

function equivalent(attrs) {
  const out = groupRanges(attrs);
  for (let i = 0; i < attrs.length; ++i) {
    const a = attrs[i];
    if (!a.enabled) {
      if (out.groupOf[i] !== -1) return `disabled attribute ${i} was grouped`;
      continue;
    }
    const g = out.groupOf[i];
    if (g < 0 || !out.used[g]) return `attribute ${i} has no live group`;
    if (out.starts[g] > a.ptr || out.ends[g] < a.ptr + a.bytes) {
      return `group ${g} does not cover ${i}: ${out.starts[g]}..${out.ends[g]} vs ${a.ptr}..${a.ptr + a.bytes}`;
    }
    // The attribute's pointer in the shared VBO is its original byte offset
    // relative to the coalesced source range; it must be non-negative.
    if (a.ptr - out.starts[g] < 0) return `negative offset for ${i}`;
  }
  // Never group distinct packed arrays: the production bridge only permits
  // stride-zero sharing for identical start pointers.
  for (let i = 0; i < attrs.length; ++i) for (let j = i + 1; j < attrs.length; ++j) {
    const a = attrs[i], b = attrs[j];
    if (a.enabled && b.enabled && a.stride === 0 && b.stride === 0 && a.ptr !== b.ptr &&
        out.groupOf[i] === out.groupOf[j]) return `distinct packed arrays ${i}/${j} shared a VBO upload`;
  }
  return "";
}

const interleaved = [
  { enabled: true, ptr: 1000, bytes: 96, stride: 24 },
  { enabled: true, ptr: 1008, bytes: 96, stride: 24 },
  { enabled: true, ptr: 1016, bytes: 96, stride: 24 },
];
let grouped = groupRanges(interleaved);
check("interleaved position/color/UV arrays upload one union range",
      grouped.used.reduce((n, x) => n + x, 0) === 1 && grouped.starts[0] === 1000 && grouped.ends[0] === 1112,
      JSON.stringify({ starts: [...grouped.starts], ends: [...grouped.ends], used: [...grouped.used] }));
check("interleaved group preserves all original byte ranges", !equivalent(interleaved), equivalent(interleaved));

const bridge = [
  { enabled: true, ptr: 100, bytes: 20, stride: 8 },
  { enabled: true, ptr: 150, bytes: 20, stride: 8 },
  { enabled: true, ptr: 110, bytes: 50, stride: 8 }, // bridges the first two
];
grouped = groupRanges(bridge);
check("bridging interleaved range merges earlier groups", grouped.used.reduce((n, x) => n + x, 0) === 1,
      JSON.stringify({ starts: [...grouped.starts], ends: [...grouped.ends], groups: [...grouped.groupOf] }));

const packed = [
  { enabled: true, ptr: 400, bytes: 16, stride: 0 },
  { enabled: true, ptr: 416, bytes: 16, stride: 0 },
  { enabled: true, ptr: 400, bytes: 24, stride: 0 },
];
grouped = groupRanges(packed);
check("distinct packed arrays stay isolated while identical starts share", grouped.groupOf[0] !== grouped.groupOf[1] && grouped.groupOf[0] === grouped.groupOf[2],
      JSON.stringify({ groups: [...grouped.groupOf] }));

// Deterministic fuzz: both clustered interleaved structs and unrelated packed
// arrays, with disabled slots, different strides, and non-monotonic pointers.
let seed = 0x51f15e;
const rnd = n => ((seed = (seed * 1664525 + 1013904223) >>> 0) % n);
let fuzzed = 0, bad = "";
for (let round = 0; round < 4000 && !bad; ++round) {
  const attrs = [];
  const base = 1024 + rnd(2048);
  for (let i = 0; i < 16; ++i) {
    const enabled = rnd(5) !== 0;
    const stride = rnd(3) === 0 ? 0 : [8, 16, 24, 32][rnd(4)];
    // Favor overlapping interleaved ranges while regularly producing unrelated ones.
    const ptr = stride && rnd(3) ? base + rnd(stride) : base + rnd(768);
    const bytes = stride ? stride * (1 + rnd(8)) : [4, 8, 12, 16, 24, 32][rnd(6)];
    attrs.push({ enabled, ptr, bytes, stride });
  }
  bad = equivalent(attrs);
  fuzzed++;
}
check("4,000 randomized range layouts preserve every native upload", !bad, bad);

const glue = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
check("generated glue contains fixed per-context group storage", /gdClientGroupOf/.test(glue) &&
      /new Uint32Array\(max\)/.test(glue) && /attr\.ptr - base/.test(glue));

console.log(`client-array equivalence: ${fuzzed} layouts checked`);
console.log(failures ? `\nCLIENT ARRAYS: ${failures} FAILED` : "\nCLIENT ARRAYS: ALL PASS");
process.exit(failures ? 1 : 0);
