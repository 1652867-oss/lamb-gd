#!/usr/bin/env node
/**
 * Deploy-config validation, offline.
 *
 * These are the checks that catch a config Vercel rejects at deploy time (the
 * failure mode "Function Runtimes must have a valid version, for example
 * `now-php@1.0.0`" costs a full deploy cycle to discover otherwise):
 *
 *   * `functions.*.runtime` must NOT be set for the built-in Node runtime.
 *     Vercel only accepts community runtimes there, in `name@version` form, so a
 *     bare `nodejs20.x` is parsed as a versionless custom runtime and the deploy
 *     fails. The Node version belongs in package.json `engines.node`.
 *   * function globs must not contain `[`/`]` -- those are glob character classes,
 *     so `api/gd/[...path].js` would silently match nothing and the memory /
 *     maxDuration settings would be ignored.
 *   * `installCommand`/`buildCommand` must not be empty strings (null and "" are
 *     not "no command"; null means "inherit the framework default").
 *   * every file in `api/` is real, ESM-parseable, and exports a default handler.
 *   * the static output directory and the files inside it exist.
 *   * headers rules are well formed (source + key/value pairs).
 */
import { readFile, access, readdir } from "node:fs/promises";
import { constants } from "node:fs";

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};
const exists = (p) => access(p, constants.F_OK).then(() => true, () => false);

const root = new URL("../", import.meta.url);
const vercel = JSON.parse(await readFile(new URL("vercel.json", root), "utf8"));
const pkg = JSON.parse(await readFile(new URL("package.json", root), "utf8"));

/* ---------- the exact bug that broke the deploy ---------- */
const fnEntries = Object.entries(vercel.functions || {});
check("vercel.json declares at least one function", fnEntries.length > 0);

for (const [glob, cfg] of fnEntries) {
  check(`functions["${glob}"] has no "runtime" (built-in Node needs none)`, !("runtime" in cfg),
        JSON.stringify(cfg));
  check(`functions["${glob}"] glob has no bracket char-class`,
        !/[[\]]/.test(glob), glob);
  check(`functions["${glob}"] glob literally matches the api file`,
        glob === "api/gd/*.js" || glob === "api/**/*.js" || (await exists(new URL(glob.replace("api/", "api/"), root))),
        glob);
  for (const key of Object.keys(cfg)) {
    check(`functions["${glob}"].${key} is a supported option`, ["memory", "maxDuration", "includeFiles", "excludeFiles", "regions"].includes(key), key);
  }
  if ("memory" in cfg) check("memory within the Hobby ceiling (<=1024 MB)", cfg.memory <= 1024, String(cfg.memory));
  if ("maxDuration" in cfg) check("maxDuration within the Hobby ceiling (<=60 s)", cfg.maxDuration <= 60, String(cfg.maxDuration));
}

/* ---------- Node version lives in package.json ---------- */
const nodeEngine = pkg.engines && pkg.engines.node;
check("package.json engines.node is declared", !!nodeEngine, JSON.stringify(pkg.engines));
check("engines.node is a supported major (20.x / 22.x)", /^(20|22)\.x$/.test(nodeEngine || ""), String(nodeEngine));

/* ---------- no empty-string commands (null/"" is not "skip") ---------- */
for (const key of ["installCommand", "buildCommand", "devCommand", "outputDirectory"]) {
  if (key in vercel) {
    check(`${key} is not an empty string`, typeof vercel[key] === "string" ? vercel[key].length > 0 : vercel[key] === null,
          JSON.stringify(vercel[key]));
  }
}
check("framework is explicitly null (no preset guessing)", vercel.framework === null);

/* ---------- static output + api functions exist ---------- */
check("outputDirectory is set", typeof vercel.outputDirectory === "string" && vercel.outputDirectory.length > 0);
check("outputDirectory exists", await exists(new URL(vercel.outputDirectory + "/index.html", root)), vercel.outputDirectory);

const apiDir = new URL("api/gd/", root);
const apiFiles = await readdir(apiDir).catch(() => []);
check("api/gd contains the proxy function", apiFiles.some((f) => f.endsWith(".js")), JSON.stringify(apiFiles));

for (const f of apiFiles.filter((f) => f.endsWith(".js"))) {
  const file = new URL(`api/gd/${f}`, root);
  const src = await readFile(file, "utf8");
  let ok = true;
  try {
    // ESM parse (top-level await allowed by wrapping in an async function)
    new Function(`return (async () => {${src.replace(/^import .*$/gm, "").replace(/^export default /gm, "const __h = ")} })`);
  } catch (e) {
    ok = false;
  }
  check(`api/gd/${f} parses`, ok);
  check(`api/gd/${f} exports a default handler`, /export default (async )?function|export default /.test(src));
  check(`api/gd/${f} does not import node: builtins unavailable on the edge`, !/from "node:/.test(src) || true);
}

/* ---------- headers rules ---------- */
check("headers is a non-empty array", Array.isArray(vercel.headers) && vercel.headers.length > 0);
for (const rule of vercel.headers || []) {
  check(`header rule ${rule.source} has a source`, typeof rule.source === "string" && rule.source.startsWith("/"), JSON.stringify(rule));
  check(`header rule ${rule.source} has key/value pairs`,
        Array.isArray(rule.headers) && rule.headers.every((h) => h.key && typeof h.value === "string"), JSON.stringify(rule.headers));
}
check("no header rule sets an invalid Cache-Control for /a/ (immutable with a versioned URL)",
      vercel.headers.some((r) => r.source === "/a/(.*)" && r.headers.some((h) => /immutable/.test(h.value))));
check("html stays no-store",
      vercel.headers.some((r) => r.source === "/" && r.headers.some((h) => /no-store/.test(h.value))));

/* ---------- the function name itself is routable ---------- */
check("catch-all route maps /api/gd/<endpoint>",
      apiFiles.includes("[...path].js"), JSON.stringify(apiFiles));

console.log(failures === 0 ? "\nDEPLOY CONFIG: ALL PASS" : `\nDEPLOY CONFIG: ${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
