#!/usr/bin/env python3
"""
Visual A/B harness: boots a build, screenshots the notice dialog and the main
menu (after clicking OK), reports console errors, and diffs against a reference.

  python3 abtest.py <label> <port> [referencedir]
"""
import asyncio, os, sys, json
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright
from PIL import Image, ImageChops

ARGS = [
    "--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
    "--js-flags=--max-old-space-size=256", "--window-size=960,540",
    "--use-gl=angle", "--use-angle=swiftshader", "--autoplay-policy=no-user-gesture-required",
]

label = sys.argv[1]
port = sys.argv[2]
refdir = sys.argv[3] if len(sys.argv) > 3 else None
OUT = "/home/user/shots"
os.makedirs(OUT, exist_ok=True)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        pg = await b.new_page(viewport={"width": 960, "height": 540})
        errs = []
        pg.on("console", lambda m: errs.append(m.text[:120]) if m.type == "error" else None)
        await pg.goto(f"http://localhost:{port}/", wait_until="commit", timeout=30000)

        ready = False
        for _ in range(100):
            await asyncio.sleep(0.25)
            try:
                if await pg.evaluate("!!window.__gdReady"):
                    ready = True
                    break
            except Exception:
                print(f"{label}: PAGE DIED during boot")
                return
        print(f"{label}: ready={ready}")

        await asyncio.sleep(3.0)  # notice dialog appears
        dlg = f"{OUT}/{label}_dialog.png"
        await pg.screenshot(path=dlg, timeout=40000)

        # click where the OK button is (dialog centre-bottom)
        box = await pg.evaluate("(() => { const r = document.getElementById('canvas').getBoundingClientRect(); return {x:r.left, y:r.top, w:r.width, h:r.height}; })()")
        await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
        await asyncio.sleep(0.8)
        await pg.mouse.click(box["x"] + box["w"] * 0.5, box["y"] + box["h"] * 0.70)
        await asyncio.sleep(2.0)
        menu = f"{OUT}/{label}_menu.png"
        await pg.screenshot(path=menu, timeout=40000)

        try:
            frames = await pg.evaluate("Module._gd_frames_get()|0")
        except Exception:
            frames = -1
        print(f"{label}: frames={frames} console_errors={len(errs)}")
        for e in errs[:3]:
            print("   ERR:", e)

        if refdir:
            for kind in ("dialog", "menu"):
                a = f"{refdir}/{label}_{kind}.png"
                ref = f"{refdir}/ref_{kind}.png"
                if os.path.exists(ref) and os.path.exists(a):
                    ia, ib = Image.open(ref).convert("RGB"), Image.open(a).convert("RGB")
                    if ia.size != ib.size:
                        ib = ib.resize(ia.size)
                    diff = ImageChops.difference(ia, ib)
                    bbox = diff.getbbox()
                    px = sum(1 for p in diff.getdata() if sum(p) > 30)
                    pct = px / (ia.size[0] * ia.size[1]) * 100
                    print(f"   diff[{kind}]: {pct:.2f}% pixels differ, bbox={bbox}")
        try:
            await b.close()
        except Exception:
            pass


asyncio.run(main())
