#!/usr/bin/env node
/**
 * Unit test for the frame pacer (`__asyncjs__gd_js_yield_frame`) in the built glue.
 *
 * The pacing contract, verified without a GPU: which wake-up mechanism is chosen
 * (vsync vs the MessageChannel fast path vs a timer), and that the fast path does
 * not allocate a queue per frame. rAF / MessageChannel / setTimeout are fakes with
 * a virtual clock, so this is deterministic.
 */
import { readFile } from "node:fs/promises";

const src = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
const pStart = src.indexOf("function __asyncjs__gd_js_yield_frame(target_ms) {");
const pEnd = src.indexOf("Module.__gdPacingInfo", pStart);
if (pStart < 0 || pEnd < 0) throw new Error("pacer not found in glue");
const pacerSrc = src.slice(pStart, pEnd);

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};
const settle = () => new Promise((r) => setImmediate(r));

function makeEnv({ pacing = {}, hidden = false } = {}) {
  const clock = { now: 0, raf: [], port: [], timers: [], counts: { raf: 0, port: 0, timer: 0 } };
  const Module = { __gdPacing: pacing };
  const env = {
    clock, Module,
    document: { hidden, addEventListener() {} },
    requestAnimationFrame(fn) {
      clock.counts.raf++;
      if (clock.counts.raf > 500) return 0;          // stop the internal watch loop
      clock.raf.push(fn);
      return clock.raf.length;
    },
    MessageChannel: class {
      constructor() {
        this.port1 = { onmessage: null };
        this.port2 = { postMessage: () => { clock.counts.port++; clock.port.push(this.port1); } };
      }
    },
    setTimeout(fn) { clock.counts.timer++; clock.timers.push(fn); return clock.timers.length; },
    Asyncify: { handleAsync: (fn) => fn() },
  };
  return env;
}

function bindPacer(env) {
  return new Function(
    "Module", "document", "requestAnimationFrame", "MessageChannel", "setTimeout", "Asyncify", "Promise",
    `${pacerSrc}; return __asyncjs__gd_js_yield_frame;`
  )(env.Module, env.document, env.requestAnimationFrame, env.MessageChannel, env.setTimeout, env.Asyncify, Promise);
}

/**
 * Run `frames` pacing cycles. Before each frame the virtual clock advances by
 * `frameMs` and any queued rAF callbacks (the refresh watcher) fire, so the
 * pacer's refresh estimate converges like it would in a browser.
 */
async function runFrames(env, targetMs, frames, frameMs = 16.7) {
  const pacer = env.Module.__gdPacer || (env.Module.__gdPacer = bindPacer(env));
  for (let f = 0; f < frames; f++) {
    env.clock.now += frameMs;
    const watchers = env.clock.raf.splice(0);
    for (const w of watchers) w(env.clock.now);

    const p = pacer(targetMs);
    let done = false;
    p.then(() => { done = true; });
    for (let spin = 0; spin < 200 && !done; spin++) {
      await settle();
      if (done) break;
      // fire every queued wake-up: the refresh watcher re-queues itself, so
      // firing only one per spin would starve the timer path
      const ports = env.clock.port.splice(0);
      const rafs = env.clock.raf.splice(0);
      const timers = env.clock.timers.splice(0);
      for (const port of ports) if (port.onmessage) port.onmessage({});
      for (const raf of rafs) raf(env.clock.now);
      for (const timer of timers) timer();
    }
    if (!done) throw new Error("pacer never woke up");
    await p;
  }
  return env.clock.counts;
}

/* 1. default: engine asks for a full frame -> vsync */
{
  const env = makeEnv();
  await runFrames(env, 16.7, 1);                    // prime the refresh estimate
  const before = { ...env.clock.counts };
  await runFrames(env, 16.7, 4);
  const d = { raf: env.clock.counts.raf - before.raf, port: env.clock.counts.port - before.port };
  check("default pacing waits for vsync (rAF)", d.raf > 0 && d.port === 0, JSON.stringify(d));
}

/* 2. ?fps=30 -> slower than the display: still one frame per refresh */
{
  const env = makeEnv({ pacing: { target: 1000 / 30 } });
  await runFrames(env, 16.7, 1);
  const before = { ...env.clock.counts };
  await runFrames(env, 16.7, 4);
  check("?fps=30 stays vsync-paced", env.clock.counts.raf > before.raf && env.clock.counts.port === 0,
        JSON.stringify(env.clock.counts));
}

/* 3. ?fps=240 -> faster than the display: skip vsync */
{
  const env = makeEnv({ pacing: { target: 1000 / 240 } });
  await runFrames(env, 16.7, 1);
  const before = { ...env.clock.counts };
  await runFrames(env, 16.7, 4);
  check("?fps=240 skips vsync (fast path)", env.clock.counts.port > before.port, JSON.stringify(env.clock.counts));
}

/* 4. the engine's own sub-refresh budget uses the fast path */
{
  const env = makeEnv();
  await runFrames(env, 16.7, 1);
  const before = { ...env.clock.counts };
  await runFrames(env, 4, 3);
  check("engine sub-refresh budget uses the fast path", env.clock.counts.port > before.port, JSON.stringify(env.clock.counts));
}

/* 5. ?uncap never waits for vsync */
{
  const env = makeEnv({ pacing: { uncap: true } });
  await runFrames(env, 16.7, 4);
  check("?uncap never waits for vsync", env.clock.counts.port >= 4, JSON.stringify(env.clock.counts));
}

/* 6. hidden tab backs off on a timer instead of spinning */
{
  const env = makeEnv({ pacing: { uncap: true }, hidden: true });
  const counts = await runFrames(env, 16.7, 2);
  check("hidden tab backs off on a timer", counts.timer > 0 && counts.port === 0, JSON.stringify(counts));
}

/* 7. refresh estimate survives a stall and stays in range */
{
  const env = makeEnv();
  await runFrames(env, 16.7, 20);
  const est = env.Module.gdPace.interval;
  check("refresh estimate converges near 60 Hz", est > 10 && est < 25, String(est));
  env.clock.now += 5000;                             // 5 s away (tab switch)
  await runFrames(env, 16.7, 2, 16.7);
  const est2 = env.Module.gdPace.interval;
  check("estimate ignores a 5 s gap and stays sane", est2 > 2 && est2 < 100, `${est} -> ${est2}`);
}

/* 8. fast path reuses one wake-up slot instead of a per-frame queue */
{
  const env = makeEnv({ pacing: { uncap: true } });
  await runFrames(env, 16.7, 3);
  const hadQueue = env.Module.gdFastQ !== undefined;
  const counts = await runFrames(env, 16.7, 8);
  check("fast path allocates no per-frame queue", !hadQueue && env.Module.gdPace.wake === null,
        `gdFastQ=${env.Module.gdFastQ} wake=${env.Module.gdPace.wake}`);
  check("fast path wakes every frame", counts.port >= 8, String(counts.port));
}

/* 9. reported pacing info matches what was requested */
{
  const env = makeEnv({ pacing: { uncap: true } });
  await runFrames(env, 16.7, 2);
  const a = src.indexOf("Module.__gdPacingInfo =");
  const infoSrc = src.slice(a, src.indexOf("\n};", a) + 3);
  const info = new Function("Module", `${infoSrc}\n return Module.__gdPacingInfo();`)(env.Module);
  check("__gdPacingInfo reports uncapped", info && info.uncap === true, JSON.stringify(info));
  check("__gdPacingInfo reports a refresh rate", info && info.hz > 10, JSON.stringify(info));
}

console.log(failures === 0 ? "\nPACING: ALL PASS" : `\nPACING: ${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
