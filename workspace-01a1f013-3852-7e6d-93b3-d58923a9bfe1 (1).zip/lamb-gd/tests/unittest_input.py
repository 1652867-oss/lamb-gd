#!/usr/bin/env python3
"""
Unit tests for the page-side code (no game assets required):
  * input events -> exact Win32-style message codes + exact game coordinates
  * mouse-move coalescing, button release on blur, wheel, touch fallback
  * letterbox geometry must not distort or shift input
"""
import asyncio, os, sys
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000/"
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
        "--js-flags=--max-old-space-size=256", "--use-gl=angle", "--use-angle=swiftshader"]

WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP = 0x200, 0x201, 0x202
WM_RBUTTONDOWN, WM_RBUTTONUP = 0x204, 0x205
WM_KEYDOWN, WM_KEYUP, WM_CHAR = 0x100, 0x101, 0x102
WM_MOUSEWHEEL, WM_ACTIVATE, WM_SETFOCUS = 0x20A, 0x6, 0x7

fails = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + (("  " + detail) if (detail and not cond) else ""))
    if not cond:
        fails.append(name)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={"width": 1000, "height": 700})  # non-16:9 on purpose
        await ctx.route("**/a/**", lambda route: route.abort())             # no assets needed
        pg = await ctx.new_page()
        await pg.goto(URL + "?nofs", wait_until="commit", timeout=30000)
        await asyncio.sleep(0.3)

        geom = await pg.evaluate("(() => { const r=document.getElementById('canvas').getBoundingClientRect(); return {x:r.left,y:r.top,w:r.width,h:r.height}; })()")
        logical = await pg.evaluate("[window.__gdRender.gameWidth, window.__gdRender.gameHeight]")
        framebuffer = await pg.evaluate("[document.getElementById('canvas').width, document.getElementById('canvas').height]")
        print(f"canvas box {geom}, game={logical}, framebuffer={framebuffer}")
        check("letterbox keeps 16:9", abs(geom["w"] / geom["h"] - 16 / 9) < 0.005, str(geom["w"] / geom["h"]))
        check("letterbox is centred", abs(geom["x"] + geom["w"] / 2 - 500) <= 1)

        # --- keyboard -------------------------------------------------------
        await pg.keyboard.down("Space")
        await pg.keyboard.up("Space")
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        kinds = [m[0] for m in q]
        check("space produces WM_KEYDOWN", WM_KEYDOWN in kinds, str(kinds))
        check("space produces WM_KEYUP", WM_KEYUP in kinds, str(kinds))
        check("space produces WM_CHAR", WM_CHAR in kinds, str(kinds))
        kd = [m for m in q if m[0] == WM_KEYDOWN][0]
        check("space virtual-key is VK_SPACE (0x20)", kd[1] == 0x20, hex(kd[1]))
        check("key state array updated", (await pg.evaluate("Module.gdKeyState[0x20]")) == 0)

        # --- mouse ----------------------------------------------------------
        await pg.evaluate("window.__gdInputClear();")
        await pg.mouse.move(geom["x"] + geom["w"] * 0.5, geom["y"] + geom["h"] * 0.5)
        await pg.mouse.down()
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        check("mousedown -> WM_LBUTTONDOWN", any(m[0] == WM_LBUTTONDOWN for m in q), str(q[:3]))
        down = [m for m in q if m[0] == WM_LBUTTONDOWN][0]
        lp = down[2]
        gx, gy = lp & 0xFFFF, (lp >> 16) & 0xFFFF
        check("click at centre maps to the native game centre", abs(gx - logical[0] / 2) <= 2 and abs(gy - logical[1] / 2) <= 2, f"{gx},{gy} vs {logical}")
        check("button mask is 1 (left)", down[1] == 1, str(down[1]))

        await pg.mouse.up()
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        check("mouseup -> WM_LBUTTONUP", any(m[0] == WM_LBUTTONUP for m in q), str([m[0] for m in q]))
        check("mouseup releases the button mask", all(m[1] == 0 for m in q if m[0] == WM_LBUTTONUP))

        # --- move coalescing ------------------------------------------------
        await pg.evaluate("window.__gdInputClear();")
        for i in range(12):
            await pg.mouse.move(geom["x"] + 40 + i * 8, geom["y"] + 30 + i * 4)
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        moves = [m for m in q if m[0] == WM_MOUSEMOVE]
        check("mousemove flooded into <=3 queued entries", len(moves) <= 3, f"{len(moves)} for 12 moves")

        # --- wheel ----------------------------------------------------------
        await pg.evaluate("window.__gdInputClear();")
        await pg.mouse.wheel(0, 120)
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        check("wheel -> WM_MOUSEWHEEL", any(m[0] == WM_MOUSEWHEEL for m in q), str([m[0] for m in q]))

        # --- focus handshake ------------------------------------------------
        await pg.evaluate("window.__gdInputClear();")
        await pg.evaluate("window.__gdSendFocus(true)")
        await asyncio.sleep(0.05)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        check("focus sends WM_ACTIVATE/SETFOCUS", WM_ACTIVATE in [m[0] for m in q] and WM_SETFOCUS in [m[0] for m in q])

        # --- blur releases held buttons -------------------------------------
        await pg.evaluate("window.__gdInputClear();")
        await pg.mouse.down()
        await pg.evaluate("window.dispatchEvent(new Event('blur'))")
        await asyncio.sleep(0.1)
        q = await pg.evaluate("window.__gdInputSnapshot()")
        check("blur releases a held mouse button", any(m[0] == WM_LBUTTONUP for m in q), str([m[0] for m in q]))

        try:
            await b.close()
        except Exception:
            pass

    print("\nINPUT+GEOMETRY UNIT TESTS:", "ALL PASS" if not fails else f"{len(fails)} FAILED -> {fails}")

asyncio.run(main())
