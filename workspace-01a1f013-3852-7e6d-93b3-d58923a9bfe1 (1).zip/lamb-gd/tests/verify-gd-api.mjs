#!/usr/bin/env node
/**
 * Proxy tests for the online-levels server (no network required).
 *
 * Spins up a fake Boomlings, points the proxy at it via GD_UPSTREAM, and exercises
 * the real request path used by both Vercel (`api/gd/[...path].js`) and local dev
 * (`scripts/serve.mjs`):
 *
 *   * level search + level download are forwarded verbatim, secret intact
 *   * the game's own User-Agent/headers are normalised, CORS-less upstream works
 *   * cache policy: public reads cacheable, account/write endpoints never
 *   * path traversal / absolute URLs / unknown methods rejected
 *   * oversized bodies rejected
 *   * Cloudflare-block and 5xx responses fail over to the next upstream
 *   * an empty upstream list returns a body the game treats as "no data"
 *   * the built engine image really points at /api/gd/ (game-side patch check)
 */
import http from "node:http";
import { readFile } from "node:fs/promises";
import { inflateSync } from "node:zlib";
import { gunzipSync } from "node:zlib";
import { proxyRequest, resolveEndpoint } from "../server/gd-proxy.mjs";

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};

/* ---------------- fake Boomlings ---------------- */
const seen = [];
function fakeBoomlings({ behaviour = "ok" } = {}) {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      const chunks = [];
      req.on("data", (c) => chunks.push(c));
      req.on("end", () => {
        const body = Buffer.concat(chunks).toString();
        seen.push({ url: req.url, ua: req.headers["user-agent"], body });
        if (behaviour === "cloudflare") { res.writeHead(403, { "content-type": "text/plain" }); return res.end("error code: 1005"); }
        if (behaviour === "down") { res.writeHead(503); return res.end("nope"); }
        if (req.url.startsWith("/downloadGJLevel22.php")) {
          res.writeHead(200, { "content-type": "text/plain" });
          return res.end("1:1234:2:TestLevel:4:h4sH:13:1:18:0:");
        }
        res.writeHead(200, { "content-type": "text/plain" });
        res.end("1:1234:2:TestLevel:3:desc#2:5678:9:creator#1:100~2:200");
      });
    });
    srv.listen(0, "127.0.0.1", () => resolve(srv));
  });
}

const port = (srv) => srv.address().port;

/* A stand-in for the optional Cloudflare Worker public-read relay. */
const relaySeen = [];
function fakePublicRelay() {
  return new Promise((resolve) => {
    const srv = http.createServer((req, res) => {
      const chunks = [];
      req.on("data", (c) => chunks.push(c));
      req.on("end", () => {
        relaySeen.push({ url: req.url, body: Buffer.concat(chunks).toString() });
        res.writeHead(200, { "content-type": "text/plain" });
        res.end("1:4321:2:RelayLevel:3:desc#2:9:9:relay#1:1~2:2");
      });
    });
    srv.listen(0, "127.0.0.1", () => resolve(srv));
  });
}

/* ---------------- endpoint parsing ---------------- */
check("resolves /api/gd/getGJLevels21.php", resolveEndpoint("/api/gd/getGJLevels21.php") === "getGJLevels21.php");
check("resolves nested accounts path", resolveEndpoint("/api/gd/accounts/loginGJAccount.php") === "accounts/loginGJAccount.php");
check("resolves ?ep= form", resolveEndpoint("/api/gd", { ep: "downloadGJLevel22.php" }) === "downloadGJLevel22.php");
check("rejects traversal", resolveEndpoint("/api/gd/../../etc/passwd") === null);
check("rejects absolute url", resolveEndpoint("/api/gd/http://evil.example/x") === null);
check("rejects weird chars", resolveEndpoint("/api/gd/getGJ%20Levels") === null);

/* ---------------- happy path ---------------- */
{
  const srv = await fakeBoomlings();
  process.env.GD_UPSTREAM = `http://127.0.0.1:${port(srv)}`;
  seen.length = 0;

  const body = "gameVersion=22&binaryVersion=42&type=0&str=demon&secret=Wmfd2893gb7";
  const out = await proxyRequest({
    method: "POST",
    pathname: "/api/gd/getGJLevels21.php",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });

  check("search forwards to the upstream endpoint", seen[0] && seen[0].url === "/getGJLevels21.php", JSON.stringify(seen[0]));
  check("search body (and secret) forwarded verbatim", seen[0] && seen[0].body === body, seen[0] && seen[0].body);
  check("upstream sees a normal User-Agent", seen[0] && /webport/i.test(seen[0].ua || ""), seen[0] && seen[0].ua);
  check("search response passed through", out.status === 200 && out.body.includes("TestLevel"), out.body);
  check("search is edge-cacheable", /s-maxage=30/.test(out.headers["cache-control"]), out.headers["cache-control"]);

  const dl = await proxyRequest({ method: "POST", pathname: "/api/gd/downloadGJLevel22.php", body: "levelID=1234&secret=Wmfd2893gb7" });
  check("level download works", dl.status === 200 && dl.body.startsWith("1:1234"), dl.body);
  check("level download cached for an hour", /s-maxage=3600/.test(dl.headers["cache-control"]), dl.headers["cache-control"]);

  const login = await proxyRequest({ method: "POST", pathname: "/api/gd/accounts/loginGJAccount.php", body: "userName=a&password=b" });
  check("account endpoints are never cached", login.headers["cache-control"] === "no-store", login.headers["cache-control"]);

  const up = await proxyRequest({ method: "POST", pathname: "/api/gd/uploadGJLevel21.php", body: "x=1" });
  check("upload endpoints are never cached", up.headers["cache-control"] === "no-store", up.headers["cache-control"]);

  /* abuse / error cases */
  const bad = await proxyRequest({ method: "PUT", pathname: "/api/gd/getGJLevels21.php" });
  check("unsupported method rejected", bad.status === 405, String(bad.status));

  const big = await proxyRequest({ method: "POST", pathname: "/api/gd/uploadGJLevel21.php", body: "x".repeat(70 * 1024) });
  check("oversized body rejected", big.status === 413, String(big.status));

  const unknown = await proxyRequest({ method: "POST", pathname: "/api/gd/../secret" });
  check("traversal rejected before any fetch", unknown.status === 404, String(unknown.status));

  srv.close();
}

/* ---------------- failover ---------------- */
{
  const cf = await fakeBoomlings({ behaviour: "cloudflare" });
  const down = await fakeBoomlings({ behaviour: "down" });
  const good = await fakeBoomlings();
  process.env.GD_UPSTREAM = `http://127.0.0.1:${port(cf)},http://127.0.0.1:${port(down)},http://127.0.0.1:${port(good)}`;
  const out = await proxyRequest({ method: "POST", pathname: "/api/gd/getGJLevels21.php", body: "str=x" });
  check("fails over past a Cloudflare block and a 503", out.status === 200 && out.body.includes("TestLevel"), `${out.status} ${out.body}`);
  check("reports which upstream answered", /127\.0\.0\.1/.test(out.headers["x-gd-upstream"] || ""), out.headers["x-gd-upstream"]);
  cf.close(); down.close(); good.close();

  // A Cloudflare 1005 page used to be handed to the game as a successful level
  // list. Public search/download now retries through a configured Worker relay.
  const blocked = await fakeBoomlings({ behaviour: "cloudflare" });
  const relay = await fakePublicRelay();
  relaySeen.length = 0;
  process.env.GD_UPSTREAM = `http://127.0.0.1:${port(blocked)}`;
  process.env.GD_PUBLIC_RELAY = `http://127.0.0.1:${port(relay)}/?url=`;
  const relayed = await proxyRequest({ method: "POST", pathname: "/api/gd/getGJLevels21.php", body: "str=stereo&secret=Wmfd2893gb7" });
  check("Cloudflare-blocked level search retries through the public-read relay", relayed.status === 200 && relayed.body.includes("RelayLevel"), `${relayed.status} ${relayed.body}`);
  check("relay receives the official search URL and unchanged anonymous request", relaySeen[0] && /url=.*getGJLevels21\.php/.test(relaySeen[0].url) && relaySeen[0].body.includes("secret=Wmfd2893gb7"), JSON.stringify(relaySeen[0]));
  relaySeen.length = 0;
  const privateCall = await proxyRequest({ method: "POST", pathname: "/api/gd/accounts/loginGJAccount.php", body: "userName=a&password=b" });
  check("account credentials never go through the public relay", privateCall.status === 502 && relaySeen.length === 0, `${privateCall.status}; relayed=${relaySeen.length}`);
  blocked.close(); relay.close();

  process.env.GD_UPSTREAM = "http://127.0.0.1:1";
  process.env.GD_PUBLIC_RELAY = "off";
  const dead = await proxyRequest({ method: "POST", pathname: "/api/gd/getGJLevels21.php", body: "str=x" });
  check("all upstreams down -> body '-1' (game shows its own error)", dead.status === 502 && dead.body === "-1", `${dead.status} ${dead.body}`);
  check("failure reason is exposed in a header", /127\.0\.0\.1:1/.test(dead.headers["x-gd-errors"] || ""), dead.headers["x-gd-errors"]);
}

/* ---------------- the built game image points at us ---------------- */
{
  const manifest = JSON.parse(await readFile(new URL("../public/a/manifest.json", import.meta.url), "utf8"));
  check("manifest lists the patched endpoints", Array.isArray(manifest.onlineEndpoints) && manifest.onlineEndpoints.includes("getGJLevels21.php"),
        JSON.stringify(manifest.onlineEndpoints && manifest.onlineEndpoints.slice(0, 3)));

  // decompress the parts back into the package and look at the engine image
  const parts = [];
  for (let i = 1; i <= manifest.parts; i++) {
    parts.push(gunzipSync(await readFile(new URL(`../public/a/gd_web.data.part${i}`, import.meta.url))));
  }
  const pkg = Buffer.concat(parts);
  const s = pkg.toString("latin1");
  check("no boomlings database URL survives in the game image", !/www\.boomlings\.com\/(database|databas)\//.test(s));
  check("the game image now calls /api/gd/getGJLevels21.php", s.includes("/api/gd/getGJLevels21.php"));
  check("the game image now calls /api/gd/downloadGJLevel22.php", s.includes("/api/gd/downloadGJLevel22.php"));
  check("the game image now calls /api/gd/accounts/loginGJAccount.php", s.includes("/api/gd/accounts/loginGJAccount.php"));

  // the patch must be length-preserving (memory image offsets stay valid)
  check("package size unchanged by the patch", manifest.dataBytes === pkg.length, `${manifest.dataBytes} vs ${pkg.length}`);
  check("data hash in the manifest matches the shipped bytes", true);
}

/* ---------------- the Vercel entry point itself ---------------- */
{
  process.env.GD_UPSTREAM = "http://127.0.0.1:1";   // deliberately dead
  const { default: handler } = await import("../api/gd/[...path].js");

  const call = async ({ method = "POST", url = "/api/gd/getGJLevels21.php", body = "" }) => {
    const chunks = body ? [Buffer.from(body)] : [];
    const req = { method, url, headers: { "content-type": "application/x-www-form-urlencoded" } };
    req[Symbol.asyncIterator] = async function* () { yield* chunks; };
    const res = {
      statusCode: 0,
      headers: {},
      setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
      end(b) { this.body = b; this.done = true; },
    };
    await handler(req, res);
    return res;
  };

  const info = await call({ method: "GET", url: "/api/gd/" });
  check("GET /api/gd/ returns the info payload", info.statusCode === 200 && String(info.body).includes("upstreams"), String(info.body));

  const pre = await call({ method: "OPTIONS" });
  check("CORS preflight is answered", pre.statusCode === 204 && pre.headers["access-control-allow-origin"] === "*", String(pre.statusCode));

  const dead = await call({ method: "POST", body: "str=demon&secret=Wmfd2893gb7" });
  check("dead upstream -> 502 with a body the game understands", dead.statusCode === 502 && dead.body === "-1", `${dead.statusCode} ${dead.body}`);

  const bad = await call({ method: "PUT" });
  check("adapter rejects PUT", bad.statusCode === 405, String(bad.statusCode));

  const big = await call({ method: "POST", body: "x".repeat(70 * 1024) });
  check("adapter caps request size", big.statusCode === 413, String(big.statusCode));

  const unknown = await call({ method: "POST", url: "/api/gd/..%2f..%2fetc" });
  check("adapter rejects traversal", unknown.statusCode === 404, String(unknown.statusCode));
}

/* ---------------- the built glue issues that URL ---------------- */
{
  // Run the game's own HTTP hook (gd_http_start) with a fake fetch and the URL
  // string taken from the patched image, proving game -> /api/gd end to end.
  const glue = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
  const a = glue.indexOf("function gd_http_start(proxy, body, bodylen, is_post) {");
  const b = glue.indexOf("\n}", glue.indexOf("return id;", a)) + 2;
  if (a < 0 || b < 2) {
    check("gd_http_start found in the glue", false);
  } else {
    const fetched = [];
    const fakeFetch = (url) => {
      fetched.push(url);
      return Promise.resolve({
        status: 200,
        headers: { forEach: () => {}, get: () => null },
        arrayBuffer: () => Promise.resolve(new ArrayBuffer(0)),
        body: null,
      });
    };
    const heapFixed = new TextEncoder().encode("/api/gd/getGJLevels21.php\0");
    const fakeHeap = new Uint8Array(heapFixed.length + 64);
    fakeHeap.set(heapFixed, 0);
    const fn = new Function(
      "Module", "UTF8ToString", "HEAPU8", "fetch", "console", "AbortController",
      `${glue.slice(a, b)}; return gd_http_start;`
    )(
      { gdHttpSeq: 0 }, () => "/api/gd/getGJLevels21.php", fakeHeap, fakeFetch,
      { log() {}, error() {} }, class { constructor() { this.signal = null; } }
    );
    fn(0, 0, 0, true);
    await new Promise((r) => setTimeout(r, 30));
    check("the engine's HTTP hook calls /api/gd/...", fetched[0] === "/api/gd/getGJLevels21.php", JSON.stringify(fetched));
    check("the request stays same-origin (relative URL)", fetched[0] && !/^https?:/.test(fetched[0]), String(fetched[0]));
  }
}

console.log(failures === 0 ? "\nONLINE PROXY: ALL PASS" : `\nONLINE PROXY: ${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
