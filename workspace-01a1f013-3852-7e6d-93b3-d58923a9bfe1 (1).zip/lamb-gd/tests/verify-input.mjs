#!/usr/bin/env node
/**
 * Unit test for the patched input hot path in gd_web.js.
 *
 * Old route: browser created [message, wParam, lParam] arrays, then the wasm glue
 * called Array.shift(), making both enqueue and dequeue allocation-heavy under an
 * input flood. New route: one fixed Int32 ring (three lanes per event), O(1) poll.
 * Drive both implementations with identical random traffic and require identical
 * Win32 message triples.
 */
import { readFile } from "node:fs/promises";

const src = await readFile(new URL("../public/a/gd_web.js", import.meta.url), "utf8");
const start = src.indexOf("function gd_js_mouse_poll(msg, wp, lp) {");
const end = src.indexOf("gd_js_mouse_poll.sig", start);
if (start < 0 || end < 0) throw new Error("gd_js_mouse_poll not found");
const patchedSrc = src.slice(start, end);

const HEAP = new Int32Array(16);
globalThis.HEAP32 = HEAP;
const CAP = 1024;
const ModuleA = {
  gdInputRing: new Int32Array(CAP * 3), gdInputMask: CAP - 1,
  gdInputHead: 0, gdInputTail: 0, gdInputCount: 0,
};
const patchedPoll = new Function("HEAP32", "Module", `return (${patchedSrc.trim()})`)(HEAP, ModuleA);
const ModuleB = { gdInputQueue: [] };

function clearA() { ModuleA.gdInputHead = ModuleA.gdInputTail = ModuleA.gdInputCount = 0; }
function pushA(e) {
  const mask = ModuleA.gdInputMask;
  const t = ModuleA.gdInputTail & mask;
  const p = t * 3, r = ModuleA.gdInputRing;
  r[p] = e[0]; r[p + 1] = e[1]; r[p + 2] = e[2];
  ModuleA.gdInputTail = (t + 1) & mask;
  if (ModuleA.gdInputCount >= mask + 1) ModuleA.gdInputHead = (ModuleA.gdInputHead + 1) & mask;
  else ModuleA.gdInputCount++;
}
function pushBoth(e) {
  pushA(e);
  // Exact overflow policy: preserve the newest CAP entries.
  if (ModuleB.gdInputQueue.length >= CAP) ModuleB.gdInputQueue.shift();
  ModuleB.gdInputQueue.push(e.slice());
}
function refPoll(msg, wp, lp) {
  const q = ModuleB.gdInputQueue;
  if (!q.length) return 0;
  const e = q.shift();
  HEAP[msg >>> 2] = e[0]; HEAP[wp >>> 2] = e[1]; HEAP[lp >>> 2] = e[2];
  return 1;
}

let checked = 0, failures = 0;
const rnd = () => Math.random();
for (let round = 0; round < 2000; round++) {
  const nPush = Math.floor(rnd() * 6);
  for (let i = 0; i < nPush; i++) pushBoth([Math.floor(rnd() * 1000), Math.floor(rnd() * 4), Math.floor(rnd() * 1e6)]);
  const nPoll = Math.floor(rnd() * 8);
  for (let i = 0; i < nPoll; i++) {
    HEAP.fill(-1); const a = patchedPoll(0, 4, 8); const aOut = Array.from(HEAP.slice(0, 3));
    HEAP.fill(-1); const b = refPoll(0, 4, 8); const bOut = Array.from(HEAP.slice(0, 3));
    checked++;
    if (a !== b || aOut.join() !== bOut.join()) {
      if (++failures <= 3) console.error("MISMATCH", { a, b, aOut, bOut });
    }
  }
}

// Empty/drain edge, then force a ring wrap + overflow to prove order and policy.
clearA(); ModuleB.gdInputQueue.length = 0;
if (patchedPoll(0, 4, 8) !== 0) { failures++; console.error("empty ring must return 0"); }
for (let i = 0; i < CAP + 17; i++) pushBoth([i, i & 3, i * 7]);
for (let i = 0; i < CAP; i++) {
  HEAP.fill(-1); const a = patchedPoll(0, 4, 8); const aOut = Array.from(HEAP.slice(0, 3));
  HEAP.fill(-1); const b = refPoll(0, 4, 8); const bOut = Array.from(HEAP.slice(0, 3));
  checked++;
  if (a !== b || aOut.join() !== bOut.join()) failures++;
}
if (ModuleA.gdInputCount !== 0 || ModuleB.gdInputQueue.length !== 0) { failures++; console.error("ring/reference not drained"); }

console.log(`ring equivalence: ${checked} polls compared, ${failures} failures`);
console.log(failures === 0 ? "GLUE HOT-PATH: ALL PASS" : "GLUE HOT-PATH: FAILED");
process.exit(failures === 0 ? 0 : 1);
