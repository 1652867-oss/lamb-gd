#!/usr/bin/env node
/**
 * Build integrity check - runs against public/ after `npm run assets`.
 *
 * Guarantees the class of bugs that broke the deployed page:
 *   1. every file the page names exists on disk (no 404s, no mixed versions)
 *   2. index.html's inlined GD_BUILD agrees with a/manifest.json
 *   3. every manifest part exists, is gzip, and its size matches the manifest
 *   4. the shipped texture set matches the engine's requested resolution
 *   5. no stale build tags are referenced anywhere
 *
 * Exit code 0 = ship it.
 */
import { createHash } from "node:crypto";
import { readFile, readdir, stat } from "node:fs/promises";
import { join } from "node:path";

const PUBLIC = new URL("../public/", import.meta.url).pathname;
let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};

const html = await readFile(join(PUBLIC, "index.html"), "utf8");
const manifest = JSON.parse(await readFile(join(PUBLIC, "a/manifest.json"), "utf8"));
const m = html.match(/var GD_BUILD = (\{[^}]*\});/);
if (!m) {
  console.error("FATAL: GD_BUILD not found in index.html");
  process.exit(1);
}
const build = JSON.parse(m[1]);

/* 1. version agreement ---------------------------------------------------- */
check("index.html GD_BUILD is the deployment's tag", build.tag === manifest.tag, `${build.tag} vs ${manifest.tag}`);
check("index.html part count matches manifest", build.parts === manifest.parts, `${build.parts} vs ${manifest.parts}`);
check("reported data size matches", build.dataBytes === manifest.dataBytes);
check("quality is reported", ["uhd", "hd", "ld", "all"].includes(build.quality), String(build.quality));
check("manifest carries an artifact-input fingerprint", typeof manifest.inputHash === "string" && /^[a-f0-9]{40}$/.test(manifest.inputHash), String(manifest.inputHash));

/* 2. every part exists, is gzip, has the declared size -------------------- */
let total = 0;
for (let i = 1; i <= manifest.parts; i++) {
  const f = join(PUBLIC, "a", `gd_web.data.part${i}`);
  let st;
  try {
    st = await stat(f);
  } catch {
    check(`part${i} exists`, false, "missing");
    continue;
  }
  total += st.size;
  const head = (await readFile(f)).subarray(0, 2);
  const gz = head[0] === 0x1f && head[1] === 0x8b;
  if (gz) check(`part${i} is gzip (${st.size} B)`, true);
  else check(`part${i} is gzip`, false, head.toString("hex"));
}
check("bytes on disk match manifest", total === manifest.dataWireBytes, `${total} vs ${manifest.dataWireBytes}`);

const files = await readdir(join(PUBLIC, "a"));
check("no orphan part files", files.filter((f) => /^gd_web\.data\.part\d+$/.test(f)).length === manifest.parts);

/* 3. the engine + wasm pack are present and current ---------------------- */
const glue = await readFile(join(PUBLIC, "a/gd_web.js"), "utf8");
check("glue is stamped with this build tag", glue.includes(`__gdBuildTag = "${manifest.tag}"`) || glue.includes(`"${manifest.tag}"`));

/* the tag must change when the GLUE changes: /a/* is immutable and the glue carries
   the same stamp, so a glue-only update would otherwise never reach returning
   players. Recompute the hash with a placeholder stamp and compare. */
{
  const { createHash } = await import("node:crypto");
  const sha = (str) => createHash("sha1").update(str).digest("hex");
  const plain = glue.replace(new RegExp(manifest.tag, "g"), "@@GD_BUILD_TAG@@");
  check("tag is derived from the glue bytes", sha(plain) === manifest.glueHash, `${sha(plain).slice(0, 12)} vs ${String(manifest.glueHash).slice(0, 12)}`);
  check("glue hash is not the stamped hash", sha(glue) !== manifest.glueHash);
}
check("wasm pack exists", (await stat(join(PUBLIC, "a/gd_web.wasm.pack"))).size > 1e6);

/* 4. resolution discipline ------------------------------------------------- */
const table = glue.slice(glue.indexOf("loadPackage("), glue.indexOf("loadPackage(") + 400000);
const names = [...table.matchAll(/"([^"]+\.(?:png|plist|fnt))"/g)].map((x) => x[1]).filter(Boolean);
const tex = names.filter((n) => /\.(png|plist|fnt)$/i.test(n));
const base = (n) => n.replace(/-(uhd|hd|ld)(\.(?:png|plist|fnt))$/i, "$2");
const seen = new Map();
let mixed = [];
for (const n of tex) {
  const b = base(n);
  const res = (n.match(/-(uhd|hd|ld)\./i) || [, "1x"])[1];
  if (seen.has(b) && seen.get(b) !== res) mixed.push(`${b}: ${seen.get(b)} vs ${res}`);
  seen.set(b, res);
}
check("single-resolution builds do not mix texture tiers", manifest.quality === "all" || mixed.length === 0,
      mixed.slice(0, 3).join("; "));
const lower = tex.filter((n) => /-(hd|ld)\./i.test(n));
check("lower-resolution texture count matches manifest", lower.length === (manifest.lowerResTextures || 0), `${lower.length} vs manifest ${manifest.lowerResTextures}`);
const selectedTier = manifest.quality === "all" ? "uhd" : manifest.quality;
check(`${selectedTier} textures present`, tex.some((n) => new RegExp(`-${selectedTier}\\.`, "i").test(n)));
if (manifest.quality === "hd") check("HD build ships no UHD textures", !tex.some((n) => /-uhd\./i.test(n)));
if (manifest.quality === "ld") check("LD build ships no UHD textures", !tex.some((n) => /-uhd\./i.test(n)));
console.log(`      (${tex.length} textures, ${lower.length} in an HD/LD tier)`);

/* 5. no dangling references in the page ----------------------------------- */
const refs = new Set();
for (const mm of html.matchAll(/assetURL\("([^"]+)"/g)) refs.add(mm[1]);
for (const mm of html.matchAll(/"a\/([^"?]+)"/g)) refs.add(mm[1]);
let missing = [];
for (const r of refs) {
  try {
    await stat(join(PUBLIC, "a", r));
  } catch {
    missing.push(r);
  }
}
check("every file the page requests exists", missing.length === 0, missing.join(", "));
const unversioned = [...html.matchAll(/(?:src|href)\s*=\s*"([^"]*\/a\/[^"]+)"/g)].map((x) => x[1]);
check("no hard-coded /a/ URLs in the page (all go through assetURL)", unversioned.length === 0, unversioned.join(", "));
check("glue is loaded through assetURL", /assetURL\("gd_web\.js"/.test(html));

/* 6. vercel.json stays consistent with reality --------------------------- */
const vercel = JSON.parse(await readFile(new URL("../vercel.json", import.meta.url), "utf8"));
check("vercel headers rule for /a/ is immutable", JSON.stringify(vercel).includes("immutable"));
check("html is never cached", JSON.stringify(vercel).includes("no-store"));

const mb = (n) => (n / 1024 / 1024).toFixed(1) + " MB";
console.log(`\nshipping ${mb(manifest.dataBytes)} raw / ${mb(manifest.dataWireBytes)} gzipped in ${manifest.parts} parts, tag ${manifest.tag}`);
console.log(failures === 0 ? "BUILD INTEGRITY: ALL PASS" : `BUILD INTEGRITY: ${failures} FAILURE(S)`);
process.exit(failures === 0 ? 0 : 1);
