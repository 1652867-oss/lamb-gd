#!/usr/bin/env node
/**
 * Browser-side online fallback contract.
 *
 * The native engine invokes gd_http_start in generated glue. This test regenerates
 * just that glue in memory from the pinned raw source (no resource repack), then
 * proves that a failed same-origin level search retries through the public-read
 * relay, account endpoints do not, and a downloaded platformer disables only the
 * unsafe uncapped simulation wake-up.
 */
import { readFile } from "node:fs/promises";

let failures = 0;
const check = (name, ok, detail = "") => {
  console.log(`${ok ? "  PASS  " : "  FAIL  "}${name}${!ok && detail ? "  -> " + detail : ""}`);
  if (!ok) failures++;
};

const source = await readFile(new URL("../scripts/fetch-assets.mjs", import.meta.url), "utf8");
const helperStart = source.indexOf("function findJsonObject(");
const helperEnd = source.indexOf("/* ------------------------------------------------------------------- main */");
if (helperStart < 0 || helperEnd < 0) throw new Error("cannot locate glue patch helpers");
const helpers = source.slice(helperStart, helperEnd);
const { findJsonObject, patchGlue, tuneGlue } = new Function(
  `const PART = 19922944; ${helpers}; return { findJsonObject, patchGlue, tuneGlue };`
)();

const raw = await readFile(new URL("../.cache-assets/gd_web.js", import.meta.url), "utf8");
const table = findJsonObject(raw, "  loadPackage(");
const meta = JSON.parse(raw.slice(table.start, table.end));
const glue = tuneGlue(patchGlue(raw, meta, "browser-online-test"));
const start = glue.indexOf("function gd_http_start(proxy, body, bodylen, is_post) {");
const end = glue.indexOf("\n}", glue.indexOf("return id;", start)) + 2;
if (start < 0 || end < 2) throw new Error("generated gd_http_start not found");
const httpSource = glue.slice(start, end);

const bytes = (s) => new TextEncoder().encode(s);
const response = (status, text) => ({
  status,
  headers: { forEach() {}, get() { return null; } },
  body: null,
  arrayBuffer: () => Promise.resolve(bytes(text).buffer),
});
const pause = () => new Promise((resolve) => setTimeout(resolve, 0));

async function run({ path, replies, pacing = { uncap: true } }) {
  const urls = [];
  const fakeFetch = (url) => {
    urls.push(String(url));
    const next = replies.shift();
    return next instanceof Error ? Promise.reject(next) : Promise.resolve(next);
  };
  const Module = { gdHttpSeq: 0, __gdPacing: pacing };
  const fn = new Function("Module", "UTF8ToString", "HEAPU8", "fetch", "console", "AbortController", httpSource + "; return gd_http_start;")(
    Module, () => path, new Uint8Array(32), fakeFetch, { log() {}, error() {} }, class { constructor() { this.signal = null; } }
  );
  const id = fn(0, 0, 0, true);
  for (let i = 0; i < 20 && !Module.gdHttpById[id].done; i++) await pause();
  return { urls, state: Module.gdHttpById[id], Module };
}

{
  const out = await run({
    path: "/api/gd/downloadGJLevel22.php",
    replies: [response(502, "proxy unavailable"), response(200, "1:999:2:Platformer:4:data:31:1:45:0:")],
  });
  check("failed same-origin level download retries in the browser", out.urls.length === 2, JSON.stringify(out.urls));
  check("browser retry targets the public GD relay", /workers\.dev\/\?url=/.test(out.urls[1] || "") && /downloadGJLevel22/.test(out.urls[1] || ""), out.urls[1] || "");
  check("relay response is returned to the native HTTP bridge", out.state.status === 200 && out.state.body && out.state.body.length > 0, String(out.state.status));
  check("platformer level disables only uncapped simulation", out.Module.__gdPlatformerActive === 1 && out.Module.__gdPacing.uncap === false,
        JSON.stringify({ platformer: out.Module.__gdPlatformerActive, uncap: out.Module.__gdPacing.uncap }));
}

{
  const out = await run({
    path: "/api/gd/accounts/loginGJAccount.php",
    replies: [response(502, "proxy unavailable")],
  });
  check("account requests never retry through the public relay", out.urls.length === 1 && out.urls[0] === "/api/gd/accounts/loginGJAccount.php", JSON.stringify(out.urls));
}

console.log(failures === 0 ? "\nBROWSER ONLINE BRIDGE: ALL PASS" : `\nBROWSER ONLINE BRIDGE: ${failures} FAILED`);
process.exit(failures === 0 ? 0 : 1);
