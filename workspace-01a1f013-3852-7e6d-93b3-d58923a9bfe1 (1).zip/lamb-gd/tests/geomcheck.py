#!/usr/bin/env python3
"""Geometry + input mapping check: one browser, one page, resized repeatedly."""
import asyncio, os, sys
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", "/opt/playwright/browsers")
from playwright.async_api import async_playwright

URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000/"
ARGS = ["--no-sandbox", "--disable-dev-shm-usage", "--single-process", "--no-zygote",
        "--js-flags=--max-old-space-size=256", "--use-gl=angle", "--use-angle=swiftshader"]

GEOM = """(() => {
  const c = document.getElementById('canvas');
  const r = c.getBoundingClientRect();
  return { rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
           win: [window.innerWidth, window.innerHeight], bitmap: [c.width, c.height],
           game: [window.__gdRender.gameWidth, window.__gdRender.gameHeight] };
})()"""


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        ctx = await b.new_context(viewport={"width": 960, "height": 540})
        await ctx.route("**/a/**", lambda route: route.abort())  # geometry needs no assets
        pg = await ctx.new_page()
        await pg.goto(URL + "?nofs", wait_until="commit", timeout=30000)
        await asyncio.sleep(0.4)

        allok = True
        for (w, h) in [(960, 540), (1000, 700), (800, 800), (1400, 500), (1920, 1080)]:
            await pg.set_viewport_size({"width": w, "height": h})
            await asyncio.sleep(0.25)
            g = await pg.evaluate(GEOM)
            L, T, W, H = g["rect"]
            aspect = W / H
            centred = abs(L + W / 2 - g["win"][0] / 2) <= 1 and abs(T + H / 2 - g["win"][1] / 2) <= 1
            inside = L >= 0 and T >= 0 and L + W <= g["win"][0] and T + H <= g["win"][1]

            clicks = []
            for fx, fy in [(0.5, 0.5), (0.25, 0.75)]:
                await pg.mouse.click(L + W * fx, T + H * fy)
                await asyncio.sleep(0.12)
                cur = await pg.evaluate("Module.gdCursorPos.slice()")
                want = [round(g["game"][0] * fx), round(g["game"][1] * fy)]
                clicks.append((cur, want, abs(cur[0] - want[0]) <= 2 and abs(cur[1] - want[1]) <= 2))

            ok = abs(aspect - 16 / 9) < 0.005 and centred and inside and all(c[2] for c in clicks)
            allok = allok and ok
            print(f"{w}x{h}: rect={g['rect']} aspect={aspect:.4f} centred={centred} inside={inside} "
                  f"clickmap={'ok' if all(c[2] for c in clicks) else 'BAD ' + str(clicks)} -> {'PASS' if ok else 'FAIL'}")

        print("\nGEOMETRY+INPUT:", "ALL PASS" if allok else "FAILURES PRESENT")
        try:
            await b.close()
        except Exception:
            pass

asyncio.run(main())
