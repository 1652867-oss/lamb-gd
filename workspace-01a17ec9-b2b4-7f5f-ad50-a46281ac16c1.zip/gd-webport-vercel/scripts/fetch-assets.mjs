#!/usr/bin/env node
/**
 * Fetches the Geometry Dash WASM assets from the pinned upstream commit,
 * applies a few performance patches to the Emscripten glue, and writes
 * everything into public/a/ so the deployment is 100% self-hosted.
 *
 *   node scripts/fetch-assets.mjs           # only downloads what is missing
 *   node scripts/fetch-assets.mjs --force   # re-download everything
 *
 * Upstream: https://github.com/AlexBoops/geometry-dash-webport (glue + assets)
 *           original web port by bog / "lollipop"
 */

import { mkdir, writeFile, stat, readFile } from "node:fs/promises";
import { createWriteStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import { Readable } from "node:stream";
import path from "node:path";

const COMMIT = "c6ac9417ff93ea957425b23ee87f1ed290663ebb";
const UPSTREAM = `https://cdn.jsdelivr.net/gh/AlexBoops/geometry-dash-webport@${COMMIT}/`;

const OUT = path.resolve("public/a");
const FORCE = process.argv.includes("--force");

const WASM_PARTS = [19922944, 19922944, 19922944, 10060133]; // 69,828,965 total
const DATA_PARTS = [
  19922944, 19922944, 19922944, 19922944, 19922944, 19922944, 19922944, 19922944,
  19922944, 19922944, 19922944, 19922944, 19922944, 19922944, 19922944, 15656699,
]; // 314,500,859 total
const WASM_TOTAL = WASM_PARTS.reduce((a, b) => a + b, 0);
const DATA_TOTAL = DATA_PARTS.reduce((a, b) => a + b, 0);

const MB = (n) => (n / 1048576).toFixed(1) + " MB";

async function exists(p, size) {
  try {
    const s = await stat(p);
    return size === undefined || s.size === size;
  } catch {
    return false;
  }
}

async function download(url, dest, expectedSize, label) {
  const { rename } = await import("node:fs/promises");
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await pipeline(Readable.fromWeb(res.body), createWriteStream(dest + ".tmp"));
      const s = await stat(dest + ".tmp");
      if (expectedSize && s.size !== expectedSize) throw new Error(`size ${s.size} != ${expectedSize}`);
      await rename(dest + ".tmp", dest);
      return;
    } catch (e) {
      if (attempt === 4) throw new Error(`${label}: ${e.message}`);
      await new Promise((r) => setTimeout(r, 300 * attempt));
    }
  }
}

/* ------------------------------------------------------------------ */
/* Emscripten glue patches                                            */
/* ------------------------------------------------------------------ */

function patchGlue(src) {
  const start = src.indexOf("async function fetchRemotePackage(packageName, packageSize) {");
  const endMarker = "    var fetchedCallback;";
  const end = src.indexOf(endMarker, start);
  if (start < 0 || end < 0) throw new Error("could not locate fetchRemotePackage in gd_web.js");

  const replacement = `async function fetchRemotePackage(packageName, packageSize) {
      if (isNode) {
        var fsPromises = require("fs/promises");
        var contents = await fsPromises.readFile(packageName);
        return contents.buffer;
      }
      // ---- patched: parallel streaming pack loader -------------------
      // Downloads all ${DATA_PARTS.length} parts of the data package concurrently, streaming each
      // response body straight into one preallocated buffer. This avoids the
      // upstream version's extra full-size copy of the 315 MB package.
      Module["dataFileDownloads"] ??= {};
      const PART_COUNT = ${DATA_PARTS.length};
      const PART_SIZE = ${DATA_PARTS[0]};
      const total = packageSize || ${DATA_TOTAL};
      const CONCURRENCY = 8;
      const merged = new Uint8Array(total);
      let loaded = 0;
      let failed = null;

      const report = () => {
        Module["dataFileDownloads"][packageName] = { loaded: loaded, total: total };
        let l = 0, t = 0;
        for (const d of Object.values(Module["dataFileDownloads"])) { l += d.loaded; t += d.total; }
        Module["setStatus"]?.("Downloading data... (" + (l / 1048576).toFixed(1) + "MB / " + (t / 1048576).toFixed(1) + "MB)");
        if (Module["gdProgress"]) Module["gdProgress"](1 / 6 + (l / t) * 74);
      };

      async function streamPart(idx) {
        const url = packageName + ".part" + (idx + 1);
        const offset = idx * PART_SIZE;
        let pos = 0;
        for (let attempt = 1; ; attempt++) {
          try {
            const headers = pos > 0 ? { Range: "bytes=" + pos + "-" } : undefined;
            const res = await fetch(url, { headers, cache: "force-cache" });
            if (res.status === 416 && pos > 0) { pos = 0; continue; }
            if (!res.ok) throw new Error("HTTP " + res.status);
            if (pos > 0 && res.status !== 206) pos = 0; // server ignored the range: restart part
            const reader = res.body.getReader();
            for (;;) {
              const { done, value } = await reader.read();
              if (done) break;
              const end = offset + pos + value.length;
              if (end > total) throw new Error("part overflow");
              merged.set(value, offset + pos);
              loaded += value.length;
              pos += value.length;
              report();
            }
            return;
          } catch (e) {
            if (attempt >= 5) throw new Error("part " + (idx + 1) + ": " + e.message);
            await new Promise((r) => setTimeout(r, 200 * attempt));
          }
        }
      }

      report();
      let next = 0;
      async function worker() {
        while (!failed) {
          const idx = next++;
          if (idx >= PART_COUNT) return;
          try {
            await streamPart(idx);
          } catch (e) {
            failed = e;
          }
        }
      }
      await Promise.all(Array.from({ length: CONCURRENCY }, worker));
      if (failed) throw failed;
      if (loaded !== total) throw new Error("data package incomplete: " + loaded + "/" + total);
      return merged.buffer;
    }
`;
  return src.slice(0, start) + replacement + src.slice(end);
}

/* ------------------------------------------------------------------ */

async function main() {
  await mkdir(OUT, { recursive: true });
  const t0 = Date.now();
  console.log(`[assets] target: ${OUT}`);
  console.log(`[assets] upstream: ${UPSTREAM}`);

  /* 1. glue */
  const gluePath = path.join(OUT, "gd_web.js");
  if (FORCE || !(await exists(gluePath))) {
    console.log("[assets] gd_web.js ...");
    const res = await fetch(UPSTREAM + "gd_web.js");
    if (!res.ok) throw new Error("gd_web.js: HTTP " + res.status);
    const patched = patchGlue(await res.text());
    await writeFile(gluePath, patched);
    console.log(`[assets] gd_web.js patched (${MB(patched.length)})`);
  } else {
    console.log("[assets] gd_web.js cached");
  }

  /* 2. wasm -> single file (streamed + compiled natively by the browser) */
  const wasmPath = path.join(OUT, "gd_web.wasm");
  if (FORCE || !(await exists(wasmPath, WASM_TOTAL))) {
    console.log(`[assets] gd_web.wasm (${WASM_PARTS.length} parts -> ${MB(WASM_TOTAL)}) ...`);
    const blobs = [];
    for (let i = 0; i < WASM_PARTS.length; i++) {
      const tmp = path.join(OUT, `.wasm.part${i + 1}`);
      await download(UPSTREAM + `gd_web.wasm.part${i + 1}`, tmp, WASM_PARTS[i], `wasm.part${i + 1}`);
      blobs.push(await readFile(tmp));
      await import("node:fs/promises").then((fs) => fs.unlink(tmp));
      console.log(`[assets]   wasm part ${i + 1}/${WASM_PARTS.length}`);
    }
    await writeFile(wasmPath, Buffer.concat(blobs));
    console.log(`[assets] gd_web.wasm ready (${MB(WASM_TOTAL)})`);
  } else {
    console.log("[assets] gd_web.wasm cached");
  }

  /* 3. data parts (served as-is, fetched in parallel by the client) */
  console.log(`[assets] gd_web.data (${DATA_PARTS.length} parts, ${MB(DATA_TOTAL)}) ...`);
  const queue = DATA_PARTS.map((size, i) => ({ i, size }));
  let finished = 0;
  const CONCURRENCY = 6;
  async function worker() {
    for (;;) {
      const job = queue.shift();
      if (!job) return;
      const dest = path.join(OUT, `gd_web.data.part${job.i + 1}`);
      if (FORCE || !(await exists(dest, job.size))) {
        await download(UPSTREAM + `gd_web.data.part${job.i + 1}`, dest, job.size, `data.part${job.i + 1}`);
      }
      finished++;
      if (finished % 4 === 0 || finished === DATA_PARTS.length) {
        console.log(`[assets]   data ${finished}/${DATA_PARTS.length} parts`);
      }
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));

  /* 4. verify */
  const totalFiles = ["gd_web.js", "gd_web.wasm"].length + DATA_PARTS.length;
  console.log(`[assets] done: ${totalFiles} files, ${MB(WASM_TOTAL + DATA_TOTAL)} in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

main().catch((e) => {
  console.error("[assets] FAILED:", e.message);
  process.exit(1);
});
