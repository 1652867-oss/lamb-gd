#!/usr/bin/env node
/**
 * Tiny static server that mimics the Vercel headers for local testing.
 *   node scripts/serve.mjs [port]
 */
import http from "node:http";
import { createReadStream, statSync, existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "public");
const PORT = Number(process.argv[2] || process.env.PORT || 3000);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".wasm": "application/wasm",
  ".json": "application/json",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (urlPath === "/") urlPath = "/index.html";
  const file = path.join(ROOT, path.normalize(urlPath).replace(/^(\.\.[/\\])+/, ""));

  if (!existsSync(file) || !statSync(file).isFile()) {
    res.writeHead(404, { "content-type": "text/plain" });
    res.end("404");
    return;
  }

  const stat = statSync(file);
  const ext = path.extname(file).toLowerCase();
  const headers = {
    "content-type": MIME[ext] || "application/octet-stream",
    "accept-ranges": "bytes",
    "access-control-allow-origin": "*",
    "cache-control": urlPath.startsWith("/a/")
      ? "public, max-age=31536000, immutable"
      : "public, max-age=0, must-revalidate",
  };

  // range support (the client resumes interrupted parts)
  const range = req.headers.range;
  if (range) {
    const m = /bytes=(\d+)-(\d*)/.exec(range);
    const start = Number(m[1]);
    const end = m[2] ? Number(m[2]) : stat.size - 1;
    headers["content-range"] = `bytes ${start}-${end}/${stat.size}`;
    headers["content-length"] = end - start + 1;
    res.writeHead(206, headers);
    createReadStream(file, { start, end }).pipe(res);
    return;
  }

  headers["content-length"] = stat.size;
  res.writeHead(200, headers);
  if (req.method === "HEAD") return res.end();
  createReadStream(file).pipe(res);
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`serving ${ROOT} on http://0.0.0.0:${PORT}`);
});
